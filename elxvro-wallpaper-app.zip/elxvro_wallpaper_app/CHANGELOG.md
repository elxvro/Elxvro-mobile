# Changelog

## 1.0.4
- Duvar kağıdı detay ekranında sağa/sola kaydırarak diğer görsellere geçiş eklendi.
- Tam ekran önizleme modu eklendi.
- Detay ekranına kategori ve görsel sayacı eklendi.
- Duvar kağıdı ayarlama akışı ve indirmesiz yapı korundu.
- GitHub Actions build akışı değiştirilmedi.

# ELXVRO Changelog

## v1.0.3
- GitHub Actions build akışı değiştirilmedi.
- Arama ekranı eklendi.
- Ana sayfadaki Tümü / Popüler / Yeni / Senin için filtreleri çalışır hale getirildi.
- Günün seçimi artık doğrudan tam ekran önizlemeyi açıyor.
- Tümünü Gör bağlantısı kategoriler ekranını açıyor.
- Kategori kartlarına içerik sayısı eklendi.
- Son görüntülenenler ekranı eklendi.
- Profil menüsündeki Favoriler, Son görüntülenenler, Gizlilik ve Hakkında bölümleri çalışır hale getirildi.
- Wallpaper kartlarına başlık katmanı eklendi.
- İndirme özelliği eklenmedi; uygulamanın amacı yalnızca duvar kağıdı uygulamak.
