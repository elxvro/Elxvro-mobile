# 1.0.16

- ELXVRO arayüzü baştan sona açık, yumuşak beyaz Material 3 tasarıma geçirildi.
- Arka plan, yüzey, sınır, metin ve vurgu renkleri profesyonel bir tasarım sistemi altında standardize edildi.
- Keşfet ekranına büyük arama alanı ve “Hızlı Keşfet” kısayolları eklendi.
- Günün seçimi, kategori kartları, geçmiş, son uygulanan ve ana galeri yeniden düzenlendi.
- Alt navigasyon, ayarlar, profil, favoriler, kategoriler, koleksiyonlar, arama ve Sync Manager açık temaya uyarlandı.
- Galeri kartlarında görsel adı gösterilmiyor; ad yalnızca detay ekranında gösteriliyor.
- Görsel detay ve düzenleyici ekranları fotoğraf odaklı koyu modda bırakıldı.
- Görsel kartlarına daha yumuşak köşeler, gölge ve tutarlı boşluk sistemi eklendi.
- Boş durum ekranları ve yardımcı metinler yeniden tasarlandı.
- Ayarlar ekranında açık tema bilgisi, yeni vurgu paleti ve daha düzenli ayar grupları eklendi.
- Gizlilik metni güncel Local Mirror / thumbnail çalışma biçimine göre güncellendi.
- Çalışan GitHub Actions workflow dosyası değiştirilmedi.

# 1.0.15

- Instant Gallery: ilk açılışta 286 görselin toplu indirilmesi kaldırıldı.
- Uygulama yalnızca manifesti alır ve galeri hemen kullanılabilir olur.
- Görseller ekranda ihtiyaç oldukça ağdan yüklenir.
- Detayda açılan görsel uygulamaya özel depolamaya otomatik alınır ve çevrimdışı kullanılabilir.
- Duvar kağıdı yapma ve düzenleyici açma sırasında gerekli dosya yerel kopyaya güvenli biçimde hazırlanır.
- Sync Manager içindeki tam eşitleme isteğe bağlıdır: “Tümünü çevrimdışı hazırla”.
- Mevcut yerel dosyalar korunur; imzası değişmiş eski kopyalar ağ sürümüne geçirilir.

# 1.0.13

- Sync Manager eklendi: canlı ilerleme, manifest/cihaz/yeni/değişmemiş/hata/temizlenen sayaçları.
- Local Mirror yalnızca yeni veya imzası değişen dosyaları indirir; tek dosya hatasında diğer dosyalar devam eder.
- Son başarılı eşitleme zamanı korunur; kısmi hata başarılı eşitleme zamanını ezmez.
- Başarılı tam eşitleme sonrası güvenli orphan temizliği ve manuel güvenli temizlik eklendi.
- Manifest schema 2 tekil ID yapısıyla uyum sağlandı.
- `_thumb` medya dosyaları istemci tarafında da reddedilir.
