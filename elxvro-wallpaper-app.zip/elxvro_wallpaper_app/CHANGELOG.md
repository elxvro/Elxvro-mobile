# 1.0.13

- Sync Manager eklendi: canlı ilerleme, manifest/cihaz/yeni/değişmemiş/hata/temizlenen sayaçları.
- Local Mirror artık yalnızca yeni veya imzası değişen dosyaları indirir; tek dosya hatasında diğer dosyalar devam eder.
- Son başarılı eşitleme zamanı korunur; kısmi hata başarılı eşitleme zamanını ezmez.
- Başarılı tam eşitleme sonrası güvenli orphan temizliği ve manuel güvenli temizlik eklendi.
- Manifest schema 2 tekil ID yapısıyla uyum sağlandı; eski yerel katalog bir kez otomatik yenilenir.
- `_thumb` medya dosyaları istemci tarafında da reddedilir.

# ELXVRO v1.0.12

## Local Mirror Sync

- Hosting medyası için ayrı manifest istemcisi eklendi.
- Yeni/değişen görseller uygulamanın Android özel depolama alanına atomik olarak kopyalanıyor.
- Görsel listeleri artık hem paket içi AssetImage hem de cihazdaki FileImage kaynaklarını destekliyor.
- Önizleme, benzer görseller, kategori kapakları, koleksiyon kapakları ve düzenleyici yerel dosya kaynağını destekliyor.
- Wallpaper uygulama servisi cihazdaki dosyayı doğrudan okuyabiliyor.
- Otomatik medya kontrolü 24 saatlik aralıkla sınırlandı.
- Başarısız bağlantı denemesi de kaydediliyor; sunucu kapalıyken uygulama açıldıkça istek tekrarlanmıyor.
- Manuel medya eşitleme ve durum bilgisi Ayarlar ekranına eklendi.
- Sitedeki kategori adları, manifestteki kategori slug'larıyla otomatik eşleştiriliyor.
- Dinamik katalog boyutlarında koleksiyon kapakları için güvenli fallback eklendi.
- Sürüm: 1.0.12+13.
