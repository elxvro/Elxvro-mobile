# Changelog

## 1.0.7
- Uygulanan duvar kağıtları için kalıcı yerel geçmiş eklendi.
- Varsayılan wallpaper hedefi ayarı eklendi.
- Günün seçimi günlük otomatik rotasyona geçirildi.
- Akıllı Koleksiyonlar ekranı eklendi.
- Gelişmiş arama ve filtreler eklendi.
- Kategori sıralama ve rastgele açma eklendi.
- Benzer duvar kağıtları paneli eklendi.
- OLED modu, vurgu rengi, kompakt galeri ve kart başlığı ayarları eklendi.
- Profil istatistikleri ve son uygulanan kartı eklendi.
- Ana sayfaya Son Uygulanan ve Devam Et bölümleri eklendi.
- Çalışan GitHub Actions build workflow değiştirilmedi.

## 1.0.6
- Sürpriz seçeneği ve komşu görsel ön yükleme eklendi.

## 1.0.5
- Favoriler ve son görüntülenenler kalıcı yerel depolamaya geçirildi.
