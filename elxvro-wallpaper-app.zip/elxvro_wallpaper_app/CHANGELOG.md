# Changelog

## 1.0.8

- Yeni tam ekran wallpaper düzenleyici eklendi.
- Pinch zoom ve sürükleyerek konumlandırma eklendi.
- Cover / contain görünüm seçenekleri eklendi.
- Parlaklık, kontrast, doygunluk ve blur kontrolleri eklendi.
- Normal, Canlı, Siyah-Beyaz, Sıcak ve Soğuk filtre presetleri eklendi.
- Önce / Sonra karşılaştırma modu eklendi.
- Ana ekran ve kilit ekranı sahte telefon önizlemesi eklendi.
- Düzenlenmiş görünüm RepaintBoundary üzerinden oluşturularak doğrudan wallpaper'a uygulanıyor.
- Native Android katmanına exactComposition desteği eklendi; düzenleyicide görülen kadraj korunuyor.
- Detay ekranına Düzenle butonu ve animasyonlu editör geçişi eklendi.
- İndirme / dışa aktarma özelliği eklenmedi.
- GitHub Actions build workflow değiştirilmedi.

## 1.0.7

- Kalıcı Uyguladıklarım geçmişi.
- Akıllı koleksiyonlar.
- Gelişmiş arama ve filtreleme.
- OLED modu, kompakt galeri ve vurgu rengi seçenekleri.
- Varsayılan wallpaper hedefi.
- Benzer wallpaper önerileri ve profil istatistikleri.
