# ELXVRO v1.0.9

- Profil alanı yalnızca Google ile girişe açıldı.
- Ayrı ELXVRO parola/kayıt formu kaldırıldı.
- Google profil adı, e-posta ve profil fotoğrafı gösteriliyor.
- Favorilerim, Uyguladıklarım, Son görüntülenenler ve Koleksiyonlar profil altında toplandı.
- Yerel veri yönetimi eklendi.
- Google hesabından çıkış eklendi.
- ELXVRO hesabını sil işlemi eklendi: Google bağlantısını kaldırır ve yerel ELXVRO verilerini temizler.
- Google hesabının kendisi silinmez.
- build-apk.yml değiştirilmedi.
