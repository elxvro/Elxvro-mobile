# ELXVRO v1.0.11

- Wallpaper görselleri tamamen yerel uygulama asset sistemine sabitlendi.
- Sitedeki görselleri kullanan herhangi bir wallpaper ağ akışı eklenmedi.
- Kategoriler ELXVRO site API'sinden alınacak şekilde bağlandı.
- Kategori listesine 24 saatlik cihaz önbelleği eklendi.
- Site erişilemezse son kategori önbelleği, o da yoksa yerel yedek kategori listesi kullanılır.
- Kategoriler ekranına manuel yenileme ve aşağı çekerek yenileme eklendi.
- Sitede olup APK içinde görseli olmayan kategoriler artık hata vermeden 0 yerel içerikle gösterilir.
- Yerel görsel ekleme rehberi eklendi.
- build-apk.yml değiştirilmedi.

# ELXVRO v1.0.10

- Google ile girişten önce Gizlilik Politikası ve Kullanım Koşulları için zorunlu onay eklendi.
- Gizlilik Politikası ve Kullanım Koşulları profil menüsüne ayrı sayfalar olarak eklendi.
- ELXVRO hesabını silme uyarısı güçlendirildi; işlemin Google hesabını silmediği açıklandı.
- Google giriş akışı, iki belge kabul edilmeden başlatılamaz.
- build-apk.yml değiştirilmedi.

# ELXVRO v1.0.9

- Profil alanı yalnızca Google ile girişe açıldı.
- Ayrı ELXVRO parola/kayıt formu kaldırıldı.
- Google profil adı, e-posta ve profil fotoğrafı gösteriliyor.
- Favorilerim, Uyguladıklarım, Son görüntülenenler ve Koleksiyonlar profil altında toplandı.
- Yerel veri yönetimi eklendi.
- Google hesabından çıkış eklendi.
- ELXVRO hesabını sil işlemi eklendi: Google bağlantısını kaldırır ve yerel ELXVRO verilerini temizler.
- Google hesabının kendisi silinmez.
- build-apk.yml değiştirilmedi.
