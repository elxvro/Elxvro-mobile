# ELXVRO v1.0.12

## Local Mirror Sync

- Hosting medyası için ayrı manifest istemcisi eklendi.
- Yeni/değişen görseller uygulamanın Android özel depolama alanına atomik olarak kopyalanıyor.
- Görsel listeleri artık hem paket içi AssetImage hem de cihazdaki FileImage kaynaklarını destekliyor.
- Önizleme, benzer görseller, kategori kapakları, koleksiyon kapakları ve düzenleyici yerel dosya kaynağını destekliyor.
- Wallpaper uygulama servisi cihazdaki dosyayı doğrudan okuyabiliyor.
- Otomatik medya kontrolü 24 saatlik aralıkla sınırlandı.
- Başarısız bağlantı denemesi de kaydediliyor; sunucu kapalıyken uygulama açıldıkça istek tekrarlanmıyor.
- Manuel medya eşitleme ve durum bilgisi Ayarlar ekranına eklendi.
- Sitedeki kategori adları, manifestteki kategori slug'larıyla otomatik eşleştiriliyor.
- Dinamik katalog boyutlarında koleksiyon kapakları için güvenli fallback eklendi.
- Sürüm: 1.0.12+13.
