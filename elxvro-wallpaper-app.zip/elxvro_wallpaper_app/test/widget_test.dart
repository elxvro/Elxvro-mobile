import 'package:flutter_test/flutter_test.dart';
import 'package:elxvro_wallpaper/app_state.dart';
import 'package:elxvro_wallpaper/main.dart';

void main() {
  testWidgets('ELXVRO uygulaması açılır', (WidgetTester tester) async {
    await tester.pumpWidget(
      AppScope(
        notifier: AppState(),
        child: const ElxvroApp(),
      ),
    );

    expect(find.text('E L X V R O'), findsWidgets);
  });
}
