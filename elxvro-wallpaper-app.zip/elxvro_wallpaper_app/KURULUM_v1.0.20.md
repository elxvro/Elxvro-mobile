# ELXVRO v1.0.20 kurulum

1. `elxvro-wallpaper-app-v1.0.20.zip` dosyasını GitHub depo köküne `elxvro-wallpaper-app.zip` adıyla yükle.
2. APK logosunun derlemeye taşınması için bu sürümle verilen `build-apk-v1.0.20.yml` dosyasını bir kez `.github/workflows/build-apk.yml` olarak değiştir.
3. GitHub Actions derlemesini çalıştır. Release keystore ve APK SHA-1 kontrolü önceki çalışan değerle aynı kalır.
4. Google Drive yedekleme için Google Cloud projesinde **Google Drive API** etkin olmalıdır. Yeni Android/Web OAuth istemcisi oluşturma; mevcut çalışan Google giriş istemcilerini kullan.
5. Uygulamada Profil → Google Drive Yedekleme → Şimdi Drive’a Yedekle seçildiğinde kullanıcıdan `drive.file` izni istenir.

Not: Bu sürüm hosting/MySQL auth dosyalarında değişiklik gerektirmez.
