# ELXVRO v1.0.9 Uygulama Akışı

Açılış -> Keşfet / Kategoriler / Favoriler -> Wallpaper Detay -> Düzenle -> Ana Ekran / Kilit Ekranı / İkisi -> Başarılı

Profil -> Google ile devam et -> Google hesap seçimi -> Profil

Profil içinde:
- Favorilerim
- Uyguladıklarım
- Son görüntülenenler
- Koleksiyonlar
- Uygulama ayarları
- Yerel verilerim
- Gizlilik
- Hakkında
- Google hesabından çıkış
- ELXVRO hesabını sil

ELXVRO hesabını sil:
Onay -> Yerel ELXVRO verilerini sıfırla -> Google yetkilendirmesini kaldır -> Giriş ekranına dön
