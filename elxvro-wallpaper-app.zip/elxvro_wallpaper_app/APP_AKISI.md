# ELXVRO Uygulama Akışı - v1.0.7

1. Açılış ekranı
2. Keşfet
   - Günün Seçimi
   - Tümü / Popüler / Yeni / Senin için / Sürpriz
   - Son uygulanan
   - Devam Et
   - Kategoriler
3. Gelişmiş Arama
   - Metin arama
   - Kategori filtresi
   - Hızlı etiket filtresi
   - Sadece favoriler
   - Sıralama
4. Kategoriler
   - Sıralama
   - Rastgele aç
5. Duvar kağıdı detayı
   - Sağa/sola kaydır
   - Tam ekran önizleme
   - Favori
   - Benzer görseller
   - Duvar Kağıdı Yap
6. Hedef
   - Ana ekran
   - Kilit ekranı
   - İkisi birden
   - Ayarlardan varsayılan hedef seçildiyse bu adım atlanır
7. Koleksiyonlar
   - Favorilerim
   - Uyguladıklarım
   - Son baktıklarım
   - Gece & Neon
   - Minimal
8. Profil
   - Kullanım istatistikleri
   - Son uygulanan
   - Favoriler / Koleksiyonlar / Geçmiş / Ayarlar
9. Ayarlar
   - OLED modu
   - Vurgu rengi
   - Kompakt galeri
   - Kart başlıkları
   - Varsayılan wallpaper hedefi
   - Yerel geçmiş temizleme

İndirme özelliği bulunmaz.
