# ELXVRO v1.0.14 Uygulama Akışı

## Açılış

1. Uygulama önce cihazdaki mevcut wallpaper kataloğunu kullanır.
2. Son medya kontrolünün üzerinden 24 saat geçtiyse küçük `media-manifest.php` dosyası kontrol edilir.
3. Manifestte yeni/değişen `ELX-M-*` dosyaları varsa sadece onlar cihazdaki uygulama özel klasörüne kopyalanır.
4. Liste/önizleme/düzenleme ekranları yalnızca yerel dosya yolunu kullanır.
5. Sunucu erişilemiyorsa kullanıcı bekletilmez; mevcut cihaz kopyalarıyla devam edilir.

## Kategoriler

- Kaynak: mevcut site `/api/v1/categories.php`.
- Cihaz cache süresi: 24 saat.
- Kategori görsel sayıları cihazdaki yerel medya kataloğuna göre hesaplanır.

## Wallpaper

Keşfet -> Detay -> Düzenle (isteğe bağlı) -> Ana ekran / Kilit ekranı / İkisi -> Android WallpaperManager

Görsel uygulanırken uzaktaki URL okunmaz; cihazdaki uygulama özel dosyası okunur.

## Profil

Yalnızca Google ile giriş. Giriş öncesinde Gizlilik Politikası ve Kullanım Koşulları kabul edilir. Profilde favoriler, uygulananlar, geçmiş, ayarlar, çıkış ve ELXVRO hesabını sil işlemleri bulunur.
