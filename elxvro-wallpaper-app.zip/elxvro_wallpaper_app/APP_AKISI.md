# ELXVRO v1.0.11 Uygulama Akışı

Açılış -> Keşfet / Kategoriler / Favoriler -> Wallpaper Detay -> Düzenle -> Ana Ekran / Kilit Ekranı / İkisi -> Başarılı

## İçerik kaynağı
Kategori listesi -> ELXVRO kategori API -> 24 saat cihaz önbelleği -> çevrimdışı yedek

Wallpaper görselleri -> yalnızca `assets/wallpapers/` -> APK/AAB içinden okunur

Siteden wallpaper görseli çekilmez.

## Profil
Profil -> Gizlilik Politikası + Kullanım Koşulları onayı -> Google ile devam et -> Google hesap seçimi -> Profil

Profil içinde:
- Favorilerim
- Uyguladıklarım
- Son görüntülenenler
- Koleksiyonlar
- Uygulama ayarları
- Yerel verilerim
- Gizlilik Politikası
- Kullanım Koşulları
- Google hesabından çıkış
- ELXVRO hesabını sil
