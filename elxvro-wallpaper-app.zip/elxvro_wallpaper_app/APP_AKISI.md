# ELXVRO v1.0.21 Uygulama Akışı

## Açılış

1. Uygulama hızlı manifest listesini alır.
2. Galeri tam boyutlu 286+ dosyanın indirilmesini beklemeden açılır.
3. Kartlarda hostingdeki küçük thumbnail dosyaları kullanılır.
4. Daha önce yerelleştirilmiş orijinaller varsa doğrudan cihazdaki kopya kullanılır.
5. Sunucu erişilemiyorsa cihazdaki Local Mirror ve paket içi fallback görsellerle devam edilir.

## Keşfet

Arama -> Günün Seçimi -> Hızlı Keşfet -> Devam Et -> Kategoriler -> Filtreli wallpaper galerisi.

Kartlarda wallpaper kodu/adı gösterilmez. Görsel detay ekranında kategori, wallpaper adı, etiketler ve uygulama/düzenleme işlemleri gösterilir.

## Kategoriler

Kategori listesi sunucu verisi ve manifestte görülen kategorilerle birleştirilir. Kategori kartları thumbnail kapakları ve gerçek görsel sayılarıyla gösterilir.

## Wallpaper

Keşfet / Kategori / Arama -> Detay -> Gerekirse orijinali cihazda hazırla -> Düzenle (isteğe bağlı) -> Ana ekran / Kilit ekranı / İkisi -> Android WallpaperManager.

## Profil

Google ile giriş kullanılır. Giriş öncesinde Gizlilik Politikası ve Kullanım Koşulları kabul edilir. Google ID token ELXVRO auth servisine gönderilir, sunucuda Google ile doğrulanır ve hesap kaydı `elxvro_app_users` MySQL tablosuna eklenir/güncellenir. Profilde MySQL senkron durumu ve ELXVRO hesap ID’si gösterilir. Favoriler, uygulananlar, geçmiş, koleksiyonlar ve tercihler bu sürümde cihazda yerel kalır.
