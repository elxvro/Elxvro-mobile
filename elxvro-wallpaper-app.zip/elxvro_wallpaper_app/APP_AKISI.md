# ELXVRO Uygulama Akışı

1. **Açılış** — Marka + tam ekran wallpaper.
2. **Keşfet** — Günün seçimi, kategori kartları ve öne çıkan wallpaper grid'i.
3. **Kategori** — Doğa, Şehir, Anime, Hayvan, Uzay, Araçlar, Minimal, Soyut.
4. **Önizleme** — Wallpaper tam ekran gösterilir; favori ve `Duvar Kağıdı Yap` bulunur.
5. **Hedef seçimi** — Ana Ekran / Kilit Ekranı / Ana Ekran + Kilit Ekranı.
6. **Android native işlem** — Flutter görsel bytes'ını `MethodChannel` ile Kotlin'e verir; Kotlin merkezden ekrana crop edip `WallpaperManager` ile uygular.
7. **Başarılı ekranı** — İşlem tamamlandığında onay diyaloğu gösterilir.
8. **Favoriler / Profil** — Kullanıcı uygulama içinde beğendiği duvar kağıtlarını görür. İndirme veya galeriye kaydetme yoktur.
