# ELXVRO Uygulama Akışı - v1.0.8

## Ana kullanım

Açılış → Keşfet → Kategori / Arama / Koleksiyon → Wallpaper Detay → Duvar Kağıdı Yap

## Düzenleme akışı

Wallpaper Detay → Düzenle → Telefon Önizlemesi → Kırp / Işık / Renk / Blur / Filtre → Önce-Sonra → Ana veya Kilit Önizleme → Düzenlenmiş Duvar Kağıdını Uygula → Ana Ekran / Kilit Ekranı / İkisi Birden → Başarılı

## Düzenleyici davranışı

- İki parmak: yakınlaştır
- Sürükle: konumlandır
- Çift dokun: düzenleme kontrollerini gizle / göster
- Ekranı Doldur: telefon ekranını tamamen kaplayan kompozisyon
- Tamamını Göster: görselin tamamını koruyan kompozisyon
- Önce: renk ve blur düzenlemelerini geçici olarak gizler
- Sıfırla: tüm ayarları ve görüntü konumunu varsayılana döndürür
- Uygula: ekranda görünen düzenlenmiş kompozisyonu wallpaper yapar

İndirme, dışa aktarma veya galeriye kayıt özelliği yoktur.
