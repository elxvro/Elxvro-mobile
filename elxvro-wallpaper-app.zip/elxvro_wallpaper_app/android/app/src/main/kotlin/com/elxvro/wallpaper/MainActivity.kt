package com.elxvro.wallpaper

import android.app.WallpaperManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import kotlin.concurrent.thread
import kotlin.math.max

class MainActivity : FlutterActivity() {
    private val channelName = "com.elxvro.wallpaper/channel"
    private val prefsName = "elxvro_local_state"
    private val listSeparator = "\u001F"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "setWallpaper" -> setWallpaper(call, result)
                    "loadState" -> loadState(result)
                    "saveState" -> saveState(call, result)
                    else -> result.notImplemented()
                }
            }
    }

    private fun setWallpaper(
        call: io.flutter.plugin.common.MethodCall,
        result: MethodChannel.Result,
    ) {
        val bytes = call.argument<ByteArray>("bytes")
        val target = call.argument<String>("target") ?: "home"
        val exactComposition = call.argument<Boolean>("exactComposition") ?: false
        if (bytes == null) {
            result.error("INVALID_IMAGE", "Görsel verisi alınamadı.", null)
            return
        }

        thread {
            try {
                val source = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    ?: throw IllegalArgumentException("Görsel çözümlenemedi.")
                val bitmap = if (exactComposition) {
                    scaleExactToScreen(source)
                } else {
                    centerCropToScreen(source)
                }
                val manager = WallpaperManager.getInstance(applicationContext)
                val which = when (target) {
                    "lock" -> WallpaperManager.FLAG_LOCK
                    "both" -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                    else -> WallpaperManager.FLAG_SYSTEM
                }
                manager.setBitmap(bitmap, null, true, which)
                if (bitmap !== source) bitmap.recycle()
                source.recycle()
                runOnUiThread { result.success(true) }
            } catch (e: Exception) {
                runOnUiThread {
                    result.error(
                        "SET_FAILED",
                        e.message ?: "Duvar kağıdı ayarlanamadı.",
                        null,
                    )
                }
            }
        }
    }

    private fun loadState(result: MethodChannel.Result) {
        try {
            val prefs = getSharedPreferences(prefsName, MODE_PRIVATE)
            val hasState = prefs.contains("favorites") ||
                prefs.contains("recent") ||
                prefs.contains("applied") ||
                prefs.contains("defaultTarget") ||
                prefs.contains("accent") ||
                prefs.contains("oledMode") ||
                prefs.contains("compactGrid") ||
                prefs.contains("showCardTitles")

            val favorites = prefs.getStringSet("favorites", emptySet())
                ?.toList()
                ?: emptyList()
            val recent = decodeList(prefs.getString("recent", "").orEmpty())
            val applied = decodeList(prefs.getString("applied", "").orEmpty())

            result.success(
                mapOf(
                    "hasState" to hasState,
                    "favorites" to favorites,
                    "recent" to recent,
                    "applied" to applied,
                    "defaultTarget" to prefs.getString("defaultTarget", "ask"),
                    "accent" to prefs.getString("accent", "violet"),
                    "oledMode" to prefs.getBoolean("oledMode", false),
                    "compactGrid" to prefs.getBoolean("compactGrid", false),
                    "showCardTitles" to prefs.getBoolean("showCardTitles", true),
                )
            )
        } catch (e: Exception) {
            result.error("STATE_READ_FAILED", e.message ?: "Yerel veri okunamadı.", null)
        }
    }

    private fun saveState(
        call: io.flutter.plugin.common.MethodCall,
        result: MethodChannel.Result,
    ) {
        try {
            val favorites = call.argument<List<String>>("favorites") ?: emptyList()
            val recent = call.argument<List<String>>("recent") ?: emptyList()
            val applied = call.argument<List<String>>("applied") ?: emptyList()
            val defaultTarget = call.argument<String>("defaultTarget") ?: "ask"
            val accent = call.argument<String>("accent") ?: "violet"
            val oledMode = call.argument<Boolean>("oledMode") ?: false
            val compactGrid = call.argument<Boolean>("compactGrid") ?: false
            val showCardTitles = call.argument<Boolean>("showCardTitles") ?: true

            getSharedPreferences(prefsName, MODE_PRIVATE)
                .edit()
                .putStringSet("favorites", favorites.toSet())
                .putString("recent", recent.joinToString(listSeparator))
                .putString("applied", applied.joinToString(listSeparator))
                .putString("defaultTarget", defaultTarget)
                .putString("accent", accent)
                .putBoolean("oledMode", oledMode)
                .putBoolean("compactGrid", compactGrid)
                .putBoolean("showCardTitles", showCardTitles)
                .apply()
            result.success(true)
        } catch (e: Exception) {
            result.error("STATE_SAVE_FAILED", e.message ?: "Yerel veri kaydedilemedi.", null)
        }
    }

    private fun decodeList(raw: String): List<String> {
        if (raw.isBlank()) return emptyList()
        return raw.split(listSeparator).filter { it.isNotBlank() }
    }

    private fun scaleExactToScreen(source: Bitmap): Bitmap {
        val metrics = resources.displayMetrics
        val targetWidth = metrics.widthPixels.coerceAtLeast(1)
        val targetHeight = metrics.heightPixels.coerceAtLeast(1)
        if (source.width == targetWidth && source.height == targetHeight) {
            return source
        }
        return Bitmap.createScaledBitmap(source, targetWidth, targetHeight, true)
    }

    private fun centerCropToScreen(source: Bitmap): Bitmap {
        val metrics = resources.displayMetrics
        val targetWidth = metrics.widthPixels.coerceAtLeast(1)
        val targetHeight = metrics.heightPixels.coerceAtLeast(1)
        val scale = max(
            targetWidth.toFloat() / source.width,
            targetHeight.toFloat() / source.height,
        )
        val scaledWidth = (source.width * scale).toInt().coerceAtLeast(targetWidth)
        val scaledHeight = (source.height * scale).toInt().coerceAtLeast(targetHeight)
        val scaled = Bitmap.createScaledBitmap(source, scaledWidth, scaledHeight, true)
        val x = ((scaledWidth - targetWidth) / 2).coerceAtLeast(0)
        val y = ((scaledHeight - targetHeight) / 2).coerceAtLeast(0)
        val cropped = Bitmap.createBitmap(scaled, x, y, targetWidth, targetHeight)
        if (scaled !== source && scaled !== cropped) scaled.recycle()
        return cropped
    }
}
