package com.elxvro.wallpaper

import android.app.WallpaperManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import kotlin.concurrent.thread
import kotlin.math.max

class MainActivity : FlutterActivity() {
    private val channelName = "com.elxvro.wallpaper/channel"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            if (call.method != "setWallpaper") {
                result.notImplemented()
                return@setMethodCallHandler
            }

            val bytes = call.argument<ByteArray>("bytes")
            val target = call.argument<String>("target") ?: "home"
            if (bytes == null) {
                result.error("INVALID_IMAGE", "Görsel verisi alınamadı.", null)
                return@setMethodCallHandler
            }

            thread {
                try {
                    val source = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        ?: throw IllegalArgumentException("Görsel çözümlenemedi.")
                    val bitmap = centerCropToScreen(source)
                    val manager = WallpaperManager.getInstance(applicationContext)
                    val which = when (target) {
                        "lock" -> WallpaperManager.FLAG_LOCK
                        "both" -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                        else -> WallpaperManager.FLAG_SYSTEM
                    }
                    manager.setBitmap(bitmap, null, true, which)
                    if (bitmap !== source) bitmap.recycle()
                    source.recycle()
                    runOnUiThread { result.success(true) }
                } catch (e: Exception) {
                    runOnUiThread {
                        result.error("SET_FAILED", e.message ?: "Duvar kağıdı ayarlanamadı.", null)
                    }
                }
            }
        }
    }

    private fun centerCropToScreen(source: Bitmap): Bitmap {
        val metrics = resources.displayMetrics
        val targetWidth = metrics.widthPixels.coerceAtLeast(1)
        val targetHeight = metrics.heightPixels.coerceAtLeast(1)
        val scale = max(targetWidth.toFloat() / source.width, targetHeight.toFloat() / source.height)
        val scaledWidth = (source.width * scale).toInt().coerceAtLeast(targetWidth)
        val scaledHeight = (source.height * scale).toInt().coerceAtLeast(targetHeight)
        val scaled = Bitmap.createScaledBitmap(source, scaledWidth, scaledHeight, true)
        val x = ((scaledWidth - targetWidth) / 2).coerceAtLeast(0)
        val y = ((scaledHeight - targetHeight) / 2).coerceAtLeast(0)
        val cropped = Bitmap.createBitmap(scaled, x, y, targetWidth, targetHeight)
        if (scaled !== source && scaled !== cropped) scaled.recycle()
        return cropped
    }
}
