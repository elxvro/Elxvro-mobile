import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';

import '../models/wallpaper.dart';

class MirrorSyncResult {
  final List<WallpaperItem> wallpapers;
  final int downloaded;
  final int reused;
  final bool checkedNetwork;
  final bool changed;
  final DateTime? lastCheckedAt;
  final String message;

  const MirrorSyncResult({
    required this.wallpapers,
    required this.downloaded,
    required this.reused,
    required this.checkedNetwork,
    required this.changed,
    required this.lastCheckedAt,
    required this.message,
  });
}

class MirrorSyncService {
  static const _channel = MethodChannel('com.elxvro.wallpaper/channel');
  static const String manifestEndpoint =
      'https://elxvro.com/app-api/v1/media-manifest.php';
  static const Duration checkInterval = Duration(hours: 24);
  static const Duration requestTimeout = Duration(seconds: 12);
  static const int maxImageBytes = 25 * 1024 * 1024;
  static const String _catalogFileName = 'mirror-catalog.json';

  static Future<MirrorSyncResult> load({
    required List<WallpaperItem> fallback,
    bool forceRefresh = false,
  }) async {
    final root = await _mirrorDirectory();
    final localCatalog = await _readLocalCatalog(root);
    final now = DateTime.now();
    final fresh = localCatalog.lastAttemptAt != null &&
        !now.difference(localCatalog.lastAttemptAt!).isNegative &&
        now.difference(localCatalog.lastAttemptAt!) < checkInterval;

    final localItems = _existingItems(root, localCatalog.items);
    if (!forceRefresh && fresh) {
      return MirrorSyncResult(
        wallpapers: localItems.isNotEmpty ? localItems : fallback,
        downloaded: 0,
        reused: localItems.length,
        checkedNetwork: false,
        changed: false,
        lastCheckedAt: localCatalog.lastCheckedAt,
        message: localItems.isNotEmpty
            ? 'Yerel kopyalar hazır.'
            : 'Paket içi görseller kullanılıyor.',
      );
    }

    try {
      final remote = await _fetchManifest();
      if (remote.items.isEmpty && localCatalog.items.isNotEmpty) {
        throw const FormatException('Boş manifest yerel kataloğun üzerine yazılmadı.');
      }
      final synced = await _sync(root, localCatalog, remote);
      final checkedAt = DateTime.now();
      await _writeLocalCatalog(
        root,
        version: remote.version,
        lastAttemptAt: checkedAt,
        lastCheckedAt: checkedAt,
        items: synced.catalogItems,
      );
      await _removeOrphans(root, synced.catalogItems);
      final syncedItems = _existingItems(root, synced.catalogItems);
      return MirrorSyncResult(
        wallpapers: syncedItems.isNotEmpty ? syncedItems : fallback,
        downloaded: synced.downloaded,
        reused: synced.reused,
        checkedNetwork: true,
        changed: synced.downloaded > 0 ||
            synced.catalogItems.length != localCatalog.items.length ||
            remote.version != localCatalog.version,
        lastCheckedAt: checkedAt,
        message: syncedItems.isEmpty
            ? 'Sunucuda yerel kopyaya uygun görsel bulunamadı.'
            : synced.downloaded > 0
                ? '${synced.downloaded} yeni/değişen görsel cihaza kopyalandı.'
                : 'Görseller güncel.',
      );
    } catch (_) {
      try {
        await _writeLocalCatalog(
          root,
          version: localCatalog.version,
          lastAttemptAt: DateTime.now(),
          lastCheckedAt: localCatalog.lastCheckedAt,
          items: localCatalog.items,
        );
      } catch (_) {
        // Başarısız kontrolün zaman damgası yazılamazsa mevcut dosyalar korunur.
      }
      return MirrorSyncResult(
        wallpapers: localItems.isNotEmpty ? localItems : fallback,
        downloaded: 0,
        reused: localItems.length,
        checkedNetwork: true,
        changed: false,
        lastCheckedAt: localCatalog.lastCheckedAt,
        message: localItems.isNotEmpty
            ? 'Bağlantı yok; cihazdaki yerel kopyalar kullanılıyor.'
            : 'Bağlantı yok; paket içi görseller kullanılıyor.',
      );
    }
  }

  static Future<String> _mirrorDirectory() async {
    try {
      final path = await _channel.invokeMethod<String>('getMirrorDirectory');
      if (path != null && path.isNotEmpty) {
        final dir = Directory(path);
        await dir.create(recursive: true);
        return dir.path;
      }
    } on MissingPluginException {
      // Test/Android dışı ortam.
    } on PlatformException {
      // Paket içi fallback kullanılacak.
    }
    return Directory.systemTemp
        .createTempSync('elxvro-mirror-test-')
        .path;
  }

  static Future<_RemoteManifest> _fetchManifest() async {
    final client = HttpClient()..connectionTimeout = requestTimeout;
    try {
      final request = await client
          .getUrl(Uri.parse(manifestEndpoint))
          .timeout(requestTimeout);
      request.headers.set(HttpHeaders.acceptHeader, 'application/json');
      request.headers.set(
        HttpHeaders.userAgentHeader,
        'ELXVRO-Android/1.0.12 local-mirror',
      );
      final response = await request.close().timeout(requestTimeout);
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw HttpException('Manifest HTTP ${response.statusCode}');
      }
      final body = await response
          .transform(utf8.decoder)
          .join()
          .timeout(requestTimeout);
      final decoded = jsonDecode(body);
      if (decoded is! Map) throw const FormatException('Manifest geçersiz.');
      final rawItems = decoded['wallpapers'];
      if (rawItems is! List) {
        throw const FormatException('wallpapers listesi yok.');
      }
      final items = <_MirrorItem>[];
      final ids = <String>{};
      for (final raw in rawItems.take(5000)) {
        final item = _MirrorItem.fromRemote(raw);
        if (item == null || !ids.add(item.id)) continue;
        items.add(item);
      }
      final version = decoded['version']?.toString() ?? '0';
      return _RemoteManifest(version: version, items: items);
    } finally {
      client.close(force: true);
    }
  }

  static Future<_SyncWork> _sync(
    String root,
    _LocalCatalog local,
    _RemoteManifest remote,
  ) async {
    final previous = {for (final item in local.items) item.id: item};
    final output = <_MirrorItem>[];
    var downloaded = 0;
    var reused = 0;

    for (final remoteItem in remote.items) {
      final old = previous[remoteItem.id];
      final target = File(_absolutePath(root, remoteItem.localRelativePath));
      final unchanged = old != null &&
          old.signature == remoteItem.signature &&
          await target.exists();
      if (unchanged) {
        output.add(remoteItem);
        reused++;
        continue;
      }

      try {
        await _download(remoteItem.url, target);
        output.add(remoteItem);
        downloaded++;
      } catch (_) {
        if (old != null) {
          final oldFile = File(_absolutePath(root, old.localRelativePath));
          if (await oldFile.exists()) {
            output.add(old);
            reused++;
          }
        }
      }
    }

    return _SyncWork(
      catalogItems: output,
      downloaded: downloaded,
      reused: reused,
    );
  }

  static Future<void> _download(String url, File target) async {
    final uri = Uri.parse(url);
    if (uri.scheme != 'https' || uri.host.toLowerCase() != 'elxvro.com') {
      throw HttpException('Yalnızca ELXVRO HTTPS medya adresleri kabul edilir.');
    }
    await target.parent.create(recursive: true);
    final temp = File('${target.path}.part');
    if (await temp.exists()) await temp.delete();

    final client = HttpClient()..connectionTimeout = requestTimeout;
    try {
      final request = await client.getUrl(uri).timeout(requestTimeout);
      request.headers.set(
        HttpHeaders.userAgentHeader,
        'ELXVRO-Android/1.0.12 media-copy',
      );
      final response = await request.close().timeout(requestTimeout);
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw HttpException('Medya HTTP ${response.statusCode}');
      }
      final contentLength = response.contentLength;
      if (contentLength > maxImageBytes) {
        throw HttpException('Görsel dosyası çok büyük.');
      }
      final sink = temp.openWrite();
      var received = 0;
      try {
        await for (final chunk in response.timeout(requestTimeout)) {
          received += chunk.length;
          if (received > maxImageBytes) {
            throw HttpException('Görsel dosyası çok büyük.');
          }
          sink.add(chunk);
        }
      } finally {
        await sink.close();
      }
      if (received == 0) throw HttpException('Boş görsel dosyası.');
      if (await target.exists()) await target.delete();
      await temp.rename(target.path);
    } finally {
      client.close(force: true);
      if (await temp.exists()) await temp.delete();
    }
  }

  static Future<_LocalCatalog> _readLocalCatalog(String root) async {
    final file = File('$root/$_catalogFileName');
    try {
      if (!await file.exists()) return const _LocalCatalog();
      final decoded = jsonDecode(await file.readAsString());
      if (decoded is! Map) return const _LocalCatalog();
      final rawItems = decoded['wallpapers'];
      final items = <_MirrorItem>[];
      if (rawItems is List) {
        for (final raw in rawItems) {
          final item = _MirrorItem.fromLocal(raw);
          if (item != null) items.add(item);
        }
      }
      final checkedRaw = decoded['last_checked_at'];
      final attemptRaw = decoded['last_attempt_at'];
      final lastCheckedAt = checkedRaw is String
          ? DateTime.tryParse(checkedRaw)
          : null;
      final lastAttemptAt = attemptRaw is String
          ? DateTime.tryParse(attemptRaw)
          : lastCheckedAt;
      return _LocalCatalog(
        version: decoded['version']?.toString() ?? '0',
        lastAttemptAt: lastAttemptAt,
        lastCheckedAt: lastCheckedAt,
        items: items,
      );
    } catch (_) {
      return const _LocalCatalog();
    }
  }

  static Future<void> _writeLocalCatalog(
    String root, {
    required String version,
    required DateTime lastAttemptAt,
    required DateTime? lastCheckedAt,
    required List<_MirrorItem> items,
  }) async {
    final file = File('$root/$_catalogFileName');
    final temp = File('${file.path}.part');
    final payload = <String, dynamic>{
      'version': version,
      'last_attempt_at': lastAttemptAt.toUtc().toIso8601String(),
      'last_checked_at': lastCheckedAt?.toUtc().toIso8601String(),
      'wallpapers': items.map((item) => item.toJson()).toList(growable: false),
    };
    await temp.writeAsString(jsonEncode(payload), flush: true);
    if (await file.exists()) await file.delete();
    await temp.rename(file.path);
  }

  static List<WallpaperItem> _existingItems(
    String root,
    List<_MirrorItem> catalog,
  ) {
    final output = <WallpaperItem>[];
    for (final item in catalog) {
      final path = _absolutePath(root, item.localRelativePath);
      if (!File(path).existsSync()) continue;
      output.add(
        WallpaperItem(
          id: item.id,
          title: item.title,
          category: item.category,
          asset: path,
          tags: item.tags,
          signature: item.signature,
        ),
      );
    }
    return output;
  }

  static Future<void> _removeOrphans(
    String root,
    List<_MirrorItem> active,
  ) async {
    final keep = active
        .map((item) => _absolutePath(root, item.localRelativePath))
        .toSet();
    final mediaRoot = Directory('$root/media');
    if (!await mediaRoot.exists()) return;
    await for (final entity in mediaRoot.list(recursive: true)) {
      if (entity is File && !keep.contains(entity.path)) {
        try {
          await entity.delete();
        } catch (_) {
          // Eski dosya silinemese de uygulamayı engelleme.
        }
      }
    }
  }

  static String _absolutePath(String root, String relative) {
    final clean = relative
        .replaceAll('\\', '/')
        .split('/')
        .where((part) => part.isNotEmpty && part != '.' && part != '..')
        .join(Platform.pathSeparator);
    return '$root${Platform.pathSeparator}$clean';
  }
}

class _RemoteManifest {
  final String version;
  final List<_MirrorItem> items;
  const _RemoteManifest({required this.version, required this.items});
}

class _LocalCatalog {
  final String version;
  final DateTime? lastAttemptAt;
  final DateTime? lastCheckedAt;
  final List<_MirrorItem> items;
  const _LocalCatalog({
    this.version = '0',
    this.lastAttemptAt,
    this.lastCheckedAt,
    this.items = const [],
  });
}

class _SyncWork {
  final List<_MirrorItem> catalogItems;
  final int downloaded;
  final int reused;
  const _SyncWork({
    required this.catalogItems,
    required this.downloaded,
    required this.reused,
  });
}

class _MirrorItem {
  final String id;
  final String title;
  final String category;
  final String file;
  final String localRelativePath;
  final String signature;
  final String url;
  final List<String> tags;

  const _MirrorItem({
    required this.id,
    required this.title,
    required this.category,
    required this.file,
    required this.localRelativePath,
    required this.signature,
    required this.url,
    required this.tags,
  });

  static _MirrorItem? fromRemote(dynamic raw) {
    if (raw is! Map) return null;
    final id = raw['id']?.toString().trim() ?? '';
    final file = raw['file']?.toString().trim() ?? '';
    final category = raw['category']?.toString().trim() ?? '';
    final signature = raw['signature']?.toString().trim() ?? '';
    final url = raw['url']?.toString().trim() ?? '';
    if (!_validId(id) || !_validFile(file) || !_validCategory(category) ||
        signature.isEmpty || !url.startsWith('https://')) {
      return null;
    }
    final localPath = 'media/$category/$file';
    return _MirrorItem(
      id: id,
      title: _title(raw['title']?.toString(), id),
      category: _categoryLabel(raw['category_name'], category),
      file: file,
      localRelativePath: localPath,
      signature: signature,
      url: url,
      tags: _tags(raw['tags']),
    );
  }

  static _MirrorItem? fromLocal(dynamic raw) {
    if (raw is! Map) return null;
    final id = raw['id']?.toString().trim() ?? '';
    final file = raw['file']?.toString().trim() ?? '';
    final category = raw['category']?.toString().trim() ?? '';
    final localPath = raw['local_path']?.toString().trim() ?? '';
    final signature = raw['signature']?.toString().trim() ?? '';
    if (!_validId(id) || !_validFile(file) || !_validCategory(category) ||
        localPath.isEmpty || signature.isEmpty) {
      return null;
    }
    return _MirrorItem(
      id: id,
      title: _title(raw['title']?.toString(), id),
      category: category,
      file: file,
      localRelativePath: localPath,
      signature: signature,
      url: raw['url']?.toString() ?? '',
      tags: _tags(raw['tags']),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'category': category,
        'file': file,
        'local_path': localRelativePath,
        'signature': signature,
        'url': url,
        'tags': tags,
      };

  static bool _validId(String value) =>
      RegExp(r'^ELX-M-[A-Za-z0-9_-]+$').hasMatch(value);

  static bool _validFile(String value) =>
      RegExp(r'^ELX-M-[A-Za-z0-9_-]+\.(?:webp|jpg|jpeg|png)$', caseSensitive: false)
          .hasMatch(value);

  static bool _validCategory(String value) =>
      RegExp(r'^[A-Za-z0-9_-]+$').hasMatch(value);

  static String _categoryLabel(dynamic raw, String fallback) {
    final value = raw?.toString().trim() ?? '';
    return value.isEmpty ? fallback : value;
  }

  static String _title(String? raw, String id) {
    final value = raw?.trim() ?? '';
    return value.isEmpty ? id : value;
  }

  static List<String> _tags(dynamic raw) {
    if (raw is! List) return const [];
    return raw
        .map((item) => item.toString().trim())
        .where((item) => item.isNotEmpty)
        .take(12)
        .toList(growable: false);
  }
}
