import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';

import '../models/wallpaper.dart';
import 'http_policy.dart';

class MirrorSyncProgress {
  final int total;
  final int processed;
  final int downloaded;
  final int reused;
  final int failed;
  final String currentId;

  const MirrorSyncProgress({
    required this.total,
    required this.processed,
    required this.downloaded,
    required this.reused,
    required this.failed,
    required this.currentId,
  });

  double get fraction => total <= 0 ? 0 : processed / total;
}

class MirrorSyncResult {
  final List<WallpaperItem> wallpapers;
  final int downloaded;
  final int reused;
  final int failed;
  final int removed;
  final int manifestCount;
  final bool checkedNetwork;
  final bool changed;
  final DateTime? lastCheckedAt;
  final String message;

  const MirrorSyncResult({
    required this.wallpapers,
    required this.downloaded,
    required this.reused,
    required this.failed,
    required this.removed,
    required this.manifestCount,
    required this.checkedNetwork,
    required this.changed,
    required this.lastCheckedAt,
    required this.message,
  });
}

class MirrorCleanupResult {
  final int removedFiles;
  final int removedBytes;

  const MirrorCleanupResult({
    required this.removedFiles,
    required this.removedBytes,
  });
}

class MirrorSyncService {
  static const _channel = MethodChannel('com.elxvro.wallpaper/channel');
  static const String manifestEndpoint =
      'https://elxvro.com/app-api/v1/media-manifest.php';
  static const Duration checkInterval = Duration(hours: 6);
  static const Duration requestTimeout = Duration(seconds: 18);
  static const int maxImageBytes = 25 * 1024 * 1024;
  static const String _catalogFileName = 'mirror-catalog.json';
  static final Map<String, Future<WallpaperItem>> _localRequests =
      <String, Future<WallpaperItem>>{};

  static Future<MirrorSyncResult> load({
    required List<WallpaperItem> fallback,
    bool forceRefresh = false,
    void Function(MirrorSyncProgress progress)? onProgress,
  }) async {
    final root = await _mirrorDirectory();
    final localCatalog = await _readLocalCatalog(root);
    final localItems = _existingItems(root, localCatalog.items);

    if (!forceRefresh &&
        localCatalog.items.isNotEmpty &&
        localCatalog.lastCheckedAt != null) {
      final age = DateTime.now().difference(localCatalog.lastCheckedAt!);
      if (!age.isNegative && age < checkInterval) {
        final visibleItems = await _fastVisibleItems(
          root,
          localCatalog.items,
          localCatalog.items,
        );
        final localReady = visibleItems.where((item) => item.isLocalFile).length;
        return MirrorSyncResult(
          wallpapers: visibleItems.isNotEmpty ? visibleItems : fallback,
          downloaded: 0,
          reused: localReady,
          failed: 0,
          removed: 0,
          manifestCount: localCatalog.items.length,
          checkedNetwork: false,
          changed: false,
          lastCheckedAt: localCatalog.lastCheckedAt,
          message: '${localCatalog.items.length} görsel hazır • '
              '$localReady çevrimdışı • sunucu kontrolü önbellekten.',
        );
      }
    }

    if (forceRefresh) {
      return _fullSync(
        root,
        localCatalog,
        fallback: fallback,
        onProgress: onProgress,
      );
    }

    try {
      final remote = await _fetchManifest();
      if (remote.items.isEmpty && localCatalog.items.isNotEmpty) {
        throw const FormatException(
          'Boş manifest yerel kataloğun üzerine yazılmadı.',
        );
      }

      final visibleItems = await _fastVisibleItems(
        root,
        localCatalog.items,
        remote.items,
      );
      final checkedAt = DateTime.now();
      await _writeLocalCatalog(
        root,
        version: remote.version,
        lastAttemptAt: checkedAt,
        lastCheckedAt: checkedAt,
        items: remote.items,
      );

      final localReady = visibleItems.where((item) => item.isLocalFile).length;
      final changed = remote.version != localCatalog.version ||
          remote.items.length != localCatalog.items.length;
      final message = localReady == remote.items.length && remote.items.isNotEmpty
          ? '${remote.items.length} görsel cihazda hazır.'
          : '${remote.items.length} görsel hazır • $localReady çevrimdışı.';

      return MirrorSyncResult(
        wallpapers: visibleItems.isNotEmpty ? visibleItems : fallback,
        downloaded: 0,
        reused: localReady,
        failed: 0,
        removed: 0,
        manifestCount: remote.items.length,
        checkedNetwork: true,
        changed: changed,
        lastCheckedAt: checkedAt,
        message: message,
      );
    } catch (_) {
      return MirrorSyncResult(
        wallpapers: localItems.isNotEmpty ? localItems : fallback,
        downloaded: 0,
        reused: localItems.length,
        failed: 0,
        removed: 0,
        manifestCount: localCatalog.items.length,
        checkedNetwork: true,
        changed: false,
        lastCheckedAt: localCatalog.lastCheckedAt,
        message: localItems.isNotEmpty
            ? 'Çevrimdışı • cihazdaki yerel kopyalar kullanılıyor.'
            : 'Sunucuya ulaşılamadı; paket içi görseller kullanılıyor.',
      );
    }
  }

  static Future<MirrorSyncResult> _fullSync(
    String root,
    _LocalCatalog localCatalog, {
    required List<WallpaperItem> fallback,
    void Function(MirrorSyncProgress progress)? onProgress,
  }) async {
    final localItems = _existingItems(root, localCatalog.items);
    try {
      final remote = await _fetchManifest();
      if (remote.items.isEmpty && localCatalog.items.isNotEmpty) {
        throw const FormatException(
          'Boş manifest yerel kataloğun üzerine yazılmadı.',
        );
      }

      onProgress?.call(
        MirrorSyncProgress(
          total: remote.items.length,
          processed: 0,
          downloaded: 0,
          reused: 0,
          failed: 0,
          currentId: '',
        ),
      );

      final synced = await _sync(
        root,
        localCatalog,
        remote,
        onProgress: onProgress,
      );
      final attemptedAt = DateTime.now();
      final fullySuccessful = synced.failed == 0 &&
          synced.catalogItems.length == remote.items.length;
      final successfulAt = fullySuccessful
          ? attemptedAt
          : localCatalog.lastCheckedAt;

      await _writeLocalCatalog(
        root,
        version: remote.version,
        lastAttemptAt: attemptedAt,
        lastCheckedAt: successfulAt,
        items: synced.catalogItems,
      );

      var removed = 0;
      if (fullySuccessful) {
        final cleanup = await _removeOrphans(root, synced.catalogItems);
        removed = cleanup.removedFiles;
      }

      final syncedItems = _existingItems(root, synced.catalogItems);
      final changed = synced.downloaded > 0 ||
          removed > 0 ||
          synced.catalogItems.length != localCatalog.items.length ||
          remote.version != localCatalog.version;

      String message;
      if (syncedItems.isEmpty) {
        message = 'Sunucuda yerel kopyaya uygun görsel bulunamadı.';
      } else if (synced.failed > 0) {
        message =
            '${synced.downloaded} güncellendi, ${synced.failed} dosya sonraki eşitlemeye kaldı.';
      } else if (synced.downloaded > 0) {
        message = '${synced.downloaded} yeni/değişen görsel çevrimdışı hazırlandı.';
      } else if (removed > 0) {
        message = 'Görseller güncel • $removed eski yerel dosya temizlendi.';
      } else {
        message = 'Tüm görseller çevrimdışı hazır.';
      }

      return MirrorSyncResult(
        wallpapers: syncedItems.isNotEmpty ? syncedItems : fallback,
        downloaded: synced.downloaded,
        reused: synced.reused,
        failed: synced.failed,
        removed: removed,
        manifestCount: remote.items.length,
        checkedNetwork: true,
        changed: changed,
        lastCheckedAt: successfulAt,
        message: message,
      );
    } catch (_) {
      return MirrorSyncResult(
        wallpapers: localItems.isNotEmpty ? localItems : fallback,
        downloaded: 0,
        reused: localItems.length,
        failed: 0,
        removed: 0,
        manifestCount: localCatalog.items.length,
        checkedNetwork: true,
        changed: false,
        lastCheckedAt: localCatalog.lastCheckedAt,
        message: localItems.isNotEmpty
            ? 'Sunucuya ulaşılamadı; cihazdaki yerel kopyalar kullanılıyor.'
            : 'Sunucuya ulaşılamadı; paket içi görseller kullanılıyor.',
      );
    }
  }

  static Future<List<WallpaperItem>> _fastVisibleItems(
    String root,
    List<_MirrorItem> previousItems,
    List<_MirrorItem> remoteItems,
  ) async {
    final previous = {for (final item in previousItems) item.id: item};
    final output = <WallpaperItem>[];

    for (final item in remoteItems) {
      final target = File(_absolutePath(root, item.localRelativePath));
      final old = previous[item.id];
      final targetExists = await target.exists();
      final reusable = targetExists &&
          old != null &&
          old.signature == item.signature &&
          old.localRelativePath == item.localRelativePath;

      if (reusable) {
        output.add(_toWallpaper(item, target.path));
        continue;
      }

      if (targetExists) {
        try {
          await target.delete();
        } catch (_) {
          // Eski kopya silinemezse ağ sürümü gösterilir.
        }
      }

      if (old != null && old.localRelativePath != item.localRelativePath) {
        final oldFile = File(_absolutePath(root, old.localRelativePath));
        try {
          if (await oldFile.exists()) await oldFile.delete();
        } catch (_) {
          // Eski kategori kopyası daha sonra güvenli temizlikte kaldırılır.
        }
      }

      output.add(_toWallpaper(item, item.url));
    }

    return output;
  }

  static Future<WallpaperItem> ensureLocal(WallpaperItem item) {
    if (!item.isRemoteUrl) return Future<WallpaperItem>.value(item);
    return _localRequests.putIfAbsent(item.asset, () async {
      try {
        return await _ensureLocalImpl(item);
      } finally {
        _localRequests.remove(item.asset);
      }
    });
  }

  static Future<WallpaperItem> _ensureLocalImpl(WallpaperItem item) async {
    final uri = Uri.tryParse(item.asset);
    if (uri == null ||
        uri.scheme != 'https' ||
        uri.host.toLowerCase() != 'elxvro.com' ||
        uri.pathSegments.length < 2) {
      throw const FormatException('Geçersiz ELXVRO medya adresi.');
    }

    final file = uri.pathSegments.last;
    final category = uri.pathSegments[uri.pathSegments.length - 2];
    if (!_MirrorItem._validFile(file) || !_MirrorItem._validCategory(category)) {
      throw const FormatException('Geçersiz ELXVRO medya yolu.');
    }

    final root = await _mirrorDirectory();
    final target = File(_absolutePath(root, 'media/$category/$file'));
    if (!await target.exists() || await target.length() <= 0) {
      await _download(item.asset, target);
    }
    return item.copyWith(asset: target.path);
  }

  static WallpaperItem _toWallpaper(_MirrorItem item, String asset) {
    return WallpaperItem(
      id: item.id,
      title: item.title,
      category: item.category,
      asset: asset,
      tags: item.tags,
      signature: item.signature,
    );
  }

  static Future<MirrorCleanupResult> cleanupLocalMedia() async {
    final root = await _mirrorDirectory();
    final catalog = await _readLocalCatalog(root);
    return _removeOrphans(root, catalog.items, removePartFiles: true);
  }

  static Future<String> _mirrorDirectory() async {
    try {
      final path = await _channel.invokeMethod<String>('getMirrorDirectory');
      if (path != null && path.isNotEmpty) {
        final dir = Directory(path);
        await dir.create(recursive: true);
        return dir.path;
      }
    } on MissingPluginException {
      // Test/Android dışı ortam.
    } on PlatformException {
      // Paket içi fallback kullanılacak.
    }
    return Directory.systemTemp.createTempSync('elxvro-mirror-test-').path;
  }

  static Future<_RemoteManifest> _fetchManifest() async {
    final client = HttpClient()..connectionTimeout = requestTimeout;
    try {
      await ElxvroRequestGate.waitTurn();
      final request = await client
          .getUrl(Uri.parse(manifestEndpoint))
          .timeout(requestTimeout);
      request.headers.set(HttpHeaders.acceptHeader, 'application/json');
      request.headers.set(
        HttpHeaders.userAgentHeader,
        'ELXVRO-Android/1.0.21 instant-gallery',
      );
      final response = await request.close().timeout(requestTimeout);
      if (response.statusCode == 403 || response.statusCode == 429) {
        ElxvroRequestGate.penalize(
          response.statusCode,
          retryAfter: response.headers.value('retry-after'),
        );
      }
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw HttpException('Manifest HTTP ${response.statusCode}');
      }
      final body = await response
          .transform(utf8.decoder)
          .join()
          .timeout(requestTimeout);
      final decoded = jsonDecode(body);
      if (decoded is! Map) throw const FormatException('Manifest geçersiz.');
      final rawItems = decoded['wallpapers'];
      if (rawItems is! List) {
        throw const FormatException('wallpapers listesi yok.');
      }
      final items = <_MirrorItem>[];
      final ids = <String>{};
      for (final raw in rawItems.take(5000)) {
        final item = _MirrorItem.fromRemote(raw);
        if (item == null || !ids.add(item.id)) continue;
        items.add(item);
      }
      final version = decoded['version']?.toString() ?? '0';
      return _RemoteManifest(version: version, items: items);
    } finally {
      client.close(force: true);
    }
  }

  static Future<_SyncWork> _sync(
    String root,
    _LocalCatalog local,
    _RemoteManifest remote, {
    void Function(MirrorSyncProgress progress)? onProgress,
  }) async {
    final previous = {for (final item in local.items) item.id: item};
    final output = <_MirrorItem>[];
    var downloaded = 0;
    var reused = 0;
    var failed = 0;
    var processed = 0;

    for (final remoteItem in remote.items) {
      final old = previous[remoteItem.id];
      final target = File(_absolutePath(root, remoteItem.localRelativePath));
      final unchanged = old != null &&
          old.signature == remoteItem.signature &&
          await target.exists();
      if (unchanged) {
        output.add(remoteItem);
        reused++;
        processed++;
        onProgress?.call(
          MirrorSyncProgress(
            total: remote.items.length,
            processed: processed,
            downloaded: downloaded,
            reused: reused,
            failed: failed,
            currentId: remoteItem.id,
          ),
        );
        continue;
      }

      try {
        await _download(remoteItem.url, target);
        output.add(remoteItem);
        downloaded++;
      } catch (_) {
        failed++;
        if (old != null) {
          final oldFile = File(_absolutePath(root, old.localRelativePath));
          if (await oldFile.exists()) {
            output.add(old);
            reused++;
          }
        }
      }

      processed++;
      onProgress?.call(
        MirrorSyncProgress(
          total: remote.items.length,
          processed: processed,
          downloaded: downloaded,
          reused: reused,
          failed: failed,
          currentId: remoteItem.id,
        ),
      );
    }

    return _SyncWork(
      catalogItems: output,
      downloaded: downloaded,
      reused: reused,
      failed: failed,
    );
  }

  static Future<void> _download(String url, File target) async {
    final uri = Uri.parse(url);
    if (uri.scheme != 'https' || uri.host.toLowerCase() != 'elxvro.com') {
      throw HttpException('Yalnızca ELXVRO HTTPS medya adresleri kabul edilir.');
    }
    await target.parent.create(recursive: true);
    final temp = File('${target.path}.part');
    if (await temp.exists()) await temp.delete();

    final client = HttpClient()..connectionTimeout = requestTimeout;
    try {
      await ElxvroRequestGate.waitTurn();
      final request = await client.getUrl(uri).timeout(requestTimeout);
      request.headers.set(
        HttpHeaders.userAgentHeader,
        'ELXVRO-Android/1.0.21 media-copy',
      );
      final response = await request.close().timeout(requestTimeout);
      if (response.statusCode == 403 || response.statusCode == 429) {
        ElxvroRequestGate.penalize(
          response.statusCode,
          retryAfter: response.headers.value('retry-after'),
        );
      }
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw HttpException('Medya HTTP ${response.statusCode}');
      }
      final contentLength = response.contentLength;
      if (contentLength > maxImageBytes) {
        throw HttpException('Görsel dosyası çok büyük.');
      }
      final sink = temp.openWrite();
      var received = 0;
      try {
        await for (final chunk in response.timeout(requestTimeout)) {
          received += chunk.length;
          if (received > maxImageBytes) {
            throw HttpException('Görsel dosyası çok büyük.');
          }
          sink.add(chunk);
        }
      } finally {
        await sink.close();
      }
      if (received == 0) throw HttpException('Boş görsel dosyası.');
      if (await target.exists()) await target.delete();
      await temp.rename(target.path);
    } finally {
      client.close(force: true);
      if (await temp.exists()) await temp.delete();
    }
  }

  static Future<_LocalCatalog> _readLocalCatalog(String root) async {
    final file = File('$root/$_catalogFileName');
    try {
      if (!await file.exists()) return const _LocalCatalog();
      final decoded = jsonDecode(await file.readAsString());
      if (decoded is! Map) return const _LocalCatalog();
      final rawItems = decoded['wallpapers'];
      final items = <_MirrorItem>[];
      if (rawItems is List) {
        for (final raw in rawItems) {
          final item = _MirrorItem.fromLocal(raw);
          if (item != null) items.add(item);
        }
      }
      final checkedRaw = decoded['last_checked_at'];
      final attemptRaw = decoded['last_attempt_at'];
      final lastCheckedAt =
          checkedRaw is String ? DateTime.tryParse(checkedRaw) : null;
      final lastAttemptAt = attemptRaw is String
          ? DateTime.tryParse(attemptRaw)
          : lastCheckedAt;
      return _LocalCatalog(
        schema: decoded['catalog_schema'] is int
            ? decoded['catalog_schema'] as int
            : 1,
        version: decoded['version']?.toString() ?? '0',
        lastAttemptAt: lastAttemptAt,
        lastCheckedAt: lastCheckedAt,
        items: items,
      );
    } catch (_) {
      return const _LocalCatalog();
    }
  }

  static Future<void> _writeLocalCatalog(
    String root, {
    required String version,
    required DateTime lastAttemptAt,
    required DateTime? lastCheckedAt,
    required List<_MirrorItem> items,
  }) async {
    final file = File('$root/$_catalogFileName');
    final temp = File('${file.path}.part');
    final payload = <String, dynamic>{
      'catalog_schema': 2,
      'version': version,
      'last_attempt_at': lastAttemptAt.toUtc().toIso8601String(),
      'last_checked_at': lastCheckedAt?.toUtc().toIso8601String(),
      'wallpapers': items.map((item) => item.toJson()).toList(growable: false),
    };
    await temp.writeAsString(jsonEncode(payload), flush: true);
    if (await file.exists()) await file.delete();
    await temp.rename(file.path);
  }

  static List<WallpaperItem> _existingItems(
    String root,
    List<_MirrorItem> catalog,
  ) {
    final output = <WallpaperItem>[];
    for (final item in catalog) {
      final path = _absolutePath(root, item.localRelativePath);
      if (!File(path).existsSync()) continue;
      output.add(
        WallpaperItem(
          id: item.id,
          title: item.title,
          category: item.category,
          asset: path,
          tags: item.tags,
          signature: item.signature,
        ),
      );
    }
    return output;
  }

  static Future<MirrorCleanupResult> _removeOrphans(
    String root,
    List<_MirrorItem> active, {
    bool removePartFiles = false,
  }) async {
    final keep = active
        .map((item) => _absolutePath(root, item.localRelativePath))
        .toSet();
    final mediaRoot = Directory('$root/media');
    if (!await mediaRoot.exists()) {
      return const MirrorCleanupResult(removedFiles: 0, removedBytes: 0);
    }

    var removedFiles = 0;
    var removedBytes = 0;
    await for (final entity in mediaRoot.list(recursive: true)) {
      if (entity is! File) continue;
      final isPart = entity.path.endsWith('.part');
      final orphan = !keep.contains(entity.path);
      if (!orphan && !(removePartFiles && isPart)) continue;
      if (!removePartFiles && isPart) continue;
      try {
        final length = await entity.length();
        await entity.delete();
        removedFiles++;
        removedBytes += length;
      } catch (_) {
        // Temizlik hatası ana eşitlemeyi engellememeli.
      }
    }

    await _deleteEmptyDirectories(mediaRoot);
    return MirrorCleanupResult(
      removedFiles: removedFiles,
      removedBytes: removedBytes,
    );
  }

  static Future<void> _deleteEmptyDirectories(Directory root) async {
    final dirs = <Directory>[];
    await for (final entity in root.list(recursive: true, followLinks: false)) {
      if (entity is Directory) dirs.add(entity);
    }
    dirs.sort((a, b) => b.path.length.compareTo(a.path.length));
    for (final dir in dirs) {
      try {
        if (await dir.list().isEmpty) await dir.delete();
      } catch (_) {
        // Dolu veya erişilemeyen klasör korunur.
      }
    }
  }

  static String _absolutePath(String root, String relative) {
    final clean = relative
        .replaceAll('\\', '/')
        .split('/')
        .where((part) => part.isNotEmpty && part != '.' && part != '..')
        .join(Platform.pathSeparator);
    return '$root${Platform.pathSeparator}$clean';
  }
}

class _RemoteManifest {
  final String version;
  final List<_MirrorItem> items;
  const _RemoteManifest({required this.version, required this.items});
}

class _LocalCatalog {
  final int schema;
  final String version;
  final DateTime? lastAttemptAt;
  final DateTime? lastCheckedAt;
  final List<_MirrorItem> items;
  const _LocalCatalog({
    this.schema = 1,
    this.version = '0',
    this.lastAttemptAt,
    this.lastCheckedAt,
    this.items = const [],
  });
}

class _SyncWork {
  final List<_MirrorItem> catalogItems;
  final int downloaded;
  final int reused;
  final int failed;
  const _SyncWork({
    required this.catalogItems,
    required this.downloaded,
    required this.reused,
    required this.failed,
  });
}

class _MirrorItem {
  final String id;
  final String title;
  final String category;
  final String file;
  final String localRelativePath;
  final String signature;
  final String url;
  final List<String> tags;

  const _MirrorItem({
    required this.id,
    required this.title,
    required this.category,
    required this.file,
    required this.localRelativePath,
    required this.signature,
    required this.url,
    required this.tags,
  });

  static _MirrorItem? fromRemote(dynamic raw) {
    if (raw is! Map) return null;
    final id = raw['id']?.toString().trim() ?? '';
    final file = raw['file']?.toString().trim() ?? '';
    final category = raw['category']?.toString().trim() ?? '';
    final signature = raw['signature']?.toString().trim() ?? '';
    final url = raw['url']?.toString().trim() ?? '';
    if (!_validId(id) ||
        !_validFile(file) ||
        !_validCategory(category) ||
        signature.isEmpty ||
        !url.startsWith('https://')) {
      return null;
    }
    final localPath = 'media/$category/$file';
    return _MirrorItem(
      id: id,
      title: _title(raw['title']?.toString(), id),
      category: category,
      file: file,
      localRelativePath: localPath,
      signature: signature,
      url: url,
      tags: _tags(raw['tags']),
    );
  }

  static _MirrorItem? fromLocal(dynamic raw) {
    if (raw is! Map) return null;
    final id = raw['id']?.toString().trim() ?? '';
    final file = raw['file']?.toString().trim() ?? '';
    final category = raw['category']?.toString().trim() ?? '';
    final localPath = raw['local_path']?.toString().trim() ?? '';
    final signature = raw['signature']?.toString().trim() ?? '';
    if (!_validId(id) ||
        !_validFile(file) ||
        !_validCategory(category) ||
        localPath.isEmpty ||
        signature.isEmpty) {
      return null;
    }
    return _MirrorItem(
      id: id,
      title: _title(raw['title']?.toString(), id),
      category: category,
      file: file,
      localRelativePath: localPath,
      signature: signature,
      url: raw['url']?.toString() ?? '',
      tags: _tags(raw['tags']),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'category': category,
        'file': file,
        'local_path': localRelativePath,
        'signature': signature,
        'url': url,
        'tags': tags,
      };

  static bool _validId(String value) =>
      RegExp(r'^ELX-M-[A-Za-z0-9_-]+$').hasMatch(value);

  static bool _validFile(String value) {
    if (value.toLowerCase().contains('_thumb.')) return false;
    return RegExp(
      r'^ELX-M-[A-Za-z0-9_-]+\.(?:webp|jpg|jpeg|png)$',
      caseSensitive: false,
    ).hasMatch(value);
  }

  static bool _validCategory(String value) =>
      RegExp(r'^[A-Za-z0-9_-]+$').hasMatch(value);

  static String _title(String? raw, String id) {
    final value = raw?.trim() ?? '';
    return value.isEmpty ? id : value;
  }

  static List<String> _tags(dynamic raw) {
    if (raw is! List) return const [];
    return raw
        .map((item) => item.toString().trim())
        .where((item) => item.isNotEmpty)
        .take(12)
        .toList(growable: false);
  }
}
