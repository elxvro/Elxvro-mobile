import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';

import '../models/category_item.dart';

class CategoryLoadResult {
  final List<CategoryItem> categories;
  final String source;
  final DateTime? updatedAt;
  final bool stale;

  const CategoryLoadResult({
    required this.categories,
    required this.source,
    required this.updatedAt,
    required this.stale,
  });
}

class CategoryService {
  static const _channel = MethodChannel('com.elxvro.wallpaper/channel');
  static const String endpoint = 'https://elxvro.com/api/v1/categories.php';
  static const Duration cacheLifetime = Duration(hours: 24);
  static const Duration requestTimeout = Duration(seconds: 6);

  static Future<CategoryLoadResult> load({
    required List<CategoryItem> fallback,
    bool forceRefresh = false,
  }) async {
    final cached = await _readCache();
    final now = DateTime.now();
    final cacheAge = cached.updatedAt == null
        ? null
        : now.difference(cached.updatedAt!);
    final cacheFresh = cacheAge != null &&
        !cacheAge.isNegative &&
        cacheAge < cacheLifetime;

    if (!forceRefresh && cached.categories.isNotEmpty && cacheFresh) {
      return CategoryLoadResult(
        categories: cached.categories,
        source: 'cache',
        updatedAt: cached.updatedAt,
        stale: false,
      );
    }

    try {
      final networkCategories = await _fetchFromSite();
      if (networkCategories.isNotEmpty) {
        final updatedAt = DateTime.now();
        await _saveCache(networkCategories, updatedAt);
        return CategoryLoadResult(
          categories: networkCategories,
          source: 'site',
          updatedAt: updatedAt,
          stale: false,
        );
      }
    } catch (_) {
      // Kategori isteği uygulamayı engellemez. Görseller daima APK içinden gelir.
    }

    if (cached.categories.isNotEmpty) {
      return CategoryLoadResult(
        categories: cached.categories,
        source: 'cache',
        updatedAt: cached.updatedAt,
        stale: true,
      );
    }

    return CategoryLoadResult(
      categories: fallback,
      source: 'local',
      updatedAt: null,
      stale: true,
    );
  }

  static Future<List<CategoryItem>> _fetchFromSite() async {
    final client = HttpClient()..connectionTimeout = requestTimeout;
    try {
      final request = await client
          .getUrl(Uri.parse(endpoint))
          .timeout(requestTimeout);
      request.headers.set(HttpHeaders.acceptHeader, 'application/json');
      request.headers.set(
        HttpHeaders.userAgentHeader,
        'ELXVRO-Android/1.0.11 categories-only',
      );
      final response = await request.close().timeout(requestTimeout);
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw HttpException('Kategori API HTTP ${response.statusCode}');
      }
      final body = await response
          .transform(utf8.decoder)
          .join()
          .timeout(requestTimeout);
      return _parseCategories(jsonDecode(body));
    } finally {
      client.close(force: true);
    }
  }

  static List<CategoryItem> _parseCategories(dynamic decoded) {
    dynamic listCandidate = decoded;
    if (decoded is Map) {
      for (final key in const ['categories', 'data', 'items', 'results']) {
        final value = decoded[key];
        if (value is List) {
          listCandidate = value;
          break;
        }
        if (value is Map) {
          for (final nestedKey in const ['categories', 'items', 'data']) {
            final nested = value[nestedKey];
            if (nested is List) {
              listCandidate = nested;
              break;
            }
          }
          if (listCandidate is List) break;
        }
      }
    }
    if (listCandidate is! List) return const <CategoryItem>[];

    final seen = <String>{};
    final output = <CategoryItem>[];
    for (final raw in listCandidate) {
      final item = CategoryItem.fromJson(raw);
      if (item == null || !seen.add(item.slug)) continue;
      output.add(item);
    }
    return output;
  }

  static Future<_CategoryCache> _readCache() async {
    try {
      final raw = await _channel.invokeMapMethod<String, dynamic>(
        'loadCategoryCache',
      );
      final jsonText = raw?['json'];
      final updatedAtMs = raw?['updatedAt'];
      if (jsonText is! String || jsonText.isEmpty) {
        return const _CategoryCache();
      }
      final decoded = jsonDecode(jsonText);
      final categories = _parseCategories(decoded);
      final updatedAt = updatedAtMs is int && updatedAtMs > 0
          ? DateTime.fromMillisecondsSinceEpoch(updatedAtMs)
          : null;
      return _CategoryCache(categories: categories, updatedAt: updatedAt);
    } on MissingPluginException {
      return const _CategoryCache();
    } on PlatformException {
      return const _CategoryCache();
    } on FormatException {
      return const _CategoryCache();
    }
  }

  static Future<void> _saveCache(
    List<CategoryItem> categories,
    DateTime updatedAt,
  ) async {
    final jsonText = jsonEncode(
      categories.map((item) => item.toJson()).toList(growable: false),
    );
    try {
      await _channel.invokeMethod<void>('saveCategoryCache', {
        'json': jsonText,
        'updatedAt': updatedAt.millisecondsSinceEpoch,
      });
    } on MissingPluginException {
      // Android dışı test ortamında cache atlanır.
    } on PlatformException {
      // Cache yazma hatası uygulama kullanımını engellemez.
    }
  }
}

class _CategoryCache {
  final List<CategoryItem> categories;
  final DateTime? updatedAt;

  const _CategoryCache({
    this.categories = const <CategoryItem>[],
    this.updatedAt,
  });
}
