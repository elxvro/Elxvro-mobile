import 'dart:async';
import 'dart:convert';
import 'dart:io';

class AppAuthAccount {
  final String id;
  final String email;
  final String name;
  final String avatarUrl;
  final String status;
  final String legalVersion;
  final int loginCount;
  final DateTime? firstLoginAt;
  final DateTime? lastLoginAt;

  const AppAuthAccount({
    required this.id,
    required this.email,
    required this.name,
    required this.avatarUrl,
    required this.status,
    required this.legalVersion,
    required this.loginCount,
    required this.firstLoginAt,
    required this.lastLoginAt,
  });

  factory AppAuthAccount.fromJson(Map<String, dynamic> json) => AppAuthAccount(
        id: '${json['id'] ?? ''}',
        email: '${json['email'] ?? ''}',
        name: '${json['name'] ?? ''}',
        avatarUrl: '${json['avatar_url'] ?? ''}',
        status: '${json['status'] ?? 'active'}',
        legalVersion: '${json['legal_version'] ?? ''}',
        loginCount: _asInt(json['login_count']),
        firstLoginAt: _asDateTime(json['first_login_at']),
        lastLoginAt: _asDateTime(json['last_login_at']),
      );

  static int _asInt(dynamic value) {
    if (value is int) return value;
    return int.tryParse('$value') ?? 0;
  }

  static DateTime? _asDateTime(dynamic value) {
    final text = '${value ?? ''}'.trim();
    if (text.isEmpty || text == 'null') return null;
    return DateTime.tryParse(text.replaceFirst(' ', 'T'));
  }
}

class AuthServerException implements Exception {
  final String code;
  final String message;

  const AuthServerException(this.code, this.message);

  @override
  String toString() => message;
}

class AuthService {
  static const String googleWebClientId =
      '227765065065-3r92i04nkfc3nbnfs3hu28uf5jpvl7c4.apps.googleusercontent.com';
  static const String _loginEndpoint =
      'https://elxvro.com/app-api/v1/auth/google-login.php';
  static const String _deleteEndpoint =
      'https://elxvro.com/app-api/v1/auth/delete-account.php';
  static const Duration _timeout = Duration(seconds: 12);

  static Future<AppAuthAccount> loginWithGoogle({
    required String idToken,
    required String legalVersion,
  }) async {
    final decoded = await _post(
      _loginEndpoint,
      <String, dynamic>{
        'id_token': idToken,
        'legal_version': legalVersion,
      },
    );
    final rawAccount = decoded['account'];
    if (rawAccount is! Map) {
      throw const AuthServerException(
        'INVALID_RESPONSE',
        'ELXVRO hesap servisi geçersiz yanıt döndürdü.',
      );
    }
    return AppAuthAccount.fromJson(Map<String, dynamic>.from(rawAccount));
  }

  static Future<void> deleteAccount({required String idToken}) async {
    await _post(
      _deleteEndpoint,
      <String, dynamic>{'id_token': idToken},
    );
  }

  static Future<Map<String, dynamic>> _post(
    String endpoint,
    Map<String, dynamic> body,
  ) async {
    final uri = Uri.parse(endpoint);
    if (uri.scheme != 'https' || uri.host.toLowerCase() != 'elxvro.com') {
      throw const AuthServerException(
        'INVALID_ENDPOINT',
        'Geçersiz ELXVRO hesap servisi adresi.',
      );
    }

    final client = HttpClient()..connectionTimeout = _timeout;
    try {
      final request = await client.postUrl(uri).timeout(_timeout);
      request.headers.set(HttpHeaders.acceptHeader, 'application/json');
      request.headers.set(HttpHeaders.contentTypeHeader, 'application/json');
      request.headers.set(
        HttpHeaders.userAgentHeader,
        'ELXVRO-Android/1.0.20 auth',
      );
      request.write(jsonEncode(body));

      final response = await request.close().timeout(_timeout);
      final responseText = await response
          .transform(utf8.decoder)
          .join()
          .timeout(_timeout);

      Map<String, dynamic> decoded;
      try {
        final value = jsonDecode(responseText);
        if (value is! Map) throw const FormatException();
        decoded = Map<String, dynamic>.from(value);
      } on FormatException {
        throw AuthServerException(
          'HTTP_${response.statusCode}',
          'ELXVRO hesap servisi geçersiz yanıt döndürdü.',
        );
      }

      if (response.statusCode < 200 || response.statusCode >= 300) {
        final rawError = decoded['error'];
        if (rawError is Map) {
          final error = Map<String, dynamic>.from(rawError);
          throw AuthServerException(
            '${error['code'] ?? 'SERVER_ERROR'}',
            '${error['message'] ?? 'ELXVRO hesap servisine bağlanılamadı.'}',
          );
        }
        throw AuthServerException(
          'HTTP_${response.statusCode}',
          'ELXVRO hesap servisine bağlanılamadı.',
        );
      }

      if (decoded['ok'] != true) {
        throw const AuthServerException(
          'SERVER_ERROR',
          'ELXVRO hesap işlemi tamamlanamadı.',
        );
      }
      return decoded;
    } on SocketException {
      throw const AuthServerException(
        'NETWORK_ERROR',
        'ELXVRO hesap sunucusuna ulaşılamadı. İnternet bağlantını kontrol et.',
      );
    } on TimeoutException {
      throw const AuthServerException(
        'TIMEOUT',
        'ELXVRO hesap sunucusu zaman aşımına uğradı. Tekrar dene.',
      );
    } finally {
      client.close(force: true);
    }
  }
}
