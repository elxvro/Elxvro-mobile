import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:google_sign_in/google_sign_in.dart';

class DriveBackupInfo {
  final String fileId;
  final String name;
  final DateTime? modifiedAt;
  final int? size;

  const DriveBackupInfo({
    required this.fileId,
    required this.name,
    required this.modifiedAt,
    required this.size,
  });
}

class DriveBackupException implements Exception {
  final String message;
  const DriveBackupException(this.message);

  @override
  String toString() => message;
}

class DriveBackupService {
  static const String fileName = 'ELXVRO Backup.json';
  static const List<String> scopes = <String>[
    'https://www.googleapis.com/auth/drive.file',
  ];
  static const Duration _timeout = Duration(seconds: 20);

  static Future<DriveBackupInfo?> status(GoogleSignInAccount account) async {
    final authorization =
        await account.authorizationClient.authorizationForScopes(scopes);
    if (authorization == null) return null;
    return _findBackup(authorization.accessToken);
  }

  static Future<DriveBackupInfo> backup({
    required GoogleSignInAccount account,
    required Map<String, dynamic> data,
  }) async {
    final authorization = await account.authorizationClient.authorizeScopes(scopes);
    final token = authorization.accessToken;
    var info = await _findBackup(token);
    info ??= await _createFile(token);
    await _uploadContent(token, info.fileId, data);
    return (await _findBackup(token)) ?? info;
  }

  static Future<Map<String, dynamic>> restore({
    required GoogleSignInAccount account,
  }) async {
    final authorization = await account.authorizationClient.authorizeScopes(scopes);
    final token = authorization.accessToken;
    final info = await _findBackup(token);
    if (info == null) {
      throw const DriveBackupException('Google Drive üzerinde ELXVRO yedeği bulunamadı.');
    }

    final response = await _request(
      'GET',
      Uri.https('www.googleapis.com', '/drive/v3/files/${info.fileId}', {
        'alt': 'media',
      }),
      token,
    );
    final decoded = jsonDecode(response);
    if (decoded is! Map) {
      throw const DriveBackupException('Drive yedeği okunamadı.');
    }
    return Map<String, dynamic>.from(decoded);
  }

  static Future<DriveBackupInfo?> _findBackup(String token) async {
    final query = "name = '$fileName' and trashed = false";
    final response = await _request(
      'GET',
      Uri.https('www.googleapis.com', '/drive/v3/files', {
        'q': query,
        'spaces': 'drive',
        'pageSize': '1',
        'orderBy': 'modifiedTime desc',
        'fields': 'files(id,name,modifiedTime,size)',
      }),
      token,
    );
    final decoded = jsonDecode(response);
    if (decoded is! Map) return null;
    final files = decoded['files'];
    if (files is! List || files.isEmpty || files.first is! Map) return null;
    return _infoFromJson(Map<String, dynamic>.from(files.first as Map));
  }

  static Future<DriveBackupInfo> _createFile(String token) async {
    final response = await _request(
      'POST',
      Uri.https('www.googleapis.com', '/drive/v3/files', {
        'fields': 'id,name,modifiedTime,size',
      }),
      token,
      body: jsonEncode(<String, dynamic>{
        'name': fileName,
        'mimeType': 'application/json',
        'description': 'ELXVRO kullanıcı tercihleri ve kitaplık yedeği',
        'appProperties': <String, String>{
          'app': 'ELXVRO',
          'type': 'user-backup',
        },
      }),
      contentType: 'application/json; charset=utf-8',
    );
    final decoded = jsonDecode(response);
    if (decoded is! Map) {
      throw const DriveBackupException('Google Drive yedek dosyası oluşturulamadı.');
    }
    return _infoFromJson(Map<String, dynamic>.from(decoded));
  }

  static Future<void> _uploadContent(
    String token,
    String fileId,
    Map<String, dynamic> data,
  ) async {
    await _request(
      'PATCH',
      Uri.https('www.googleapis.com', '/upload/drive/v3/files/$fileId', {
        'uploadType': 'media',
      }),
      token,
      body: const JsonEncoder.withIndent('  ').convert(data),
      contentType: 'application/json; charset=utf-8',
    );
  }

  static DriveBackupInfo _infoFromJson(Map<String, dynamic> json) {
    final id = '${json['id'] ?? ''}'.trim();
    if (id.isEmpty) {
      throw const DriveBackupException('Google Drive dosya kimliği alınamadı.');
    }
    return DriveBackupInfo(
      fileId: id,
      name: '${json['name'] ?? fileName}',
      modifiedAt: DateTime.tryParse('${json['modifiedTime'] ?? ''}'),
      size: int.tryParse('${json['size'] ?? ''}'),
    );
  }

  static Future<String> _request(
    String method,
    Uri uri,
    String token, {
    String? body,
    String? contentType,
  }) async {
    final client = HttpClient()..connectionTimeout = _timeout;
    try {
      final HttpClientRequest request;
      switch (method) {
        case 'POST':
          request = await client.postUrl(uri).timeout(_timeout);
          break;
        case 'PATCH':
          request = await client.patchUrl(uri).timeout(_timeout);
          break;
        default:
          request = await client.getUrl(uri).timeout(_timeout);
      }
      request.headers.set(HttpHeaders.authorizationHeader, 'Bearer $token');
      request.headers.set(HttpHeaders.acceptHeader, 'application/json');
      if (contentType != null) {
        request.headers.set(HttpHeaders.contentTypeHeader, contentType);
      }
      if (body != null) request.write(body);

      final response = await request.close().timeout(_timeout);
      final text = await response.transform(utf8.decoder).join().timeout(_timeout);
      if (response.statusCode < 200 || response.statusCode >= 300) {
        String detail = '';
        try {
          final decoded = jsonDecode(text);
          if (decoded is Map && decoded['error'] is Map) {
            detail = '${(decoded['error'] as Map)['message'] ?? ''}'.trim();
          }
        } catch (_) {
          detail = '';
        }
        if (response.statusCode == 401 || response.statusCode == 403) {
          throw DriveBackupException(
            detail.isEmpty
                ? 'Google Drive erişim izni alınamadı. Drive API ve izin ayarlarını kontrol et.'
                : detail,
          );
        }
        throw DriveBackupException(
          detail.isEmpty ? 'Google Drive işlemi tamamlanamadı.' : detail,
        );
      }
      return text;
    } on SocketException {
      throw const DriveBackupException('Google Drive’a bağlanılamadı. İnternet bağlantını kontrol et.');
    } on TimeoutException {
      throw const DriveBackupException('Google Drive bağlantısı zaman aşımına uğradı.');
    } on GoogleSignInException catch (error) {
      throw DriveBackupException(
        error.description?.trim().isNotEmpty == true
            ? error.description!.trim()
            : 'Google Drive izni tamamlanamadı.',
      );
    } finally {
      client.close(force: true);
    }
  }
}
