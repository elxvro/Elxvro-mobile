import 'package:flutter/services.dart';

enum WallpaperTarget { home, lock, both }

class WallpaperService {
  static const _channel = MethodChannel('com.elxvro.wallpaper/channel');

  static Future<void> setFromAsset(String assetPath, WallpaperTarget target) async {
    final data = await rootBundle.load(assetPath);
    final bytes = data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
    await _channel.invokeMethod<void>('setWallpaper', {
      'bytes': bytes,
      'target': target.name,
    });
  }
}
