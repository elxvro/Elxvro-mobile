import 'dart:io';

import 'package:flutter/services.dart';

import '../models/wallpaper.dart';

enum WallpaperTarget { home, lock, both }

class WallpaperService {
  static const _channel = MethodChannel('com.elxvro.wallpaper/channel');

  static Future<void> setFromItem(
    WallpaperItem item,
    WallpaperTarget target,
  ) async {
    if (item.isBundledAsset) {
      return setFromAsset(item.asset, target);
    }
    final bytes = await File(item.asset).readAsBytes();
    return setFromBytes(bytes, target);
  }

  static Future<void> setFromAsset(
    String assetPath,
    WallpaperTarget target,
  ) async {
    final data = await rootBundle.load(assetPath);
    final bytes = data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
    await setFromBytes(bytes, target);
  }

  static Future<void> setFromBytes(
    Uint8List bytes,
    WallpaperTarget target, {
    bool exactComposition = false,
  }) async {
    await _channel.invokeMethod<void>('setWallpaper', {
      'bytes': bytes,
      'target': target.name,
      'exactComposition': exactComposition,
    });
  }
}
