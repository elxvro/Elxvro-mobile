import 'dart:io';
import 'package:flutter/services.dart';

import '../models/wallpaper.dart';

enum WallpaperTarget { home, lock, both }

class WallpaperService {
  static const _channel = MethodChannel('com.elxvro.wallpaper/channel');
  static const _requestTimeout = Duration(seconds: 20);
  static const _maxImageBytes = 25 * 1024 * 1024;

  static Future<void> setFromItem(
    WallpaperItem item,
    WallpaperTarget target,
  ) async {
    if (item.isBundledAsset) {
      return setFromAsset(item.asset, target);
    }
    if (item.isRemoteUrl) {
      final bytes = await _readRemote(item.asset);
      return setFromBytes(bytes, target);
    }
    final bytes = await File(item.asset).readAsBytes();
    return setFromBytes(bytes, target);
  }

  static Future<Uint8List> _readRemote(String url) async {
    final uri = Uri.parse(url);
    if (uri.scheme != 'https' || uri.host.toLowerCase() != 'elxvro.com') {
      throw const FormatException('Geçersiz ELXVRO medya adresi.');
    }

    final client = HttpClient()..connectionTimeout = _requestTimeout;
    try {
      final request = await client.getUrl(uri).timeout(_requestTimeout);
      request.headers.set(
        HttpHeaders.userAgentHeader,
        'ELXVRO-Android/1.0.20 wallpaper-apply',
      );
      final response = await request.close().timeout(_requestTimeout);
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw HttpException('Medya HTTP ${response.statusCode}');
      }
      if (response.contentLength > _maxImageBytes) {
        throw HttpException('Görsel dosyası çok büyük.');
      }
      final chunks = <int>[];
      var received = 0;
      await for (final chunk in response.timeout(_requestTimeout)) {
        received += chunk.length;
        if (received > _maxImageBytes) {
          throw HttpException('Görsel dosyası çok büyük.');
        }
        chunks.addAll(chunk);
      }
      if (chunks.isEmpty) throw HttpException('Boş görsel dosyası.');
      return Uint8List.fromList(chunks);
    } finally {
      client.close(force: true);
    }
  }

  static Future<void> setFromAsset(
    String assetPath,
    WallpaperTarget target,
  ) async {
    final data = await rootBundle.load(assetPath);
    final bytes = data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
    await setFromBytes(bytes, target);
  }

  static Future<void> setFromBytes(
    Uint8List bytes,
    WallpaperTarget target, {
    bool exactComposition = false,
  }) async {
    await _channel.invokeMethod<void>('setWallpaper', {
      'bytes': bytes,
      'target': target.name,
      'exactComposition': exactComposition,
    });
  }
}
