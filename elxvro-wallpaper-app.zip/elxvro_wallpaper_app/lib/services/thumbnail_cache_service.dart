import 'dart:async';
import 'dart:collection';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';

import '../models/wallpaper.dart';
import 'http_policy.dart';

class ThumbnailCacheService {
  static const _channel = MethodChannel('com.elxvro.wallpaper/channel');
  static const Duration _timeout = Duration(seconds: 12);
  static const int _maxBytes = 3 * 1024 * 1024;
  static const int _maxConcurrent = 2;

  static final Map<String, Future<File?>> _requests = <String, Future<File?>>{};
  static final Queue<_ThumbnailJob> _queue = Queue<_ThumbnailJob>();
  static Future<String>? _rootFuture;
  static int _active = 0;

  static String? urlFor(WallpaperItem item) {
    if (!item.isRemoteUrl) return null;
    final uri = Uri.tryParse(item.asset);
    if (uri == null ||
        uri.scheme != 'https' ||
        uri.host.toLowerCase() != 'elxvro.com') {
      return null;
    }
    final segments = uri.pathSegments;
    if (segments.length < 2) return null;
    final category = segments[segments.length - 2];
    final filename = segments.last;
    final dot = filename.lastIndexOf('.');
    if (dot <= 0) return null;
    final base = filename.substring(0, dot);
    return Uri(
      scheme: 'https',
      host: 'elxvro.com',
      pathSegments: <String>['app-media', 'thumbs', category, '${base}_thumb.webp'],
      queryParameters: item.signature == null || item.signature!.isEmpty
          ? null
          : <String, String>{'v': item.signature!},
    ).toString();
  }

  static Future<File?> get(WallpaperItem item) {
    final url = urlFor(item);
    if (url == null) return Future<File?>.value(null);
    return _requests.putIfAbsent(url, () => _enqueue(url));
  }

  static Future<File?> _enqueue(String url) {
    final completer = Completer<File?>();
    _queue.add(_ThumbnailJob(url, completer));
    _pump();
    return completer.future;
  }

  static void _pump() {
    while (_active < _maxConcurrent && _queue.isNotEmpty) {
      final job = _queue.removeFirst();
      _active++;
      _run(job).whenComplete(() {
        _active--;
        Future<void>.delayed(const Duration(milliseconds: 160), _pump);
      });
    }
  }

  static Future<void> _run(_ThumbnailJob job) async {
    try {
      job.completer.complete(await _download(job.url));
    } catch (_) {
      job.completer.complete(null);
    }
  }

  static Future<File?> _download(String url) async {
    final root = await (_rootFuture ??= _cacheRoot());
    final file = File('$root/${_cacheKey(url)}.webp');
    if (await file.exists() && await file.length() > 0) return file;

    await ElxvroRequestGate.waitTurn();
    final uri = Uri.parse(url);
    final client = HttpClient()..connectionTimeout = _timeout;
    try {
      final request = await client.getUrl(uri).timeout(_timeout);
      request.headers.set(HttpHeaders.acceptHeader, 'image/webp,image/*;q=0.8');
      request.headers.set(
        HttpHeaders.userAgentHeader,
        'ELXVRO-Android/1.0.21 thumbnail-cache',
      );
      final response = await request.close().timeout(_timeout);
      if (response.statusCode == 403 || response.statusCode == 429) {
        ElxvroRequestGate.penalize(
          response.statusCode,
          retryAfter: response.headers.value('retry-after'),
        );
      }
      if (response.statusCode < 200 || response.statusCode >= 300) return null;
      if (response.contentLength > _maxBytes) return null;

      await file.parent.create(recursive: true);
      final temp = File('${file.path}.part');
      if (await temp.exists()) await temp.delete();
      final sink = temp.openWrite();
      var received = 0;
      var tooLarge = false;
      try {
        await for (final chunk in response.timeout(_timeout)) {
          received += chunk.length;
          if (received > _maxBytes) {
            tooLarge = true;
            break;
          }
          sink.add(chunk);
        }
      } finally {
        await sink.close();
      }
      if (tooLarge || received <= 0) {
        if (await temp.exists()) await temp.delete();
        return null;
      }
      if (await file.exists()) await file.delete();
      await temp.rename(file.path);
      return file;
    } finally {
      client.close(force: true);
    }
  }

  static Future<String> _cacheRoot() async {
    try {
      final root = await _channel.invokeMethod<String>('getMirrorDirectory');
      if (root != null && root.isNotEmpty) {
        final dir = Directory('$root/thumb-cache');
        await dir.create(recursive: true);
        return dir.path;
      }
    } on MissingPluginException {
      // Test ortamında geçici klasör kullanılır.
    } on PlatformException {
      // Test ortamında geçici klasör kullanılır.
    }
    final dir = await Directory.systemTemp.createTemp('elxvro-thumb-cache-');
    return dir.path;
  }

  static String _cacheKey(String value) {
    var hash = 0x811c9dc5;
    for (final byte in utf8.encode(value)) {
      hash ^= byte;
      hash = (hash * 0x01000193) & 0xffffffff;
    }
    return hash.toRadixString(16).padLeft(8, '0');
  }
}

class _ThumbnailJob {
  final String url;
  final Completer<File?> completer;

  const _ThumbnailJob(this.url, this.completer);
}
