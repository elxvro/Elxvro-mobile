import 'package:flutter/material.dart';
import 'app_state.dart';
import 'screens/splash_screen.dart';
import 'theme/app_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(AppScope(notifier: AppState(), child: const ElxvroApp()));
}

class ElxvroApp extends StatelessWidget {
  const ElxvroApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ELXVRO',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      home: const SplashScreen(),
    );
  }
}
