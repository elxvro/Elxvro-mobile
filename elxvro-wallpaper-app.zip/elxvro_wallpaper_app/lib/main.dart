import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'app_state.dart';
import 'screens/splash_screen.dart';
import 'theme/app_theme.dart';
import 'services/http_policy.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  HttpOverrides.global = ElxvroHttpOverrides();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
      statusBarBrightness: Brightness.light,
      systemNavigationBarColor: AppTheme.background,
      systemNavigationBarIconBrightness: Brightness.dark,
    ),
  );
  runApp(AppScope(notifier: AppState(), child: const ElxvroApp()));
}

class ElxvroApp extends StatelessWidget {
  const ElxvroApp({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return MaterialApp(
      title: 'ELXVRO',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(accent: state.accentColor),
      home: const SplashScreen(),
    );
  }
}
