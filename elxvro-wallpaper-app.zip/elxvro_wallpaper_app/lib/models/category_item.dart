import '../utils/category_key.dart';

class CategoryItem {
  final String name;
  final String slug;

  const CategoryItem({
    required this.name,
    required this.slug,
  });

  factory CategoryItem.fromName(String name) => CategoryItem(
        name: name.trim(),
        slug: categoryKey(name),
      );

  Map<String, String> toJson() => {
        'name': name,
        'slug': slug,
      };

  static CategoryItem? fromJson(dynamic raw) {
    if (raw is String) {
      final name = raw.trim();
      if (name.isEmpty) return null;
      return CategoryItem.fromName(name);
    }
    if (raw is! Map) return null;

    String? firstText(List<String> keys) {
      for (final key in keys) {
        final value = raw[key];
        if (value is String && value.trim().isNotEmpty) return value.trim();
      }
      return null;
    }

    final name = firstText(const [
      'name',
      'title',
      'category_name',
      'category',
      'label',
    ]);
    if (name == null) return null;

    final rawSlug = firstText(const ['slug', 'key', 'category_slug']);
    final slug = categoryKey(rawSlug ?? name);
    if (slug.isEmpty) return null;
    return CategoryItem(name: name, slug: slug);
  }
}
