class WallpaperItem {
  final String id;
  final String title;
  final String category;
  final String asset;
  final List<String> tags;
  final String? signature;

  const WallpaperItem({
    required this.id,
    required this.title,
    required this.category,
    required this.asset,
    required this.tags,
    this.signature,
  });

  bool get isBundledAsset => asset.startsWith('assets/');
  bool get isLocalFile => !isBundledAsset;

  WallpaperItem copyWith({
    String? id,
    String? title,
    String? category,
    String? asset,
    List<String>? tags,
    String? signature,
  }) {
    return WallpaperItem(
      id: id ?? this.id,
      title: title ?? this.title,
      category: category ?? this.category,
      asset: asset ?? this.asset,
      tags: tags ?? this.tags,
      signature: signature ?? this.signature,
    );
  }
}
