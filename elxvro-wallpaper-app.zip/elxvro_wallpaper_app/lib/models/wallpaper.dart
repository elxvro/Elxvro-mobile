class WallpaperItem {
  final String id;
  final String title;
  final String category;
  final String asset;
  final List<String> tags;

  const WallpaperItem({
    required this.id,
    required this.title,
    required this.category,
    required this.asset,
    required this.tags,
  });
}
