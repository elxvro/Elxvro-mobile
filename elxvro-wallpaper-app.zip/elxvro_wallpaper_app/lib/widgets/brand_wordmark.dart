import 'package:flutter/material.dart';

class BrandWordmark extends StatelessWidget {
  final double fontSize;
  final double letterSpacing;
  final FontWeight fontWeight;
  final TextAlign textAlign;

  const BrandWordmark({
    super.key,
    this.fontSize = 24,
    this.letterSpacing = 4,
    this.fontWeight = FontWeight.w900,
    this.textAlign = TextAlign.left,
  });

  @override
  Widget build(BuildContext context) {
    return ShaderMask(
      blendMode: BlendMode.srcIn,
      shaderCallback: (bounds) => const LinearGradient(
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
        colors: [
          Color(0xFF7C3AED),
          Color(0xFFA855F7),
          Color(0xFFD8B4FE),
          Color(0xFF8B5CF6),
        ],
      ).createShader(bounds),
      child: Text(
        'ELXVRO',
        textAlign: textAlign,
        style: TextStyle(
          color: Colors.white,
          fontSize: fontSize,
          letterSpacing: letterSpacing,
          fontWeight: fontWeight,
          height: 1,
        ),
      ),
    );
  }
}
