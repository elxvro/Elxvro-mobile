import 'dart:io';

import 'package:flutter/material.dart';

import '../models/wallpaper.dart';

ImageProvider<Object> wallpaperProviderFromPath(String path) {
  if (path.startsWith('assets/')) return AssetImage(path);
  if (path.startsWith('https://') || path.startsWith('http://')) {
    return NetworkImage(path);
  }
  return FileImage(File(path));
}

ImageProvider<Object> wallpaperProvider(WallpaperItem item) =>
    wallpaperProviderFromPath(item.asset);

class WallpaperImage extends StatelessWidget {
  final WallpaperItem item;
  final BoxFit fit;
  final double? width;
  final double? height;
  final FilterQuality filterQuality;
  final Widget? errorWidget;

  const WallpaperImage({
    super.key,
    required this.item,
    this.fit = BoxFit.cover,
    this.width,
    this.height,
    this.filterQuality = FilterQuality.medium,
    this.errorWidget,
  });

  @override
  Widget build(BuildContext context) {
    final fallback = errorWidget ??
        const ColoredBox(
          color: Color(0xFF11151E),
          child: Center(
            child: Icon(Icons.broken_image_outlined, color: Colors.white24),
          ),
        );

    if (item.isBundledAsset) {
      return Image.asset(
        item.asset,
        fit: fit,
        width: width,
        height: height,
        filterQuality: filterQuality,
        errorBuilder: (_, __, ___) => fallback,
      );
    }

    if (item.isRemoteUrl) {
      return Image.network(
        item.asset,
        fit: fit,
        width: width,
        height: height,
        filterQuality: filterQuality,
        gaplessPlayback: true,
        errorBuilder: (_, __, ___) => fallback,
        loadingBuilder: (context, child, progress) {
          if (progress == null) return child;
          return Stack(
            fit: StackFit.expand,
            children: [
              const ColoredBox(color: Color(0xFF11151E)),
              Center(
                child: SizedBox(
                  width: 24,
                  height: 24,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    value: progress.expectedTotalBytes == null
                        ? null
                        : progress.cumulativeBytesLoaded /
                            progress.expectedTotalBytes!,
                  ),
                ),
              ),
            ],
          );
        },
      );
    }

    return Image.file(
      File(item.asset),
      fit: fit,
      width: width,
      height: height,
      filterQuality: filterQuality,
      errorBuilder: (_, __, ___) => fallback,
    );
  }
}
