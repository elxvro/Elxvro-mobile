import 'dart:io';

import 'package:flutter/material.dart';

import '../models/wallpaper.dart';

ImageProvider<Object> wallpaperProviderFromPath(String path) {
  if (path.startsWith('assets/')) return AssetImage(path);
  if (path.startsWith('https://') || path.startsWith('http://')) {
    return NetworkImage(path);
  }
  return FileImage(File(path));
}

ImageProvider<Object> wallpaperProvider(WallpaperItem item) =>
    wallpaperProviderFromPath(item.asset);

String? wallpaperThumbnailUrl(WallpaperItem item) {
  if (!item.isRemoteUrl) return null;
  final uri = Uri.tryParse(item.asset);
  if (uri == null || uri.host.toLowerCase() != 'elxvro.com') return null;
  final segments = uri.pathSegments;
  if (segments.length < 2) return null;
  final category = segments[segments.length - 2];
  final filename = segments.last;
  final dot = filename.lastIndexOf('.');
  if (dot <= 0) return null;
  final base = filename.substring(0, dot);
  final thumbnailFile = '${base}_thumb.webp';
  return Uri(
    scheme: 'https',
    host: 'elxvro.com',
    pathSegments: ['app-media', 'thumbs', category, thumbnailFile],
    queryParameters: item.signature == null || item.signature!.isEmpty
        ? null
        : {'v': item.signature!},
  ).toString();
}

class WallpaperImage extends StatelessWidget {
  final WallpaperItem item;
  final BoxFit fit;
  final double? width;
  final double? height;
  final FilterQuality filterQuality;
  final Widget? errorWidget;
  final bool useThumbnail;
  final bool progressive;

  const WallpaperImage({
    super.key,
    required this.item,
    this.fit = BoxFit.cover,
    this.width,
    this.height,
    this.filterQuality = FilterQuality.medium,
    this.errorWidget,
    this.useThumbnail = false,
    this.progressive = false,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final placeholder = ColoredBox(color: scheme.surfaceContainerHighest);
    final fallback = errorWidget ??
        ColoredBox(
          color: scheme.surfaceContainerHighest,
          child: Center(
            child: Icon(
              Icons.broken_image_outlined,
              color: scheme.onSurfaceVariant.withValues(alpha: .45),
            ),
          ),
        );
    final decodeWidth = useThumbnail ? 560 : null;

    if (item.isBundledAsset) {
      return Image.asset(
        item.asset,
        fit: fit,
        width: width,
        height: height,
        cacheWidth: decodeWidth,
        filterQuality: filterQuality,
        errorBuilder: (_, __, ___) => fallback,
      );
    }

    if (item.isRemoteUrl) {
      final thumbnailUrl = wallpaperThumbnailUrl(item);
      if (useThumbnail && thumbnailUrl != null) {
        return _networkImage(
          thumbnailUrl,
          fallback: fallback,
          fallbackUrl: item.asset,
          cacheWidth: decodeWidth,
          loadingPlaceholder: placeholder,
        );
      }
      return _networkImage(
        item.asset,
        fallback: fallback,
        cacheWidth: decodeWidth,
        loadingPlaceholder: progressive && thumbnailUrl != null
            ? _networkImage(
                thumbnailUrl,
                fallback: placeholder,
                cacheWidth: 720,
                loadingPlaceholder: placeholder,
                showProgress: false,
              )
            : placeholder,
      );
    }

    return Image.file(
      File(item.asset),
      fit: fit,
      width: width,
      height: height,
      cacheWidth: decodeWidth,
      filterQuality: filterQuality,
      errorBuilder: (_, __, ___) => fallback,
    );
  }

  Widget _networkImage(
    String url, {
    required Widget fallback,
    String? fallbackUrl,
    int? cacheWidth,
    Widget? loadingPlaceholder,
    bool showProgress = true,
  }) {
    return Image.network(
      url,
      fit: fit,
      width: width,
      height: height,
      cacheWidth: cacheWidth,
      filterQuality: filterQuality,
      gaplessPlayback: true,
      errorBuilder: (_, __, ___) {
        if (fallbackUrl == null) return fallback;
        return Image.network(
          fallbackUrl,
          fit: fit,
          width: width,
          height: height,
          cacheWidth: cacheWidth,
          filterQuality: filterQuality,
          gaplessPlayback: true,
          errorBuilder: (_, __, ___) => fallback,
        );
      },
      loadingBuilder: (context, child, progress) {
        if (progress == null) return child;
        return Stack(
          fit: StackFit.expand,
          children: [
            loadingPlaceholder ?? fallback,
            if (showProgress)
              const Align(
                alignment: Alignment.bottomCenter,
                child: LinearProgressIndicator(minHeight: 1.5),
              ),
          ],
        );
      },
    );
  }
}
