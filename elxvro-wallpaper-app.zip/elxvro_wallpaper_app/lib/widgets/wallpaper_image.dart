import 'dart:io';

import 'package:flutter/material.dart';

import '../models/wallpaper.dart';
import '../services/mirror_sync_service.dart';
import '../services/thumbnail_cache_service.dart';

ImageProvider<Object> wallpaperProviderFromPath(String path) {
  if (path.startsWith('assets/')) return AssetImage(path);
  if (path.startsWith('https://') || path.startsWith('http://')) {
    return NetworkImage(path);
  }
  return FileImage(File(path));
}

ImageProvider<Object> wallpaperProvider(WallpaperItem item) =>
    wallpaperProviderFromPath(item.asset);

class WallpaperImage extends StatelessWidget {
  final WallpaperItem item;
  final BoxFit fit;
  final double? width;
  final double? height;
  final FilterQuality filterQuality;
  final Widget? errorWidget;
  final bool useThumbnail;
  final bool progressive;

  const WallpaperImage({
    super.key,
    required this.item,
    this.fit = BoxFit.cover,
    this.width,
    this.height,
    this.filterQuality = FilterQuality.medium,
    this.errorWidget,
    this.useThumbnail = false,
    this.progressive = false,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final placeholder = ColoredBox(color: scheme.surfaceContainerHighest);
    final fallback = errorWidget ??
        ColoredBox(
          color: scheme.surfaceContainerHighest,
          child: Center(
            child: Icon(
              Icons.broken_image_outlined,
              color: scheme.onSurfaceVariant.withValues(alpha: .45),
            ),
          ),
        );
    final decodeWidth = useThumbnail ? 560 : null;

    if (item.isBundledAsset) {
      return Image.asset(
        item.asset,
        fit: fit,
        width: width,
        height: height,
        cacheWidth: decodeWidth,
        filterQuality: filterQuality,
        errorBuilder: (context, error, stackTrace) => fallback,
      );
    }

    if (item.isRemoteUrl) {
      if (useThumbnail) {
        return _CachedThumbnail(
          item: item,
          fit: fit,
          width: width,
          height: height,
          filterQuality: filterQuality,
          cacheWidth: decodeWidth,
          placeholder: placeholder,
          fallback: fallback,
        );
      }

      return _CachedOriginal(
        item: item,
        fit: fit,
        width: width,
        height: height,
        filterQuality: filterQuality,
        placeholder: progressive
            ? _CachedThumbnail(
                item: item,
                fit: fit,
                width: width,
                height: height,
                filterQuality: FilterQuality.low,
                cacheWidth: 720,
                placeholder: placeholder,
                fallback: placeholder,
              )
            : placeholder,
        fallback: fallback,
      );
    }

    return Image.file(
      File(item.asset),
      fit: fit,
      width: width,
      height: height,
      cacheWidth: decodeWidth,
      filterQuality: filterQuality,
      errorBuilder: (context, error, stackTrace) => fallback,
    );
  }
}

class _CachedThumbnail extends StatelessWidget {
  final WallpaperItem item;
  final BoxFit fit;
  final double? width;
  final double? height;
  final FilterQuality filterQuality;
  final int? cacheWidth;
  final Widget placeholder;
  final Widget fallback;

  const _CachedThumbnail({
    required this.item,
    required this.fit,
    required this.width,
    required this.height,
    required this.filterQuality,
    required this.cacheWidth,
    required this.placeholder,
    required this.fallback,
  });

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<File?>(
      future: ThumbnailCacheService.get(item),
      builder: (context, snapshot) {
        final file = snapshot.data;
        if (file != null) {
          return Image.file(
            file,
            fit: fit,
            width: width,
            height: height,
            cacheWidth: cacheWidth,
            filterQuality: filterQuality,
            gaplessPlayback: true,
            errorBuilder: (context, error, stackTrace) => fallback,
          );
        }
        if (snapshot.connectionState == ConnectionState.done) return fallback;
        return placeholder;
      },
    );
  }
}

class _CachedOriginal extends StatelessWidget {
  final WallpaperItem item;
  final BoxFit fit;
  final double? width;
  final double? height;
  final FilterQuality filterQuality;
  final Widget placeholder;
  final Widget fallback;

  const _CachedOriginal({
    required this.item,
    required this.fit,
    required this.width,
    required this.height,
    required this.filterQuality,
    required this.placeholder,
    required this.fallback,
  });

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<WallpaperItem>(
      future: MirrorSyncService.ensureLocal(item),
      builder: (context, snapshot) {
        final local = snapshot.data;
        if (local != null && local.isLocalFile) {
          return Image.file(
            File(local.asset),
            fit: fit,
            width: width,
            height: height,
            filterQuality: filterQuality,
            gaplessPlayback: true,
            errorBuilder: (context, error, stackTrace) => fallback,
          );
        }
        if (snapshot.hasError) return fallback;
        return Stack(
          fit: StackFit.expand,
          children: <Widget>[
            placeholder,
            const Align(
              alignment: Alignment.bottomCenter,
              child: LinearProgressIndicator(minHeight: 1.5),
            ),
          ],
        );
      },
    );
  }
}
