import 'dart:io';

import 'package:flutter/material.dart';

import '../models/wallpaper.dart';

ImageProvider<Object> wallpaperProviderFromPath(String path) {
  if (path.startsWith('assets/')) return AssetImage(path);
  return FileImage(File(path));
}

ImageProvider<Object> wallpaperProvider(WallpaperItem item) =>
    wallpaperProviderFromPath(item.asset);

class WallpaperImage extends StatelessWidget {
  final WallpaperItem item;
  final BoxFit fit;
  final double? width;
  final double? height;
  final FilterQuality filterQuality;
  final Widget? errorWidget;

  const WallpaperImage({
    super.key,
    required this.item,
    this.fit = BoxFit.cover,
    this.width,
    this.height,
    this.filterQuality = FilterQuality.medium,
    this.errorWidget,
  });

  @override
  Widget build(BuildContext context) {
    final fallback = errorWidget ??
        const ColoredBox(
          color: Color(0xFF11151E),
          child: Center(
            child: Icon(Icons.broken_image_outlined, color: Colors.white24),
          ),
        );

    if (item.isBundledAsset) {
      return Image.asset(
        item.asset,
        fit: fit,
        width: width,
        height: height,
        filterQuality: filterQuality,
        errorBuilder: (_, __, ___) => fallback,
      );
    }

    return Image.file(
      File(item.asset),
      fit: fit,
      width: width,
      height: height,
      filterQuality: filterQuality,
      errorBuilder: (_, __, ___) => fallback,
    );
  }
}
