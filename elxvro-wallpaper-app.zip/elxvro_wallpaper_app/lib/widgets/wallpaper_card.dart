import 'package:flutter/material.dart';
import '../app_state.dart';
import '../models/wallpaper.dart';
import '../screens/wallpaper_detail_screen.dart';

class WallpaperCard extends StatelessWidget {
  final WallpaperItem item;
  final double? aspectRatio;
  const WallpaperCard({super.key, required this.item, this.aspectRatio});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return GestureDetector(
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => WallpaperDetailScreen(item: item)),
      ),
      child: AspectRatio(
        aspectRatio: aspectRatio ?? .62,
        child: ClipRRect(
            borderRadius: BorderRadius.circular(22),
            child: Stack(
              fit: StackFit.expand,
              children: [
                Image.asset(item.asset, fit: BoxFit.cover),
                Positioned(
                  right: 8,
                  bottom: 8,
                  child: Material(
                    color: Colors.black.withValues(alpha: .35),
                    shape: const CircleBorder(),
                    child: IconButton(
                      visualDensity: VisualDensity.compact,
                      onPressed: () => state.toggleFavorite(item.id),
                      icon: Icon(
                        state.isFavorite(item.id) ? Icons.favorite : Icons.favorite_border,
                        color: state.isFavorite(item.id) ? const Color(0xFFFF668F) : Colors.white,
                        size: 20,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
      ),
    );
  }
}
