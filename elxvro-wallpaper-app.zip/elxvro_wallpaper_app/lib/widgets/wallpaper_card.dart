import 'package:flutter/material.dart';

import '../app_state.dart';
import '../models/wallpaper.dart';
import '../screens/wallpaper_detail_screen.dart';
import 'wallpaper_image.dart';

class WallpaperCard extends StatelessWidget {
  final WallpaperItem item;
  final double? aspectRatio;

  const WallpaperCard({
    super.key,
    required this.item,
    this.aspectRatio,
  });

  void _open(BuildContext context) {
    AppScope.of(context).markViewed(item.id);
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => WallpaperDetailScreen(item: item)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final isFavorite = state.isFavorite(item.id);
    final wasApplied = state.wasApplied(item.id);
    final radius = state.compactGrid ? 16.0 : 22.0;

    return GestureDetector(
      onTap: () => _open(context),
      child: AspectRatio(
        aspectRatio: aspectRatio ?? .62,
        child: DecoratedBox(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(radius),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(radius),
            child: Stack(
              fit: StackFit.expand,
              children: [
                WallpaperImage(
                  item: item,
                  fit: BoxFit.cover,
                  filterQuality: FilterQuality.low,
                  useThumbnail: true,
                ),
                const DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.transparent, Color(0x55000000)],
                    ),
                  ),
                ),
                if (wasApplied)
                  Positioned(
                    left: 8,
                    top: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: .48),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: Colors.white24),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.check_rounded, size: 13, color: Colors.white),
                          SizedBox(width: 3),
                          Text(
                            'Uygulandı',
                            style: TextStyle(fontSize: 9, color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  ),
                if (!state.compactGrid)
                  Positioned(
                    right: 8,
                    bottom: 8,
                    child: Material(
                      color: Colors.black.withValues(alpha: .38),
                      shape: const CircleBorder(),
                      child: IconButton(
                        visualDensity: VisualDensity.compact,
                        onPressed: () => state.toggleFavorite(item.id),
                        icon: Icon(
                          isFavorite ? Icons.favorite : Icons.favorite_border,
                          color: isFavorite
                              ? const Color(0xFFFF668F)
                              : Colors.white,
                          size: 20,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
