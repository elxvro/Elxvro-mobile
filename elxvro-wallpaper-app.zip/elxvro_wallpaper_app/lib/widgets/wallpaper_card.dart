import 'package:flutter/material.dart';
import '../app_state.dart';
import '../models/wallpaper.dart';
import '../screens/wallpaper_detail_screen.dart';

class WallpaperCard extends StatelessWidget {
  final WallpaperItem item;
  final double? aspectRatio;

  const WallpaperCard({
    super.key,
    required this.item,
    this.aspectRatio,
  });

  void _open(BuildContext context) {
    AppScope.of(context).markViewed(item.id);
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => WallpaperDetailScreen(item: item)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final isFavorite = state.isFavorite(item.id);
    final wasApplied = state.wasApplied(item.id);

    return GestureDetector(
      onTap: () => _open(context),
      child: AspectRatio(
        aspectRatio: aspectRatio ?? .62,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(state.compactGrid ? 16 : 22),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.asset(
                item.asset,
                fit: BoxFit.cover,
                filterQuality: FilterQuality.medium,
              ),
              const DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Color(0x77000000)],
                  ),
                ),
              ),
              if (wasApplied)
                Positioned(
                  left: 8,
                  top: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 5,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: .48),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.check_rounded, size: 13),
                        SizedBox(width: 3),
                        Text('Uygulandı', style: TextStyle(fontSize: 9)),
                      ],
                    ),
                  ),
                ),
              if (state.showCardTitles)
                Positioned(
                  left: 10,
                  bottom: 12,
                  right: state.compactGrid ? 10 : 50,
                  child: Text(
                    item.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: state.compactGrid ? 10 : 12,
                      fontWeight: FontWeight.w700,
                      shadows: const [
                        Shadow(blurRadius: 8, color: Colors.black),
                      ],
                    ),
                  ),
                ),
              if (!state.compactGrid)
                Positioned(
                  right: 8,
                  bottom: 8,
                  child: Material(
                    color: Colors.black.withValues(alpha: .38),
                    shape: const CircleBorder(),
                    child: IconButton(
                      visualDensity: VisualDensity.compact,
                      onPressed: () => state.toggleFavorite(item.id),
                      icon: Icon(
                        isFavorite ? Icons.favorite : Icons.favorite_border,
                        color: isFavorite
                            ? const Color(0xFFFF668F)
                            : Colors.white,
                        size: 20,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
