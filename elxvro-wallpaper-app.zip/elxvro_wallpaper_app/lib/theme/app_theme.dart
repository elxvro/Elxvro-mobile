import 'package:flutter/material.dart';

class AppTheme {
  static const background = Color(0xFF070A10);
  static const card = Color(0xFF111722);
  static const accent = Color(0xFF8B6CFF);
  static const accent2 = Color(0xFFFF5E9B);

  static ThemeData get dark {
    final scheme = ColorScheme.fromSeed(
      seedColor: accent,
      brightness: Brightness.dark,
      surface: card,
    );
    return ThemeData(
      brightness: Brightness.dark,
      colorScheme: scheme,
      scaffoldBackgroundColor: background,
      useMaterial3: true,
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: const Color(0xFF090D14),
        indicatorColor: accent.withValues(alpha: .18),
        labelTextStyle: WidgetStateProperty.all(const TextStyle(fontSize: 11)),
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: Color(0xFF0E131C),
        modalBackgroundColor: Color(0xFF0E131C),
        showDragHandle: true,
      ),
    );
  }
}
