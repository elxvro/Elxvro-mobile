import 'package:flutter/material.dart';

class AppTheme {
  static const card = Color(0xFF111722);

  static ThemeData dark({
    required Color accent,
    required bool oled,
  }) {
    final background = oled ? Colors.black : const Color(0xFF070A10);
    final surface = oled ? const Color(0xFF090909) : card;
    final scheme = ColorScheme.fromSeed(
      seedColor: accent,
      brightness: Brightness.dark,
      surface: surface,
    );

    return ThemeData(
      brightness: Brightness.dark,
      colorScheme: scheme,
      scaffoldBackgroundColor: background,
      useMaterial3: true,
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: oled ? Colors.black : const Color(0xFF090D14),
        indicatorColor: accent.withValues(alpha: .18),
        labelTextStyle: WidgetStateProperty.all(const TextStyle(fontSize: 11)),
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: surface,
        modalBackgroundColor: surface,
        showDragHandle: true,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        foregroundColor: scheme.onSurface,
      ),
    );
  }
}
