import '../models/category_item.dart';
import '../models/wallpaper.dart';

// Paket içindeki görseller ilk kurulum/çevrimdışı durum için yedektir.
// Hosting senkronizasyonu tamamlandığında bu liste uygulamanın özel depolama
// alanına kopyalanmış ELX-M-* görselleriyle dinamik olarak değiştirilir.
final wallpapers = <WallpaperItem>[
  WallpaperItem(
    id: 'n1',
    title: 'Sessiz Zirve',
    category: 'Doğa',
    asset: 'assets/wallpapers/nature_twilight_peak.jpg',
    tags: ['Dağ', 'Gün Batımı', 'Minimal'],
  ),
  WallpaperItem(
    id: 'n2',
    title: 'Zümrüt Akışı',
    category: 'Doğa',
    asset: 'assets/wallpapers/nature_emerald_falls.jpg',
    tags: ['Orman', 'Şelale', 'Yeşil'],
  ),
  WallpaperItem(
    id: 'n3',
    title: 'Kuzey Işıkları',
    category: 'Doğa',
    asset: 'assets/wallpapers/nature_aurora.jpg',
    tags: ['Aurora', 'Gece', 'Dağ'],
  ),
  WallpaperItem(
    id: 'n4',
    title: 'Sessiz Kıyı',
    category: 'Doğa',
    asset: 'assets/wallpapers/nature_coast.jpg',
    tags: ['Deniz', 'Gün Batımı'],
  ),
  WallpaperItem(
    id: 'c1',
    title: 'Neon Şehir',
    category: 'Şehir',
    asset: 'assets/wallpapers/city_neon.jpg',
    tags: ['Neon', 'Gece', 'Şehir'],
  ),
  WallpaperItem(
    id: 'c2',
    title: 'Gün Batımı Metropolü',
    category: 'Şehir',
    asset: 'assets/wallpapers/city_dusk.jpg',
    tags: ['Şehir', 'Pembe', 'Gece'],
  ),
  WallpaperItem(
    id: 's1',
    title: 'Ayın Altında',
    category: 'Uzay',
    asset: 'assets/wallpapers/space_moon.jpg',
    tags: ['Ay', 'Gece', 'Yıldız'],
  ),
  WallpaperItem(
    id: 's2',
    title: 'Galaksi Akışı',
    category: 'Uzay',
    asset: 'assets/wallpapers/space_galaxy.jpg',
    tags: ['Galaksi', 'Mor', 'Uzay'],
  ),
  WallpaperItem(
    id: 'a1',
    title: 'Mor Akış',
    category: 'Soyut',
    asset: 'assets/wallpapers/abstract_violet.jpg',
    tags: ['Soyut', 'Mor', 'Neon'],
  ),
  WallpaperItem(
    id: 'a2',
    title: 'Okyanus Akışı',
    category: 'Soyut',
    asset: 'assets/wallpapers/abstract_ocean.jpg',
    tags: ['Soyut', 'Mavi', 'Minimal'],
  ),
  WallpaperItem(
    id: 'm1',
    title: 'Sessiz Küre',
    category: 'Minimal',
    asset: 'assets/wallpapers/minimal_orb.jpg',
    tags: ['Minimal', 'Koyu'],
  ),
  WallpaperItem(
    id: 'h1',
    title: 'Gece Gözcüsü',
    category: 'Hayvan',
    asset: 'assets/wallpapers/animal_night.jpg',
    tags: ['Hayvan', 'Gece'],
  ),
  WallpaperItem(
    id: 'an1',
    title: 'Alacakaranlık',
    category: 'Anime',
    asset: 'assets/wallpapers/anime_twilight.jpg',
    tags: ['Anime', 'Pembe'],
  ),
  WallpaperItem(
    id: 'v1',
    title: 'Gece Sürüşü',
    category: 'Araçlar',
    asset: 'assets/wallpapers/vehicle_night.jpg',
    tags: ['Araç', 'Gece', 'Neon'],
  ),
];

// Site kategori servisine ulaşılamazsa yalnızca arayüzün boş kalmaması için
// kullanılan son çare liste. Normal kullanımda kategori isimleri siteden gelir.
const localCategoryFallback = <CategoryItem>[
  CategoryItem(name: 'Hayvan', slug: 'hayvan'),
  CategoryItem(name: 'Anime', slug: 'anime'),
  CategoryItem(name: 'Doğa', slug: 'doga'),
  CategoryItem(name: 'Şehir', slug: 'sehir'),
  CategoryItem(name: 'Araçlar', slug: 'araclar'),
  CategoryItem(name: 'Oyun', slug: 'oyun'),
  CategoryItem(name: 'Uzay', slug: 'uzay'),
  CategoryItem(name: 'Minimal', slug: 'minimal'),
  CategoryItem(name: 'Soyut', slug: 'soyut'),
];
