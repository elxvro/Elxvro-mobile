import 'dart:async';
import 'package:flutter/material.dart';
import 'home_shell.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 1400), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        PageRouteBuilder(
          pageBuilder: (_, __, ___) => const HomeShell(),
          transitionsBuilder: (_, animation, __, child) => FadeTransition(opacity: animation, child: child),
          transitionDuration: const Duration(milliseconds: 500),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset('assets/wallpapers/nature_twilight_peak.jpg', fit: BoxFit.cover),
          Container(color: Colors.black.withValues(alpha: .38)),
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Colors.transparent, Color(0x55000000), Color(0xDD05070C)],
              ),
            ),
          ),
          SafeArea(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Spacer(flex: 5),
                const Text('E L X V R O', style: TextStyle(fontSize: 32, letterSpacing: 9, fontWeight: FontWeight.w300)),
                const SizedBox(height: 12),
                Text('Dünyanı yeniden yansıt', style: TextStyle(color: Colors.white.withValues(alpha: .78), fontSize: 16)),
                const Spacer(flex: 4),
                const Text('Her duvar, başka bir hikâye.', style: TextStyle(fontSize: 13, color: Colors.white70)),
                const SizedBox(height: 28),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
