import 'package:flutter/material.dart';

import '../app_state.dart';
import '../theme/app_theme.dart';

class SyncManagerScreen extends StatelessWidget {
  const SyncManagerScreen({super.key});

  String _time(DateTime? value) {
    if (value == null) return 'Henüz başarılı eşitleme yok';
    final local = value.toLocal();
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(local.day)}.${two(local.month)}.${local.year} '
        '${two(local.hour)}:${two(local.minute)}';
  }

  Future<void> _confirmCleanup(BuildContext context) async {
    final state = AppScope.of(context);
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Yerel artıklar temizlensin mi?'),
        content: const Text(
          'Yalnızca mevcut yerel katalogda kullanılmayan dosyalar ve yarım kalan .part dosyaları silinir. Aktif duvar kağıtlarına dokunulmaz.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Güvenli temizle'),
          ),
        ],
      ),
    );
    if (confirmed == true) await state.cleanupLocalMedia();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final busy = state.mediaSyncing || state.mediaCleaning;

    return Scaffold(
      appBar: AppBar(title: const Text('Sync Manager')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: AppTheme.surface,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: AppTheme.border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      state.mediaFailedLast > 0
                          ? Icons.sync_problem_rounded
                          : state.mediaSyncing
                              ? Icons.sync_rounded
                              : Icons.cloud_done_outlined,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        state.mediaSyncing ? 'Eşitleme sürüyor' : 'Yerel Mirror',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  state.mediaMessage,
                  style: const TextStyle(color: AppTheme.textSecondary, height: 1.4),
                ),
                if (state.mediaSyncing) ...[
                  const SizedBox(height: 14),
                  LinearProgressIndicator(
                    value: state.mediaTotal > 0 ? state.mediaProgress : null,
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Text(
                        state.mediaTotal > 0
                            ? '${state.mediaProcessed}/${state.mediaTotal}'
                            : 'Manifest okunuyor…',
                        style: const TextStyle(
                          fontSize: 12,
                          color: AppTheme.textSecondary,
                        ),
                      ),
                      const Spacer(),
                      if (state.mediaCurrentId.isNotEmpty)
                        Flexible(
                          child: Text(
                            state.mediaCurrentId,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 12,
                              color: AppTheme.textTertiary,
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
                const SizedBox(height: 14),
                Text(
                  'Son sunucu kontrolü: ${_time(state.mediaUpdatedAt)}',
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppTheme.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          _StatsGrid(state: state),
          const SizedBox(height: 14),
          FilledButton.icon(
            onPressed: busy ? null : () => state.refreshMedia(force: true),
            icon: state.mediaSyncing
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.sync_rounded),
            label: const Text('Tümünü çevrimdışı hazırla'),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: busy ? null : () => _confirmCleanup(context),
            icon: state.mediaCleaning
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.cleaning_services_outlined),
            label: const Text('Yerel artıkları güvenli temizle'),
          ),
          if (state.mediaCleanupMessage.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(
              state.mediaCleanupMessage,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary),
            ),
          ],
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.surface,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppTheme.border),
            ),
            child: Text(
              'Uygulama açılışta yalnızca küçük manifest listesini alır; ${state.mediaManifestCount} görselin tamamını bekletmez. Galeri hemen açılır. Bir görseli açtığında orijinal dosya çevrimdışı kullanım için uygulamanın özel alanına hazırlanır. İstersen tüm koleksiyonu tek seferde çevrimdışı hazır hale getirebilirsin.',
              style: const TextStyle(
                fontSize: 12,
                height: 1.5,
                color: AppTheme.textSecondary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatsGrid extends StatelessWidget {
  final AppState state;

  const _StatsGrid({required this.state});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = (constraints.maxWidth - 10) / 2;
        return Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            _StatCard(
              width: width,
              icon: Icons.cloud_outlined,
              label: 'Manifest',
              value: '${state.mediaManifestCount}',
            ),
            _StatCard(
              width: width,
              icon: Icons.phone_android_rounded,
              label: 'Cihazda',
              value: '${state.localMediaCount}',
            ),
            _StatCard(
              width: width,
              icon: Icons.download_done_rounded,
              label: 'Yeni / değişen',
              value: '${state.mediaDownloadedLast}',
            ),
            _StatCard(
              width: width,
              icon: Icons.check_circle_outline,
              label: 'Değişmemiş',
              value: '${state.mediaReusedLast}',
            ),
            _StatCard(
              width: width,
              icon: Icons.error_outline_rounded,
              label: 'Hata',
              value: '${state.mediaFailedLast}',
            ),
            _StatCard(
              width: width,
              icon: Icons.delete_sweep_outlined,
              label: 'Temizlenen',
              value: '${state.mediaRemovedLast}',
            ),
          ],
        );
      },
    );
  }
}

class _StatCard extends StatelessWidget {
  final double width;
  final IconData icon;
  final String label;
  final String value;

  const _StatCard({
    required this.width,
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) => Container(
        width: width,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppTheme.surface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppTheme.border),
        ),
        child: Row(
          children: [
            Icon(icon, size: 22),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    value,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  Text(
                    label,
                    style: const TextStyle(
                      fontSize: 11,
                      color: AppTheme.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
}
