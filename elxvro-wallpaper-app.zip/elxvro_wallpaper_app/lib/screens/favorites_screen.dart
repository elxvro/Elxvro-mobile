import 'package:flutter/material.dart';
import '../app_state.dart';
import '../widgets/wallpaper_card.dart';

class FavoritesScreen extends StatelessWidget {
  final bool standalone;

  const FavoritesScreen({
    super.key,
    this.standalone = false,
  });

  Widget _content(BuildContext context) {
    final state = AppScope.of(context);
    final items = state.favorites;
    final columns = state.compactGrid ? 3 : 2;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (!standalone)
          const Padding(
            padding: EdgeInsets.fromLTRB(18, 20, 18, 16),
            child: Text(
              'Favorilerim',
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800),
            ),
          ),
        Expanded(
          child: items.isEmpty
              ? const Center(
                  child: Text(
                    'Henüz favori eklemedin.',
                    style: TextStyle(color: Colors.white60),
                  ),
                )
              : GridView.builder(
                  padding: EdgeInsets.fromLTRB(
                    18,
                    standalone ? 8 : 0,
                    18,
                    24,
                  ),
                  itemCount: items.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: columns,
                    childAspectRatio: .62,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                  ),
                  itemBuilder: (_, index) => WallpaperCard(item: items[index]),
                ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    if (standalone) {
      return Scaffold(
        appBar: AppBar(title: const Text('Favorilerim')),
        body: _content(context),
      );
    }
    return SafeArea(child: _content(context));
  }
}
