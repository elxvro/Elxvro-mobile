import 'package:flutter/material.dart';
import '../app_state.dart';
import '../widgets/wallpaper_card.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final items = state.favorites;
    return SafeArea(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(18, 20, 18, 16),
            child: Text('Favorilerim', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
          ),
          Expanded(
            child: items.isEmpty
                ? const Center(child: Text('Henüz favori eklemedin.', style: TextStyle(color: Colors.white60)))
                : GridView.builder(
                    padding: const EdgeInsets.fromLTRB(18, 0, 18, 24),
                    itemCount: items.length,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: .62, crossAxisSpacing: 12, mainAxisSpacing: 12),
                    itemBuilder: (_, i) => WallpaperCard(item: items[i]),
                  ),
          ),
        ],
      ),
    );
  }
}
