import 'package:flutter/material.dart';

import '../app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/wallpaper_card.dart';

class FavoritesScreen extends StatelessWidget {
  final bool standalone;

  const FavoritesScreen({
    super.key,
    this.standalone = false,
  });

  Widget _content(BuildContext context) {
    final state = AppScope.of(context);
    final items = state.favorites;
    final columns = state.compactGrid ? 3 : 2;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (!standalone)
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 20, 18, 14),
            child: Row(
              children: [
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Favorilerim',
                        style: TextStyle(
                          fontSize: 27,
                          fontWeight: FontWeight.w900,
                          letterSpacing: -.4,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Beğendiğin duvar kağıtları tek yerde.',
                        style: TextStyle(
                          color: AppTheme.textSecondary,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                if (items.isNotEmpty)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: state.accentColor.withValues(alpha: .09),
                      borderRadius: BorderRadius.circular(13),
                    ),
                    child: Text(
                      '${items.length}',
                      style: TextStyle(
                        color: state.accentColor,
                        fontWeight: FontWeight.w900,
                        fontSize: 11,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        Expanded(
          child: items.isEmpty
              ? const _EmptyFavorites()
              : GridView.builder(
                  padding: EdgeInsets.fromLTRB(
                    18,
                    standalone ? 8 : 0,
                    18,
                    24,
                  ),
                  itemCount: items.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: columns,
                    childAspectRatio: .62,
                    crossAxisSpacing: 11,
                    mainAxisSpacing: 11,
                  ),
                  itemBuilder: (_, index) => WallpaperCard(item: items[index]),
                ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    if (standalone) {
      return Scaffold(
        appBar: AppBar(title: const Text('Favorilerim')),
        body: _content(context),
      );
    }
    return SafeArea(child: _content(context));
  }
}

class _EmptyFavorites extends StatelessWidget {
  const _EmptyFavorites();

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(34),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 72,
                height: 72,
                decoration: const BoxDecoration(
                  color: AppTheme.surfaceSoft,
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.favorite_border_rounded,
                  color: AppTheme.textSecondary,
                  size: 31,
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'Henüz favorin yok',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 6),
              const Text(
                'Beğendiğin görsellerde kalp simgesine dokun. Burada otomatik toplanırlar.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: AppTheme.textSecondary,
                  fontSize: 12,
                  height: 1.45,
                ),
              ),
            ],
          ),
        ),
      );
}
