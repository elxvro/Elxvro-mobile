import 'package:flutter/material.dart';
import '../app_state.dart';
import 'sync_manager_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  String _targetLabel(String value) {
    switch (value) {
      case 'home':
        return 'Ana ekran';
      case 'lock':
        return 'Kilit ekranı';
      case 'both':
        return 'İkisi birden';
      default:
        return 'Her seferinde sor';
    }
  }

  String _mediaTime(DateTime? value) {
    if (value == null) return 'Henüz sunucu kontrolü yapılmadı';
    final local = value.toLocal();
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(local.day)}.${two(local.month)}.${local.year} ${two(local.hour)}:${two(local.minute)}';
  }

  Future<void> _selectTarget(BuildContext context) async {
    final state = AppScope.of(context);
    final selected = await showModalBottomSheet<String>(
      context: context,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Varsayılan hedef',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 10),
              _TargetOption(
                value: 'ask',
                groupValue: state.defaultTarget,
                title: 'Her seferinde sor',
                icon: Icons.touch_app_outlined,
              ),
              _TargetOption(
                value: 'home',
                groupValue: state.defaultTarget,
                title: 'Ana ekran',
                icon: Icons.phone_android,
              ),
              _TargetOption(
                value: 'lock',
                groupValue: state.defaultTarget,
                title: 'Kilit ekranı',
                icon: Icons.lock_outline,
              ),
              _TargetOption(
                value: 'both',
                groupValue: state.defaultTarget,
                title: 'İkisi birden',
                icon: Icons.splitscreen,
              ),
            ],
          ),
        ),
      ),
    );
    if (selected != null) state.setDefaultTarget(selected);
  }

  Future<void> _confirmClear(
    BuildContext context, {
    required String title,
    required String message,
    required VoidCallback onConfirm,
  }) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Temizle'),
          ),
        ],
      ),
    );
    if (confirmed == true) onConfirm();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Ayarlar')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        children: [
          const _SectionTitle('Görünüm'),
          _SettingsCard(
            children: [
              SwitchListTile(
                value: state.oledMode,
                onChanged: state.setOledMode,
                secondary: const Icon(Icons.brightness_2_outlined),
                title: const Text('OLED siyah modu'),
                subtitle: const Text('Arka planı tam siyah yapar.'),
              ),
              SwitchListTile(
                value: state.compactGrid,
                onChanged: state.setCompactGrid,
                secondary: const Icon(Icons.grid_view_rounded),
                title: const Text('Kompakt galeri'),
                subtitle: const Text('Ekranda aynı anda daha fazla görsel gösterir.'),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Vurgu rengi',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        _AccentChoice(
                          keyName: 'violet',
                          color: const Color(0xFF8B6CFF),
                          selected: state.accent == 'violet',
                        ),
                        const SizedBox(width: 12),
                        _AccentChoice(
                          keyName: 'cyan',
                          color: const Color(0xFF48C7FF),
                          selected: state.accent == 'cyan',
                        ),
                        const SizedBox(width: 12),
                        _AccentChoice(
                          keyName: 'pink',
                          color: const Color(0xFFFF5E9B),
                          selected: state.accent == 'pink',
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          const _SectionTitle('Duvar kağıdı'),
          _SettingsCard(
            children: [
              ListTile(
                leading: const Icon(Icons.wallpaper_outlined),
                title: const Text('Varsayılan hedef'),
                subtitle: Text(_targetLabel(state.defaultTarget)),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _selectTarget(context),
              ),
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: Text(
                  'Bir hedef seçersen “Duvar Kağıdı Yap” düğmesi seçim ekranını atlayıp doğrudan o hedefe uygular.',
                  style: TextStyle(fontSize: 12, color: Colors.white54),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          const _SectionTitle('Yerel medya'),
          _SettingsCard(
            children: [
              ListTile(
                leading: state.mediaSyncing
                    ? const SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.sync_rounded),
                title: const Text('Sync Manager'),
                subtitle: Text(
                  '${state.visibleMediaCount} görsel • ${state.localMediaCount} çevrimdışı • ${state.mediaMessage}',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const SyncManagerScreen(),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Son sunucu kontrolü: ${_mediaTime(state.mediaUpdatedAt)}\nGörseller anında açılır; açtıkların cihazda çevrimdışı kullanım için hazırlanır.',
                    style: const TextStyle(
                      fontSize: 11,
                      height: 1.45,
                      color: Color(0x73FFFFFF),
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          const _SectionTitle('Yerel geçmiş'),
          _SettingsCard(
            children: [
              ListTile(
                leading: const Icon(Icons.history),
                title: const Text('Son görüntülenenleri temizle'),
                subtitle: Text('${state.recent.length} kayıt'),
                onTap: state.recent.isEmpty
                    ? null
                    : () => _confirmClear(
                          context,
                          title: 'Geçmiş temizlensin mi?',
                          message: 'Favorilerin etkilenmez.',
                          onConfirm: state.clearRecent,
                        ),
              ),
              ListTile(
                leading: const Icon(Icons.done_all_rounded),
                title: const Text('Uygulanan geçmişini temizle'),
                subtitle: Text('${state.applied.length} kayıt'),
                onTap: state.applied.isEmpty
                    ? null
                    : () => _confirmClear(
                          context,
                          title: 'Uygulanan geçmişi temizlensin mi?',
                          message: 'Bu işlem cihazdaki duvar kağıdını değiştirmez.',
                          onConfirm: state.clearApplied,
                        ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 8),
            child: Text(
              'Tüm tercihler yalnızca cihazında saklanır. Kullanıcıya görsel indirme veya galeriye kaydetme düğmesi sunulmaz.',
              style: TextStyle(fontSize: 11, color: Colors.white38),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(6, 0, 6, 8),
        child: Text(
          text,
          style: const TextStyle(
            fontSize: 13,
            color: Colors.white60,
            fontWeight: FontWeight.w700,
          ),
        ),
      );
}

class _SettingsCard extends StatelessWidget {
  final List<Widget> children;
  const _SettingsCard({required this.children});

  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(22),
        ),
        child: Column(children: children),
      );
}

class _AccentChoice extends StatelessWidget {
  final String keyName;
  final Color color;
  final bool selected;

  const _AccentChoice({
    required this.keyName,
    required this.color,
    required this.selected,
  });

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: () => AppScope.of(context).setAccent(keyName),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          width: 54,
          height: 42,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: selected ? Colors.white : Colors.white12,
              width: selected ? 2 : 1,
            ),
          ),
          child: Center(
            child: Container(
              width: 22,
              height: 22,
              decoration: BoxDecoration(color: color, shape: BoxShape.circle),
              child: selected
                  ? const Icon(Icons.check, size: 15, color: Colors.white)
                  : null,
            ),
          ),
        ),
      );
}

class _TargetOption extends StatelessWidget {
  final String value;
  final String groupValue;
  final String title;
  final IconData icon;

  const _TargetOption({
    required this.value,
    required this.groupValue,
    required this.title,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) => ListTile(
        onTap: () => Navigator.pop(context, value),
        leading: Icon(icon),
        title: Text(title),
        trailing: Icon(
          value == groupValue
              ? Icons.radio_button_checked
              : Icons.radio_button_off,
          color: value == groupValue
              ? Theme.of(context).colorScheme.primary
              : Colors.white38,
        ),
      );
}
