import 'package:flutter/material.dart';

import '../app_state.dart';
import '../theme/app_theme.dart';
import 'sync_manager_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  String _targetLabel(String value) {
    switch (value) {
      case 'home':
        return 'Ana ekran';
      case 'lock':
        return 'Kilit ekranı';
      case 'both':
        return 'İkisi birden';
      default:
        return 'Her seferinde sor';
    }
  }

  String _mediaTime(DateTime? value) {
    if (value == null) return 'Henüz sunucu kontrolü yapılmadı';
    final local = value.toLocal();
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(local.day)}.${two(local.month)}.${local.year} ${two(local.hour)}:${two(local.minute)}';
  }

  Future<void> _selectTarget(BuildContext context) async {
    final state = AppScope.of(context);
    final selected = await showModalBottomSheet<String>(
      context: context,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Varsayılan hedef',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 10),
              _TargetOption(
                value: 'ask',
                groupValue: state.defaultTarget,
                title: 'Her seferinde sor',
                icon: Icons.touch_app_outlined,
              ),
              _TargetOption(
                value: 'home',
                groupValue: state.defaultTarget,
                title: 'Ana ekran',
                icon: Icons.phone_android,
              ),
              _TargetOption(
                value: 'lock',
                groupValue: state.defaultTarget,
                title: 'Kilit ekranı',
                icon: Icons.lock_outline,
              ),
              _TargetOption(
                value: 'both',
                groupValue: state.defaultTarget,
                title: 'İkisi birden',
                icon: Icons.splitscreen,
              ),
            ],
          ),
        ),
      ),
    );
    if (selected != null) state.setDefaultTarget(selected);
  }

  Future<void> _confirmClear(
    BuildContext context, {
    required String title,
    required String message,
    required VoidCallback onConfirm,
  }) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Temizle'),
          ),
        ],
      ),
    );
    if (confirmed == true) onConfirm();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Ayarlar')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 30),
        children: [
          const _SectionTitle('Görünüm'),
          _SettingsCard(
            children: [
              ListTile(
                leading: _IconBox(
                  icon: Icons.light_mode_rounded,
                  color: state.accentColor,
                ),
                title: const Text(
                  'Açık tema',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
                subtitle: const Text(
                  'Yumuşak beyaz yüzeyler ve yüksek görsel kontrastı.',
                ),
                trailing: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                  decoration: BoxDecoration(
                    color: state.accentColor.withValues(alpha: .09),
                    borderRadius: BorderRadius.circular(11),
                  ),
                  child: Text(
                    'AKTİF',
                    style: TextStyle(
                      color: state.accentColor,
                      fontSize: 9,
                      fontWeight: FontWeight.w900,
                      letterSpacing: .6,
                    ),
                  ),
                ),
              ),
              const Divider(height: 1, indent: 16, endIndent: 16),
              SwitchListTile(
                value: state.compactGrid,
                onChanged: state.setCompactGrid,
                secondary: const Icon(Icons.grid_view_rounded),
                title: const Text('Kompakt galeri'),
                subtitle: const Text('Ekranda aynı anda daha fazla görsel gösterir.'),
              ),
              const Divider(height: 1, indent: 16, endIndent: 16),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 17),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Vurgu rengi',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'Butonlar ve seçili alanlarda kullanılır.',
                      style: TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 11,
                      ),
                    ),
                    const SizedBox(height: 13),
                    Row(
                      children: [
                        Expanded(
                          child: _AccentChoice(
                            keyName: 'violet',
                            label: 'İndigo',
                            color: const Color(0xFF5B5CE2),
                            selected: state.accent == 'violet',
                          ),
                        ),
                        const SizedBox(width: 9),
                        Expanded(
                          child: _AccentChoice(
                            keyName: 'cyan',
                            label: 'Turkuaz',
                            color: const Color(0xFF0D9AA6),
                            selected: state.accent == 'cyan',
                          ),
                        ),
                        const SizedBox(width: 9),
                        Expanded(
                          child: _AccentChoice(
                            keyName: 'pink',
                            label: 'Mercan',
                            color: const Color(0xFFDD4F78),
                            selected: state.accent == 'pink',
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 22),
          const _SectionTitle('Duvar kağıdı'),
          _SettingsCard(
            children: [
              ListTile(
                leading: const _IconBox(icon: Icons.wallpaper_outlined),
                title: const Text(
                  'Varsayılan hedef',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
                subtitle: Text(_targetLabel(state.defaultTarget)),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => _selectTarget(context),
              ),
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: Text(
                  'Bir hedef seçersen “Duvar Kağıdı Yap” düğmesi seçim ekranını atlayıp doğrudan o hedefe uygular.',
                  style: TextStyle(
                    fontSize: 11,
                    height: 1.45,
                    color: AppTheme.textSecondary,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 22),
          const _SectionTitle('Yerel medya'),
          _SettingsCard(
            children: [
              ListTile(
                leading: state.mediaSyncing
                    ? const SizedBox(
                        width: 40,
                        height: 40,
                        child: Padding(
                          padding: EdgeInsets.all(10),
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                      )
                    : const _IconBox(icon: Icons.sync_rounded),
                title: const Text(
                  'Sync Manager',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
                subtitle: Text(
                  '${state.visibleMediaCount} görsel • ${state.localMediaCount} çevrimdışı',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => const SyncManagerScreen()),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Son kontrol: ${_mediaTime(state.mediaUpdatedAt)}\n${state.mediaMessage}',
                    style: const TextStyle(
                      fontSize: 10.5,
                      height: 1.45,
                      color: AppTheme.textSecondary,
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 22),
          const _SectionTitle('Yerel geçmiş'),
          _SettingsCard(
            children: [
              ListTile(
                leading: const _IconBox(icon: Icons.history_rounded),
                title: const Text('Son görüntülenenleri temizle'),
                subtitle: Text('${state.recent.length} kayıt'),
                onTap: state.recent.isEmpty
                    ? null
                    : () => _confirmClear(
                          context,
                          title: 'Geçmiş temizlensin mi?',
                          message: 'Favorilerin etkilenmez.',
                          onConfirm: state.clearRecent,
                        ),
              ),
              const Divider(height: 1, indent: 16, endIndent: 16),
              ListTile(
                leading: const _IconBox(icon: Icons.done_all_rounded),
                title: const Text('Uygulanan geçmişini temizle'),
                subtitle: Text('${state.applied.length} kayıt'),
                onTap: state.applied.isEmpty
                    ? null
                    : () => _confirmClear(
                          context,
                          title: 'Uygulanan geçmişi temizlensin mi?',
                          message: 'Bu işlem cihazdaki duvar kağıdını değiştirmez.',
                          onConfirm: state.clearApplied,
                        ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 8),
            child: Text(
              'Tercihler cihazında saklanır. ELXVRO görselleri galeriye kaydetmez; duvar kağıdı olarak uygular.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 10.5,
                height: 1.4,
                color: AppTheme.textTertiary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(6, 0, 6, 8),
        child: Text(
          text.toUpperCase(),
          style: const TextStyle(
            fontSize: 10,
            letterSpacing: .9,
            color: AppTheme.textSecondary,
            fontWeight: FontWeight.w800,
          ),
        ),
      );
}

class _SettingsCard extends StatelessWidget {
  final List<Widget> children;
  const _SettingsCard({required this.children});

  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(
          color: AppTheme.surface,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: AppTheme.border),
          boxShadow: const [
            BoxShadow(
              color: Color(0x0A121826),
              blurRadius: 18,
              offset: Offset(0, 7),
            ),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(children: children),
      );
}

class _IconBox extends StatelessWidget {
  final IconData icon;
  final Color? color;

  const _IconBox({required this.icon, this.color});

  @override
  Widget build(BuildContext context) {
    final effective = color ?? AppScope.of(context).accentColor;
    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        color: effective.withValues(alpha: .08),
        borderRadius: BorderRadius.circular(13),
      ),
      child: Icon(icon, size: 20, color: effective),
    );
  }
}

class _AccentChoice extends StatelessWidget {
  final String keyName;
  final String label;
  final Color color;
  final bool selected;

  const _AccentChoice({
    required this.keyName,
    required this.label,
    required this.color,
    required this.selected,
  });

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: () => AppScope.of(context).setAccent(keyName),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 9),
          decoration: BoxDecoration(
            color: selected ? color.withValues(alpha: .08) : AppTheme.surfaceSoft,
            borderRadius: BorderRadius.circular(15),
            border: Border.all(
              color: selected ? color.withValues(alpha: .65) : AppTheme.border,
              width: selected ? 1.5 : 1,
            ),
          ),
          child: Column(
            children: [
              Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                child: selected
                    ? const Icon(Icons.check_rounded, size: 15, color: Colors.white)
                    : null,
              ),
              const SizedBox(height: 6),
              Text(
                label,
                maxLines: 1,
                style: TextStyle(
                  color: selected ? color : AppTheme.textSecondary,
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
      );
}

class _TargetOption extends StatelessWidget {
  final String value;
  final String groupValue;
  final String title;
  final IconData icon;

  const _TargetOption({
    required this.value,
    required this.groupValue,
    required this.title,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) => ListTile(
        onTap: () => Navigator.pop(context, value),
        leading: Icon(icon),
        title: Text(title),
        trailing: Icon(
          value == groupValue
              ? Icons.radio_button_checked
              : Icons.radio_button_off,
          color: value == groupValue
              ? Theme.of(context).colorScheme.primary
              : AppTheme.textTertiary,
        ),
      );
}
