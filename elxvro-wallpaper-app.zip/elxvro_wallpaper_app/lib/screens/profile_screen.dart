import 'package:flutter/material.dart';
import '../app_state.dart';
import 'collections_screen.dart';
import 'favorites_screen.dart';
import 'recent_screen.dart';
import 'settings_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  void _showPrivacy(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Gizlilik'),
        content: const Text(
          'ELXVRO görselleri indirme özelliği sunmaz. Favoriler, son görüntülenenler, uygulanan duvar kağıtları ve görünüm tercihleri yalnızca cihazında yerel olarak saklanır. Düzenleme işlemleri görsel dosyası olarak dışarı aktarılmaz; yalnızca duvar kağıdına uygulanır.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tamam'),
          ),
        ],
      ),
    );
  }

  void _showAbout(BuildContext context) {
    showAboutDialog(
      context: context,
      applicationName: 'ELXVRO',
      applicationVersion: '1.0.8',
      applicationLegalese: 'Keşfet, önizle ve doğrudan duvar kağıdı yap.',
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final lastApplied = state.lastApplied;

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 20, 18, 24),
        children: [
          const Text(
            'Profil',
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 18),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              borderRadius: BorderRadius.circular(24),
            ),
            child: const Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundImage:
                      AssetImage('assets/wallpapers/nature_aurora.jpg'),
                ),
                SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'ELXVRO',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 18,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Duvar kağıdını indirmen gerekmez.',
                        style: TextStyle(color: Colors.white54, fontSize: 12),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: _StatCard(
                  value: '${state.favorites.length}',
                  label: 'Favori',
                  icon: Icons.favorite_rounded,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _StatCard(
                  value: '${state.applied.length}',
                  label: 'Uygulandı',
                  icon: Icons.done_all_rounded,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _StatCard(
                  value: '${state.recent.length}',
                  label: 'Geçmiş',
                  icon: Icons.history_rounded,
                ),
              ),
            ],
          ),
          if (lastApplied != null) ...[
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(14),
                    child: Image.asset(
                      lastApplied.asset,
                      width: 54,
                      height: 72,
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Son uygulanan',
                          style: TextStyle(fontSize: 11, color: Colors.white54),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          lastApplied.title,
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                        Text(
                          lastApplied.category,
                          style: const TextStyle(
                            fontSize: 11,
                            color: Colors.white54,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Icon(Icons.check_circle_outline_rounded),
                ],
              ),
            ),
          ],
          const SizedBox(height: 20),
          _Tile(
            icon: Icons.favorite_outline,
            title: 'Favorilerim',
            trailing: '${state.favorites.length}',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => const FavoritesScreen(standalone: true),
              ),
            ),
          ),
          _Tile(
            icon: Icons.auto_awesome_mosaic_outlined,
            title: 'Koleksiyonlar',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const CollectionsScreen()),
            ),
          ),
          _Tile(
            icon: Icons.history,
            title: 'Son görüntülenenler',
            trailing: '${state.recent.length}',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const RecentScreen()),
            ),
          ),
          _Tile(
            icon: Icons.settings_outlined,
            title: 'Ayarlar',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ),
          ),
          _Tile(
            icon: Icons.shield_outlined,
            title: 'Gizlilik Politikası',
            onTap: () => _showPrivacy(context),
          ),
          _Tile(
            icon: Icons.info_outline,
            title: 'Hakkında',
            onTap: () => _showAbout(context),
          ),
          const SizedBox(height: 24),
          const Center(
            child: Text(
              'ELXVRO v1.0.8',
              style: TextStyle(color: Colors.white38, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String value;
  final String label;
  final IconData icon;

  const _StatCard({
    required this.value,
    required this.label,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Column(
          children: [
            Icon(icon, size: 18, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 6),
            Text(
              value,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
            ),
            Text(
              label,
              style: const TextStyle(fontSize: 10, color: Colors.white54),
            ),
          ],
        ),
      );
}

class _Tile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? trailing;
  final VoidCallback onTap;

  const _Tile({
    required this.icon,
    required this.title,
    required this.onTap,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(18),
        ),
        child: ListTile(
          onTap: onTap,
          leading: Icon(icon),
          title: Text(title),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (trailing != null) ...[
                Text(
                  trailing!,
                  style: const TextStyle(color: Colors.white54),
                ),
                const SizedBox(width: 6),
              ],
              const Icon(Icons.chevron_right),
            ],
          ),
        ),
      );
}
