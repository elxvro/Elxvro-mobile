import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../app_state.dart';
import 'collections_screen.dart';
import 'favorites_screen.dart';
import 'recent_screen.dart';
import 'settings_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final GoogleSignIn _googleSignIn = GoogleSignIn(
    scopes: const <String>['email'],
  );

  StreamSubscription<GoogleSignInAccount?>? _accountSubscription;
  GoogleSignInAccount? _account;
  bool _restoringSession = true;
  bool _busy = false;
  String? _authError;

  @override
  void initState() {
    super.initState();
    _accountSubscription = _googleSignIn.onCurrentUserChanged.listen((account) {
      if (!mounted) return;
      setState(() {
        _account = account;
        _restoringSession = false;
        _authError = null;
      });
    });
    _restoreSession();
  }

  @override
  void dispose() {
    _accountSubscription?.cancel();
    super.dispose();
  }

  Future<void> _restoreSession() async {
    try {
      final account = await _googleSignIn.signInSilently();
      if (!mounted) return;
      setState(() {
        _account = account;
        _restoringSession = false;
      });
    } on PlatformException {
      if (!mounted) return;
      setState(() => _restoringSession = false);
    } catch (_) {
      if (!mounted) return;
      setState(() => _restoringSession = false);
    }
  }

  Future<void> _signIn() async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _authError = null;
    });
    try {
      final account = await _googleSignIn.signIn();
      if (!mounted) return;
      setState(() => _account = account);
    } on PlatformException catch (error) {
      if (!mounted) return;
      setState(() => _authError = _friendlyAuthError(error));
    } catch (_) {
      if (!mounted) return;
      setState(
        () => _authError =
            'Google ile giriş başlatılamadı. İnternet bağlantını ve Google yapılandırmasını kontrol et.',
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _friendlyAuthError(PlatformException error) {
    final details = '${error.code} ${error.message ?? ''}'.toLowerCase();
    if (details.contains('sign_in_canceled') || details.contains('cancel')) {
      return 'Google ile giriş iptal edildi.';
    }
    if (details.contains('network')) {
      return 'İnternet bağlantısı kurulamadı.';
    }
    if (details.contains('10') ||
        details.contains('developer_error') ||
        details.contains('configuration')) {
      return 'Google OAuth yapılandırması tamamlanmamış. Paket adı ve SHA-1 kaydını kontrol et.';
    }
    return 'Google ile giriş yapılamadı. Lütfen tekrar dene.';
  }

  Future<void> _signOut() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await _googleSignIn.signOut();
      if (!mounted) return;
      setState(() => _account = null);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _deleteElxvroAccount() async {
    final state = AppScope.of(context);
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        icon: const Icon(Icons.delete_forever_outlined, color: Colors.redAccent),
        title: const Text('ELXVRO hesabını sil?'),
        content: const Text(
          'Bu işlem Google hesabını silmez. ELXVRO ile Google bağlantısını kaldırır; favorilerini, son görüntülenenlerini, uyguladıklarını ve uygulama tercihlerini bu cihazdan kalıcı olarak temizler.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.redAccent),
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Hesabı Sil'),
          ),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;
    setState(() => _busy = true);
    try {
      await state.resetUserData();
      try {
        await _googleSignIn.disconnect();
      } catch (_) {
        await _googleSignIn.signOut();
      }
      if (!mounted) return;
      setState(() => _account = null);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('ELXVRO hesap verileri silindi.')),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _showPrivacy() {
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Gizlilik'),
        content: const Text(
          'ELXVRO profilinde yalnızca Google ile giriş kullanılır. Uygulama; favoriler, son görüntülenenler, uygulanan duvar kağıtları ve görünüm tercihlerini bu sürümde cihazda yerel olarak saklar. Google hesabının parolası ELXVRO tarafından görülmez veya saklanmaz.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Tamam'),
          ),
        ],
      ),
    );
  }

  void _showAbout() {
    showAboutDialog(
      context: context,
      applicationName: 'ELXVRO',
      applicationVersion: '1.0.9',
      applicationLegalese: 'Keşfet, düzenle ve doğrudan duvar kağıdı yap.',
    );
  }

  void _showDataManagement() {
    final state = AppScope.of(context);
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 4, 18, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Yerel verilerim',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 6),
              const Text(
                'Bu işlemler Google hesabını etkilemez.',
                style: TextStyle(color: Colors.white54),
              ),
              const SizedBox(height: 14),
              _DataAction(
                icon: Icons.favorite_outline_rounded,
                title: 'Favorileri temizle',
                subtitle: '${state.favorites.length} kayıt',
                enabled: state.favorites.isNotEmpty,
                onTap: () {
                  state.clearFavorites();
                  Navigator.pop(sheetContext);
                },
              ),
              _DataAction(
                icon: Icons.history_rounded,
                title: 'Görüntüleme geçmişini temizle',
                subtitle: '${state.recent.length} kayıt',
                enabled: state.recent.isNotEmpty,
                onTap: () {
                  state.clearRecent();
                  Navigator.pop(sheetContext);
                },
              ),
              _DataAction(
                icon: Icons.done_all_rounded,
                title: 'Uygulama geçmişini temizle',
                subtitle: '${state.applied.length} kayıt',
                enabled: state.applied.isNotEmpty,
                onTap: () {
                  state.clearApplied();
                  Navigator.pop(sheetContext);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_restoringSession) {
      return const SafeArea(
        child: Center(child: CircularProgressIndicator()),
      );
    }

    if (_account == null) {
      return _SignedOutProfile(
        busy: _busy,
        error: _authError,
        onSignIn: _signIn,
      );
    }

    return _SignedInProfile(
      account: _account!,
      busy: _busy,
      onSignOut: _signOut,
      onDeleteAccount: _deleteElxvroAccount,
      onShowPrivacy: _showPrivacy,
      onShowAbout: _showAbout,
      onShowDataManagement: _showDataManagement,
    );
  }
}

class _SignedOutProfile extends StatelessWidget {
  final bool busy;
  final String? error;
  final VoidCallback onSignIn;

  const _SignedOutProfile({
    required this.busy,
    required this.error,
    required this.onSignIn,
  });

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 28),
        children: [
          const Text(
            'Profil',
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 42),
          Center(
            child: Container(
              width: 92,
              height: 92,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [primary, primary.withValues(alpha: .35)],
                ),
              ),
              child: const Icon(Icons.person_rounded, size: 44),
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'ELXVRO hesabına giriş yap',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 10),
          const Text(
            'Profil alanı yalnızca Google hesabıyla açılır. Ayrı parola veya ELXVRO kayıt formu yok.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white60, height: 1.45),
          ),
          const SizedBox(height: 28),
          FilledButton(
            onPressed: busy ? null : onSignIn,
            style: FilledButton.styleFrom(
              minimumSize: const Size.fromHeight(56),
              backgroundColor: Colors.white,
              foregroundColor: Colors.black,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
              ),
            ),
            child: busy
                ? const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _GoogleMark(),
                      SizedBox(width: 12),
                      Text(
                        'Google ile devam et',
                        style: TextStyle(fontWeight: FontWeight.w800),
                      ),
                    ],
                  ),
          ),
          if (error != null) ...[
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.redAccent.withValues(alpha: .12),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: Colors.redAccent.withValues(alpha: .25),
                ),
              ),
              child: Text(
                error!,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.redAccent, fontSize: 12),
              ),
            ),
          ],
          const SizedBox(height: 28),
          const _InfoRow(
            icon: Icons.lock_outline_rounded,
            title: 'Parola istemez',
            subtitle: 'Kimlik doğrulama Google tarafından yapılır.',
          ),
          const _InfoRow(
            icon: Icons.cloud_off_outlined,
            title: 'Wallpaper kullanımın yerelde kalır',
            subtitle: 'Favori ve geçmiş bilgileri bu sürümde cihazında tutulur.',
          ),
          const _InfoRow(
            icon: Icons.delete_outline_rounded,
            title: 'Hesap kontrolü sende',
            subtitle: 'Profilinden çıkış yapabilir veya ELXVRO verilerini silebilirsin.',
          ),
        ],
      ),
    );
  }
}

class _SignedInProfile extends StatelessWidget {
  final GoogleSignInAccount account;
  final bool busy;
  final Future<void> Function() onSignOut;
  final Future<void> Function() onDeleteAccount;
  final VoidCallback onShowPrivacy;
  final VoidCallback onShowAbout;
  final VoidCallback onShowDataManagement;

  const _SignedInProfile({
    required this.account,
    required this.busy,
    required this.onSignOut,
    required this.onDeleteAccount,
    required this.onShowPrivacy,
    required this.onShowAbout,
    required this.onShowDataManagement,
  });

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final lastApplied = state.lastApplied;

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 20, 18, 30),
        children: [
          const Text(
            'Profil',
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 18),
          _ProfileHeader(account: account),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: _StatCard(
                  value: '${state.favorites.length}',
                  label: 'Favori',
                  icon: Icons.favorite_rounded,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _StatCard(
                  value: '${state.applied.length}',
                  label: 'Uygulandı',
                  icon: Icons.done_all_rounded,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _StatCard(
                  value: '${state.recent.length}',
                  label: 'Geçmiş',
                  icon: Icons.history_rounded,
                ),
              ),
            ],
          ),
          if (lastApplied != null) ...[
            const SizedBox(height: 14),
            _LastAppliedCard(itemTitle: lastApplied.title, asset: lastApplied.asset),
          ],
          const SizedBox(height: 24),
          const _SectionTitle('Kitaplığım'),
          _ProfileTile(
            icon: Icons.favorite_outline_rounded,
            title: 'Favorilerim',
            subtitle: '${state.favorites.length} duvar kağıdı',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => const FavoritesScreen(standalone: true),
              ),
            ),
          ),
          _ProfileTile(
            icon: Icons.done_all_rounded,
            title: 'Uyguladıklarım',
            subtitle: '${state.applied.length} kayıt',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => const CollectionWallpapersScreen(
                  mode: CollectionMode.applied,
                ),
              ),
            ),
          ),
          _ProfileTile(
            icon: Icons.history_rounded,
            title: 'Son görüntülenenler',
            subtitle: '${state.recent.length} kayıt',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const RecentScreen()),
            ),
          ),
          _ProfileTile(
            icon: Icons.auto_awesome_mosaic_outlined,
            title: 'Koleksiyonlar',
            subtitle: 'Akıllı gruplarını görüntüle',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const CollectionsScreen()),
            ),
          ),
          const SizedBox(height: 14),
          const _SectionTitle('Kişiselleştirme'),
          _ProfileTile(
            icon: Icons.tune_rounded,
            title: 'Uygulama ayarları',
            subtitle: 'Tema, galeri görünümü ve wallpaper hedefi',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ),
          ),
          const SizedBox(height: 14),
          const _SectionTitle('Hesap ve gizlilik'),
          _ProfileTile(
            icon: Icons.storage_outlined,
            title: 'Yerel verilerim',
            subtitle: 'Favori ve geçmiş kayıtlarını yönet',
            onTap: onShowDataManagement,
          ),
          _ProfileTile(
            icon: Icons.shield_outlined,
            title: 'Gizlilik',
            subtitle: 'ELXVRO hangi verileri kullanıyor?',
            onTap: onShowPrivacy,
          ),
          _ProfileTile(
            icon: Icons.info_outline_rounded,
            title: 'Hakkında',
            subtitle: 'ELXVRO v1.0.9',
            onTap: onShowAbout,
          ),
          const SizedBox(height: 16),
          OutlinedButton.icon(
            onPressed: busy ? null : onSignOut,
            icon: const Icon(Icons.logout_rounded),
            label: const Text('Google hesabından çıkış yap'),
            style: OutlinedButton.styleFrom(
              minimumSize: const Size.fromHeight(52),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
          ),
          const SizedBox(height: 12),
          TextButton.icon(
            onPressed: busy ? null : onDeleteAccount,
            icon: const Icon(Icons.delete_forever_outlined),
            label: const Text('ELXVRO hesabını sil'),
            style: TextButton.styleFrom(
              foregroundColor: Colors.redAccent,
              minimumSize: const Size.fromHeight(50),
            ),
          ),
          const SizedBox(height: 16),
          const Center(
            child: Text(
              'ELXVRO v1.0.9',
              style: TextStyle(color: Colors.white38, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }
}

class _ProfileHeader extends StatelessWidget {
  final GoogleSignInAccount account;

  const _ProfileHeader({required this.account});

  @override
  Widget build(BuildContext context) {
    final photoUrl = account.photoUrl;
    final displayName = account.displayName?.trim();
    final name = displayName == null || displayName.isEmpty
        ? account.email.split('@').first
        : displayName;

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(24),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 32,
            backgroundColor:
                Theme.of(context).colorScheme.primary.withValues(alpha: .18),
            backgroundImage:
                photoUrl == null ? null : NetworkImage(photoUrl),
            child: photoUrl == null
                ? Text(
                    name.substring(0, 1).toUpperCase(),
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                    ),
                  )
                : null,
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  account.email,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white54, fontSize: 12),
                ),
                const SizedBox(height: 8),
                const Row(
                  children: [
                    Icon(Icons.verified_rounded, size: 14, color: Colors.greenAccent),
                    SizedBox(width: 5),
                    Text(
                      'Google ile bağlı',
                      style: TextStyle(color: Colors.white60, fontSize: 11),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _LastAppliedCard extends StatelessWidget {
  final String itemTitle;
  final String asset;

  const _LastAppliedCard({required this.itemTitle, required this.asset});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: Image.asset(asset, width: 54, height: 72, fit: BoxFit.cover),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Son uygulanan',
                    style: TextStyle(fontSize: 11, color: Colors.white54),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    itemTitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                ],
              ),
            ),
            const Icon(Icons.check_circle_outline_rounded),
          ],
        ),
      );
}

class _StatCard extends StatelessWidget {
  final String value;
  final String label;
  final IconData icon;

  const _StatCard({
    required this.value,
    required this.label,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Column(
          children: [
            Icon(icon, size: 18, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 6),
            Text(
              value,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
            ),
            Text(
              label,
              style: const TextStyle(fontSize: 10, color: Colors.white54),
            ),
          ],
        ),
      );
}

class _SectionTitle extends StatelessWidget {
  final String text;

  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 0, 4, 9),
        child: Text(
          text,
          style: const TextStyle(
            color: Colors.white54,
            fontSize: 12,
            fontWeight: FontWeight.w700,
          ),
        ),
      );
}

class _ProfileTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _ProfileTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 9),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(18),
        ),
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 4),
          onTap: onTap,
          leading: Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primary.withValues(alpha: .12),
              borderRadius: BorderRadius.circular(13),
            ),
            child: Icon(icon, size: 20),
          ),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(
            subtitle,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.white38, fontSize: 11),
          ),
          trailing: const Icon(Icons.chevron_right_rounded),
        ),
      );
}

class _DataAction extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final bool enabled;
  final VoidCallback onTap;

  const _DataAction({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.enabled,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => ListTile(
        enabled: enabled,
        contentPadding: EdgeInsets.zero,
        onTap: enabled ? onTap : null,
        leading: Icon(icon),
        title: Text(title),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right_rounded),
      );
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const _InfoRow({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 18),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    style: const TextStyle(color: Colors.white54, fontSize: 12),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
}

class _GoogleMark extends StatelessWidget {
  const _GoogleMark();

  @override
  Widget build(BuildContext context) => Container(
        width: 24,
        height: 24,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: const Color(0xFFE3E3E3)),
        ),
        child: const Text(
          'G',
          style: TextStyle(
            color: Color(0xFF4285F4),
            fontSize: 17,
            fontWeight: FontWeight.w900,
          ),
        ),
      );
}
