import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 20, 18, 24),
        children: [
          Row(children: [
            const Expanded(child: Text('Profil', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800))),
            IconButton(onPressed: () {}, icon: const Icon(Icons.settings_outlined)),
          ]),
          const SizedBox(height: 18),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: const Color(0xFF111722), borderRadius: BorderRadius.circular(24)),
            child: const Row(children: [
              CircleAvatar(radius: 30, backgroundImage: AssetImage('assets/wallpapers/nature_aurora.jpg')),
              SizedBox(width: 14),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('ELXVRO', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                SizedBox(height: 4),
                Text('Daha güzel duvarlar, daha güzel yarınlar.', style: TextStyle(color: Colors.white54, fontSize: 12)),
              ]),
            ]),
          ),
          const SizedBox(height: 20),
          const _Tile(icon: Icons.favorite_outline, title: 'Favorilerim'),
          const _Tile(icon: Icons.history, title: 'Son görüntülenenler'),
          const _Tile(icon: Icons.shield_outlined, title: 'Gizlilik Politikası'),
          const _Tile(icon: Icons.info_outline, title: 'Hakkında'),
          const SizedBox(height: 24),
          const Center(child: Text('ELXVRO v1.0.0', style: TextStyle(color: Colors.white38, fontSize: 12))),
        ],
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  final IconData icon;
  final String title;
  const _Tile({required this.icon, required this.title});
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 10),
    decoration: BoxDecoration(color: const Color(0xFF111722), borderRadius: BorderRadius.circular(18)),
    child: ListTile(leading: Icon(icon), title: Text(title), trailing: const Icon(Icons.chevron_right)),
  );
}
