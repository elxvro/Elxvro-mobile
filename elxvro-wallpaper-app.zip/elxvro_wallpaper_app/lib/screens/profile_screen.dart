import 'package:flutter/material.dart';
import '../app_state.dart';
import 'favorites_screen.dart';
import 'recent_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  void _showPrivacy(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Gizlilik'),
        content: const Text(
          'Bu demo sürümünde duvar kağıtları cihazdan indirilmez ve uygulama kişisel veri toplamaz. Favoriler ve son görüntülenenler yalnızca uygulama oturumu boyunca tutulur.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tamam'),
          ),
        ],
      ),
    );
  }

  void _showAbout(BuildContext context) {
    showAboutDialog(
      context: context,
      applicationName: 'ELXVRO',
      applicationVersion: '1.0.3',
      applicationLegalese: 'Sadece keşfet, önizle ve duvar kağıdı yap.',
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 20, 18, 24),
        children: [
          const Text(
            'Profil',
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 18),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: const Color(0xFF111722),
              borderRadius: BorderRadius.circular(24),
            ),
            child: const Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundImage:
                      AssetImage('assets/wallpapers/nature_aurora.jpg'),
                ),
                SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'ELXVRO',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 18,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Daha güzel duvarlar, daha güzel yarınlar.',
                        style: TextStyle(color: Colors.white54, fontSize: 12),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          _Tile(
            icon: Icons.favorite_outline,
            title: 'Favorilerim',
            trailing: '${state.favorites.length}',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => const FavoritesScreen(standalone: true),
              ),
            ),
          ),
          _Tile(
            icon: Icons.history,
            title: 'Son görüntülenenler',
            trailing: '${state.recent.length}',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const RecentScreen()),
            ),
          ),
          _Tile(
            icon: Icons.shield_outlined,
            title: 'Gizlilik Politikası',
            onTap: () => _showPrivacy(context),
          ),
          _Tile(
            icon: Icons.info_outline,
            title: 'Hakkında',
            onTap: () => _showAbout(context),
          ),
          const SizedBox(height: 24),
          const Center(
            child: Text(
              'ELXVRO v1.0.3',
              style: TextStyle(color: Colors.white38, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? trailing;
  final VoidCallback onTap;

  const _Tile({
    required this.icon,
    required this.title,
    required this.onTap,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: const Color(0xFF111722),
          borderRadius: BorderRadius.circular(18),
        ),
        child: ListTile(
          onTap: onTap,
          leading: Icon(icon),
          title: Text(title),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (trailing != null) ...[
                Text(
                  trailing!,
                  style: const TextStyle(color: Colors.white54),
                ),
                const SizedBox(width: 6),
              ],
              const Icon(Icons.chevron_right),
            ],
          ),
        ),
      );
}
