import 'package:flutter/material.dart';
import '../app_state.dart';
import '../widgets/wallpaper_card.dart';

class RecentScreen extends StatelessWidget {
  const RecentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final items = state.recent;
    final columns = state.compactGrid ? 3 : 2;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Son Görüntülenenler'),
        actions: [
          if (items.isNotEmpty)
            TextButton(
              onPressed: state.clearRecent,
              child: const Text('Temizle'),
            ),
        ],
      ),
      body: items.isEmpty
          ? const Center(
              child: Text(
                'Henüz bir duvar kağıdı görüntülemedin.',
                style: TextStyle(color: Colors.white60),
              ),
            )
          : GridView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              itemCount: items.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: columns,
                childAspectRatio: .62,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
              ),
              itemBuilder: (_, index) => WallpaperCard(item: items[index]),
            ),
    );
  }
}
