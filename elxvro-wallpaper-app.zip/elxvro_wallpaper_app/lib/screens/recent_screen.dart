import 'package:flutter/material.dart';
import '../app_state.dart';
import '../widgets/wallpaper_card.dart';

class RecentScreen extends StatelessWidget {
  const RecentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final items = state.recent;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Son Görüntülenenler'),
        backgroundColor: Colors.transparent,
        actions: [
          if (items.isNotEmpty)
            TextButton(
              onPressed: state.clearRecent,
              child: const Text('Temizle'),
            ),
        ],
      ),
      body: items.isEmpty
          ? const Center(
              child: Text(
                'Henüz bir duvar kağıdı görüntülemedin.',
                style: TextStyle(color: Colors.white60),
              ),
            )
          : GridView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              itemCount: items.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: .62,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
              ),
              itemBuilder: (_, index) => WallpaperCard(item: items[index]),
            ),
    );
  }
}
