import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../app_state.dart';
import '../services/drive_backup_service.dart';
import '../theme/app_theme.dart';

class BackupScreen extends StatefulWidget {
  final GoogleSignInAccount account;

  const BackupScreen({super.key, required this.account});

  @override
  State<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends State<BackupScreen> {
  DriveBackupInfo? _info;
  bool _checking = true;
  bool _busy = false;
  String? _message;

  @override
  void initState() {
    super.initState();
    _refreshStatus();
  }

  Future<void> _refreshStatus() async {
    try {
      final info = await DriveBackupService.status(widget.account);
      if (!mounted) return;
      setState(() {
        _info = info;
        _checking = false;
      });
    } catch (_) {
      if (mounted) setState(() => _checking = false);
    }
  }

  Future<void> _backupNow() async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _message = null;
    });
    try {
      final state = AppScope.of(context);
      final data = state.exportBackupData();
      data['account_email'] = widget.account.email;
      final info = await DriveBackupService.backup(
        account: widget.account,
        data: data,
      );
      if (!mounted) return;
      setState(() {
        _info = info;
        _message = 'Yedek Google Drive’a güvenle kaydedildi.';
      });
    } on DriveBackupException catch (error) {
      if (mounted) setState(() => _message = error.message);
    } catch (_) {
      if (mounted) setState(() => _message = 'Yedekleme tamamlanamadı.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _restore() async {
    if (_busy) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        icon: const Icon(Icons.restore_rounded),
        title: const Text('Drive yedeği geri yüklensin mi?'),
        content: const Text(
          'Favoriler, son görüntülenenler, uygulananlar ve desteklenen uygulama ayarları bu cihazdaki mevcut verilerin üzerine yazılır.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Geri Yükle'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;

    setState(() {
      _busy = true;
      _message = null;
    });
    try {
      final data = await DriveBackupService.restore(account: widget.account);
      final backupEmail = '${data['account_email'] ?? ''}'.trim().toLowerCase();
      if (backupEmail.isNotEmpty &&
          backupEmail != widget.account.email.trim().toLowerCase()) {
        throw const FormatException('Bu Drive yedeği farklı bir Google hesabına ait.');
      }
      if (!mounted) return;
      await AppScope.of(context).importBackupData(data);
      if (!mounted) return;
      setState(() => _message = 'Drive yedeği bu cihaza geri yüklendi.');
    } on DriveBackupException catch (error) {
      if (mounted) setState(() => _message = error.message);
    } on FormatException catch (error) {
      if (mounted) setState(() => _message = error.message);
    } catch (_) {
      if (mounted) setState(() => _message = 'Yedek geri yüklenemedi.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _dateLabel(DateTime? date) {
    if (date == null) return 'Henüz yedek yok';
    final local = date.toLocal();
    String two(int value) => value.toString().padLeft(2, '0');
    return '${two(local.day)}.${two(local.month)}.${local.year} • ${two(local.hour)}:${two(local.minute)}';
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final accent = state.accentColor;
    return Scaffold(
      appBar: AppBar(title: const Text('Google Drive Yedekleme')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 30),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFFF3E8FF), Color(0xFFFDFCFF)],
                ),
                borderRadius: BorderRadius.circular(26),
                border: Border.all(color: const Color(0xFFE8D5FF)),
              ),
              child: Column(
                children: [
                  Container(
                    width: 72,
                    height: 72,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: accent.withValues(alpha: .16),
                          blurRadius: 24,
                          offset: const Offset(0, 9),
                        ),
                      ],
                    ),
                    child: Icon(Icons.cloud_done_rounded, size: 36, color: accent),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Verilerin sende, yedeğin Drive’da',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    widget.account.email,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _BackupStatusCard(
              checking: _checking,
              connected: _info != null,
              date: _dateLabel(_info?.modifiedAt),
              fileName: DriveBackupService.fileName,
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: _busy ? null : _backupNow,
              icon: _busy
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.cloud_upload_rounded),
              label: Text(_busy ? 'İşleniyor...' : 'Şimdi Drive’a Yedekle'),
              style: FilledButton.styleFrom(
                minimumSize: const Size.fromHeight(54),
                backgroundColor: accent,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
              ),
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: _busy ? null : _restore,
              icon: const Icon(Icons.restore_rounded),
              label: const Text('Drive’dan Geri Yükle'),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(52),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
              ),
            ),
            if (_message != null) ...[
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(13),
                decoration: BoxDecoration(
                  color: accent.withValues(alpha: .08),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: accent.withValues(alpha: .18)),
                ),
                child: Text(
                  _message!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 12, height: 1.4),
                ),
              ),
            ],
            const SizedBox(height: 24),
            const Text(
              'Yedeklenenler',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 10),
            const _BackupItem(icon: Icons.favorite_rounded, text: 'Favoriler'),
            const _BackupItem(icon: Icons.history_rounded, text: 'Son görüntülenenler'),
            const _BackupItem(icon: Icons.done_all_rounded, text: 'Uygulanan duvar kağıtları'),
            const _BackupItem(icon: Icons.tune_rounded, text: 'Desteklenen uygulama ayarları'),
            const SizedBox(height: 16),
            const Text(
              'Duvar kağıdı görsellerinin kendileri Drive’a kopyalanmaz. Yedek; ELXVRO içerik kimliklerini ve tercihlerini saklar. Böylece yedek küçük kalır ve yeni cihazda hızlı geri yüklenir.',
              style: TextStyle(color: AppTheme.textSecondary, fontSize: 12, height: 1.5),
            ),
          ],
        ),
      ),
    );
  }
}

class _BackupStatusCard extends StatelessWidget {
  final bool checking;
  final bool connected;
  final String date;
  final String fileName;

  const _BackupStatusCard({
    required this.checking,
    required this.connected,
    required this.date,
    required this.fileName,
  });

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: AppTheme.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppTheme.border),
        ),
        child: Row(
          children: [
            Icon(
              connected ? Icons.check_circle_rounded : Icons.cloud_outlined,
              color: connected ? Colors.green : AppTheme.textSecondary,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    checking
                        ? 'Drive kontrol ediliyor...'
                        : connected
                            ? 'Drive yedeği hazır'
                            : 'Drive izni henüz verilmedi',
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    connected ? '$fileName • $date' : 'İlk yedeklemede Google Drive izni istenir.',
                    style: const TextStyle(color: AppTheme.textSecondary, fontSize: 11),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
}

class _BackupItem extends StatelessWidget {
  final IconData icon;
  final String text;

  const _BackupItem({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child: Row(
          children: [
            Icon(icon, size: 19, color: Theme.of(context).colorScheme.primary),
            const SizedBox(width: 11),
            Text(text, style: const TextStyle(fontWeight: FontWeight.w700)),
          ],
        ),
      );
}
