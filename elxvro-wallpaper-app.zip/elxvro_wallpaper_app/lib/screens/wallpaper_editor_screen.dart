import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/rendering.dart';

import '../app_state.dart';
import '../models/wallpaper.dart';
import '../services/wallpaper_service.dart';

enum _EditorTool { crop, light, color, blur, filter }
enum _FitMode { cover, contain }
enum _PreviewTarget { home, lock }
enum _FilterPreset { normal, vivid, mono, warm, cool }

class WallpaperEditorScreen extends StatefulWidget {
  final WallpaperItem item;

  const WallpaperEditorScreen({
    super.key,
    required this.item,
  });

  @override
  State<WallpaperEditorScreen> createState() => _WallpaperEditorScreenState();
}

class _WallpaperEditorScreenState extends State<WallpaperEditorScreen> {
  final GlobalKey _captureKey = GlobalKey();
  final TransformationController _transformController = TransformationController();

  _EditorTool _tool = _EditorTool.crop;
  _FitMode _fitMode = _FitMode.cover;
  _PreviewTarget _previewTarget = _PreviewTarget.lock;
  _FilterPreset _preset = _FilterPreset.normal;

  double _brightness = 0;
  double _contrast = 1;
  double _saturation = 1;
  double _blur = 0;
  double _imageAspect = 0.5;

  bool _beforePreview = false;
  bool _controlsVisible = true;
  bool _setting = false;
  bool _favoritePulse = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _resolveImageAspect();
  }

  @override
  void dispose() {
    _transformController.dispose();
    super.dispose();
  }

  void _resolveImageAspect() {
    final provider = AssetImage(widget.item.asset);
    final stream = provider.resolve(createLocalImageConfiguration(context));
    late final ImageStreamListener listener;
    listener = ImageStreamListener((info, _) {
      final width = info.image.width.toDouble();
      final height = info.image.height.toDouble();
      if (height > 0 && mounted) {
        final ratio = width / height;
        if ((ratio - _imageAspect).abs() > 0.001) {
          setState(() => _imageAspect = ratio);
        }
      }
      stream.removeListener(listener);
    });
    stream.addListener(listener);
  }

  void _reset() {
    setState(() {
      _fitMode = _FitMode.cover;
      _preset = _FilterPreset.normal;
      _brightness = 0;
      _contrast = 1;
      _saturation = 1;
      _blur = 0;
      _beforePreview = false;
    });
    _transformController.value = Matrix4.identity();
    HapticFeedback.selectionClick();
  }

  List<double> _adjustmentMatrix() {
    final sat = _saturation;
    final invSat = 1 - sat;
    const r = 0.2126;
    const g = 0.7152;
    const b = 0.0722;

    final sr = invSat * r;
    final sg = invSat * g;
    final sb = invSat * b;

    final c = _contrast;
    final brightnessOffset = _brightness * 255;
    final contrastOffset = 128 * (1 - c);
    final offset = brightnessOffset + contrastOffset;

    return <double>[
      (sr + sat) * c, sg * c, sb * c, 0, offset,
      sr * c, (sg + sat) * c, sb * c, 0, offset,
      sr * c, sg * c, (sb + sat) * c, 0, offset,
      0, 0, 0, 1, 0,
    ];
  }

  List<double> _presetMatrix() {
    switch (_preset) {
      case _FilterPreset.vivid:
        return const <double>[
          1.12, 0, 0, 0, 2,
          0, 1.08, 0, 0, 2,
          0, 0, 1.14, 0, 2,
          0, 0, 0, 1, 0,
        ];
      case _FilterPreset.mono:
        return const <double>[
          0.2126, 0.7152, 0.0722, 0, 0,
          0.2126, 0.7152, 0.0722, 0, 0,
          0.2126, 0.7152, 0.0722, 0, 0,
          0, 0, 0, 1, 0,
        ];
      case _FilterPreset.warm:
        return const <double>[
          1.10, 0, 0, 0, 7,
          0, 1.03, 0, 0, 1,
          0, 0, 0.90, 0, -3,
          0, 0, 0, 1, 0,
        ];
      case _FilterPreset.cool:
        return const <double>[
          0.92, 0, 0, 0, -2,
          0, 1.02, 0, 0, 1,
          0, 0, 1.12, 0, 6,
          0, 0, 0, 1, 0,
        ];
      case _FilterPreset.normal:
        return const <double>[
          1, 0, 0, 0, 0,
          0, 1, 0, 0, 0,
          0, 0, 1, 0, 0,
          0, 0, 0, 1, 0,
        ];
    }
  }

  Widget _buildFilteredImage(BoxConstraints constraints) {
    final viewportWidth = constraints.maxWidth;
    final viewportHeight = constraints.maxHeight;
    final viewportAspect = viewportWidth / viewportHeight;

    double childWidth;
    double childHeight;

    if (_fitMode == _FitMode.cover) {
      if (_imageAspect >= viewportAspect) {
        childHeight = viewportHeight;
        childWidth = childHeight * _imageAspect;
      } else {
        childWidth = viewportWidth;
        childHeight = childWidth / _imageAspect;
      }
    } else {
      if (_imageAspect >= viewportAspect) {
        childWidth = viewportWidth;
        childHeight = childWidth / _imageAspect;
      } else {
        childHeight = viewportHeight;
        childWidth = childHeight * _imageAspect;
      }
    }

    Widget image = Image.asset(
      widget.item.asset,
      width: childWidth,
      height: childHeight,
      fit: BoxFit.fill,
      filterQuality: FilterQuality.high,
    );

    if (!_beforePreview) {
      image = ColorFiltered(
        colorFilter: ColorFilter.matrix(_adjustmentMatrix()),
        child: image,
      );
      image = ColorFiltered(
        colorFilter: ColorFilter.matrix(_presetMatrix()),
        child: image,
      );
      if (_blur > 0.05) {
        image = ImageFiltered(
          imageFilter: ui.ImageFilter.blur(sigmaX: _blur, sigmaY: _blur),
          child: image,
        );
      }
    }

    return InteractiveViewer(
      transformationController: _transformController,
      constrained: false,
      minScale: 1,
      maxScale: 4,
      clipBehavior: Clip.hardEdge,
      alignment: Alignment.center,
      boundaryMargin: EdgeInsets.zero,
      child: SizedBox(
        width: childWidth,
        height: childHeight,
        child: image,
      ),
    );
  }

  Future<Uint8List> _captureEditedBytes() async {
    final boundary = _captureKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
    if (boundary == null) {
      throw const PlatformException(
        code: 'CAPTURE_FAILED',
        message: 'Düzenlenmiş görsel hazırlanamadı.',
      );
    }

    await WidgetsBinding.instance.endOfFrame;
    final dpr = MediaQuery.devicePixelRatioOf(context).clamp(1.5, 3.0).toDouble();
    final image = await boundary.toImage(pixelRatio: dpr);
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    image.dispose();
    if (data == null) {
      throw const PlatformException(
        code: 'CAPTURE_FAILED',
        message: 'Düzenlenmiş görsel hazırlanamadı.',
      );
    }
    return data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
  }

  WallpaperTarget? _targetFromSetting(String value) {
    switch (value) {
      case 'home':
        return WallpaperTarget.home;
      case 'lock':
        return WallpaperTarget.lock;
      case 'both':
        return WallpaperTarget.both;
      default:
        return null;
    }
  }

  String _targetLabel(WallpaperTarget target) {
    switch (target) {
      case WallpaperTarget.home:
        return 'Ana ekran';
      case WallpaperTarget.lock:
        return 'Kilit ekranı';
      case WallpaperTarget.both:
        return 'Ana + kilit ekranı';
    }
  }

  Future<void> _chooseTarget() async {
    final state = AppScope.of(context);
    final preferred = _targetFromSetting(state.defaultTarget);
    if (preferred != null) {
      await _applyEdited(preferred);
      return;
    }

    final target = await showModalBottomSheet<WallpaperTarget>(
      context: context,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Düzenlenmiş görsel nereye uygulansın?',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 14),
              _TargetTile(
                icon: Icons.phone_android_rounded,
                title: 'Ana Ekran',
                onTap: () => Navigator.pop(context, WallpaperTarget.home),
              ),
              _TargetTile(
                icon: Icons.lock_outline_rounded,
                title: 'Kilit Ekranı',
                onTap: () => Navigator.pop(context, WallpaperTarget.lock),
              ),
              _TargetTile(
                icon: Icons.splitscreen_rounded,
                title: 'İkisi Birden',
                onTap: () => Navigator.pop(context, WallpaperTarget.both),
              ),
            ],
          ),
        ),
      ),
    );

    if (target != null && mounted) {
      await _applyEdited(target);
    }
  }

  Future<void> _applyEdited(WallpaperTarget target) async {
    setState(() {
      _setting = true;
      _beforePreview = false;
    });

    try {
      final bytes = await _captureEditedBytes();
      await WallpaperService.setFromBytes(
        bytes,
        target,
        exactComposition: true,
      );
      if (!mounted) return;
      AppScope.of(context).markApplied(widget.item.id);
      HapticFeedback.mediumImpact();
      await showDialog<void>(
        context: context,
        builder: (_) => _EditorSuccessDialog(
          title: widget.item.title,
          target: _targetLabel(target),
        ),
      );
    } on PlatformException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.message ?? 'Duvar kağıdı ayarlanamadı.')),
      );
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Düzenlenmiş görsel hazırlanamadı.')),
      );
    } finally {
      if (mounted) setState(() => _setting = false);
    }
  }

  void _toggleFavorite() {
    final state = AppScope.of(context);
    state.toggleFavorite(widget.item.id);
    HapticFeedback.selectionClick();
    setState(() => _favoritePulse = true);
    Future<void>.delayed(const Duration(milliseconds: 180), () {
      if (mounted) setState(() => _favoritePulse = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final screen = MediaQuery.sizeOf(context);
    final phoneAspect = screen.width / math.max(screen.height, 1.0);

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              height: _controlsVisible ? 60 : 0,
              child: ClipRect(
                child: AnimatedOpacity(
                  duration: const Duration(milliseconds: 160),
                  opacity: _controlsVisible ? 1 : 0,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Row(
                      children: [
                        IconButton(
                          onPressed: () => Navigator.pop(context),
                          icon: const Icon(Icons.arrow_back_rounded),
                        ),
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Düzenle',
                                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
                              ),
                              Text(
                                widget.item.title,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontSize: 11, color: Colors.white54),
                              ),
                            ],
                          ),
                        ),
                        Tooltip(
                          message: _beforePreview ? 'Sonra' : 'Önce',
                          child: IconButton(
                            onPressed: () => setState(() => _beforePreview = !_beforePreview),
                            icon: Icon(
                              _beforePreview
                                  ? Icons.visibility_rounded
                                  : Icons.compare_rounded,
                            ),
                          ),
                        ),
                        AnimatedScale(
                          scale: _favoritePulse ? 1.22 : 1,
                          duration: const Duration(milliseconds: 160),
                          child: IconButton(
                            onPressed: _toggleFavorite,
                            icon: Icon(
                              state.isFavorite(widget.item.id)
                                  ? Icons.favorite_rounded
                                  : Icons.favorite_border_rounded,
                              color: state.isFavorite(widget.item.id)
                                  ? const Color(0xFFFF668F)
                                  : null,
                            ),
                          ),
                        ),
                        IconButton(
                          onPressed: _reset,
                          icon: const Icon(Icons.restart_alt_rounded),
                          tooltip: 'Sıfırla',
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              child: Center(
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final maxHeight = constraints.maxHeight - (_controlsVisible ? 8 : 0);
                    final maxWidth = constraints.maxWidth - 28;
                    double previewWidth = maxWidth;
                    double previewHeight = previewWidth / phoneAspect;
                    if (previewHeight > maxHeight) {
                      previewHeight = maxHeight;
                      previewWidth = previewHeight * phoneAspect;
                    }

                    return GestureDetector(
                      behavior: HitTestBehavior.translucent,
                      onDoubleTap: () => setState(() => _controlsVisible = !_controlsVisible),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 220),
                        width: _controlsVisible ? previewWidth : constraints.maxWidth,
                        height: _controlsVisible ? previewHeight : constraints.maxHeight,
                        decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(_controlsVisible ? 30 : 0),
                          border: _controlsVisible
                              ? Border.all(color: Colors.white12, width: 1)
                              : null,
                          boxShadow: _controlsVisible
                              ? const [
                                  BoxShadow(
                                    color: Color(0x66000000),
                                    blurRadius: 24,
                                    offset: Offset(0, 12),
                                  ),
                                ]
                              : null,
                        ),
                        clipBehavior: Clip.antiAlias,
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            RepaintBoundary(
                              key: _captureKey,
                              child: ColoredBox(
                                color: Colors.black,
                                child: LayoutBuilder(
                                  builder: (context, imageConstraints) {
                                    return _buildFilteredImage(imageConstraints);
                                  },
                                ),
                              ),
                            ),
                            IgnorePointer(
                              child: AnimatedOpacity(
                                duration: const Duration(milliseconds: 160),
                                opacity: _controlsVisible ? 1 : 0,
                                child: _PhonePreviewOverlay(target: _previewTarget),
                              ),
                            ),
                            if (_beforePreview)
                              Positioned(
                                top: 14,
                                left: 14,
                                child: _Badge(
                                  text: 'ÖNCE',
                                  color: state.accentColor,
                                ),
                              ),
                            Positioned(
                              right: 12,
                              bottom: 12,
                              child: Material(
                                color: Colors.black.withValues(alpha: .48),
                                borderRadius: BorderRadius.circular(22),
                                child: IconButton(
                                  visualDensity: VisualDensity.compact,
                                  onPressed: () => setState(() {
                                    _controlsVisible = !_controlsVisible;
                                  }),
                                  icon: Icon(
                                    _controlsVisible
                                        ? Icons.fullscreen_rounded
                                        : Icons.fullscreen_exit_rounded,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
            AnimatedSize(
              duration: const Duration(milliseconds: 220),
              curve: Curves.easeOutCubic,
              child: _controlsVisible
                  ? _EditorPanel(
                      tool: _tool,
                      fitMode: _fitMode,
                      previewTarget: _previewTarget,
                      preset: _preset,
                      brightness: _brightness,
                      contrast: _contrast,
                      saturation: _saturation,
                      blur: _blur,
                      accent: state.accentColor,
                      onToolChanged: (value) => setState(() => _tool = value),
                      onFitChanged: (value) {
                        setState(() => _fitMode = value);
                        _transformController.value = Matrix4.identity();
                      },
                      onPreviewChanged: (value) => setState(() => _previewTarget = value),
                      onPresetChanged: (value) => setState(() => _preset = value),
                      onBrightnessChanged: (value) => setState(() => _brightness = value),
                      onContrastChanged: (value) => setState(() => _contrast = value),
                      onSaturationChanged: (value) => setState(() => _saturation = value),
                      onBlurChanged: (value) => setState(() => _blur = value),
                      onResetTransform: () {
                        _transformController.value = Matrix4.identity();
                        HapticFeedback.selectionClick();
                      },
                    )
                  : const SizedBox.shrink(),
            ),
            AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              height: _controlsVisible ? 76 : 0,
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
              child: ClipRect(
                child: AnimatedOpacity(
                  duration: const Duration(milliseconds: 160),
                  opacity: _controlsVisible ? 1 : 0,
                  child: FilledButton.icon(
                    onPressed: _setting ? null : _chooseTarget,
                    icon: _setting
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.wallpaper_rounded),
                    label: Text(_setting ? 'Hazırlanıyor...' : 'Düzenlenmiş Duvar Kağıdını Uygula'),
                    style: FilledButton.styleFrom(
                      backgroundColor: state.accentColor,
                      foregroundColor: Colors.white,
                      minimumSize: const Size.fromHeight(54),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _EditorPanel extends StatelessWidget {
  final _EditorTool tool;
  final _FitMode fitMode;
  final _PreviewTarget previewTarget;
  final _FilterPreset preset;
  final double brightness;
  final double contrast;
  final double saturation;
  final double blur;
  final Color accent;
  final ValueChanged<_EditorTool> onToolChanged;
  final ValueChanged<_FitMode> onFitChanged;
  final ValueChanged<_PreviewTarget> onPreviewChanged;
  final ValueChanged<_FilterPreset> onPresetChanged;
  final ValueChanged<double> onBrightnessChanged;
  final ValueChanged<double> onContrastChanged;
  final ValueChanged<double> onSaturationChanged;
  final ValueChanged<double> onBlurChanged;
  final VoidCallback onResetTransform;

  const _EditorPanel({
    required this.tool,
    required this.fitMode,
    required this.previewTarget,
    required this.preset,
    required this.brightness,
    required this.contrast,
    required this.saturation,
    required this.blur,
    required this.accent,
    required this.onToolChanged,
    required this.onFitChanged,
    required this.onPreviewChanged,
    required this.onPresetChanged,
    required this.onBrightnessChanged,
    required this.onContrastChanged,
    required this.onSaturationChanged,
    required this.onBlurChanged,
    required this.onResetTransform,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        color: Color(0xFF0D1118),
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
        border: Border(top: BorderSide(color: Colors.white10)),
      ),
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 8),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _ToolButton(
                  label: 'Kırp',
                  icon: Icons.crop_rounded,
                  selected: tool == _EditorTool.crop,
                  accent: accent,
                  onTap: () => onToolChanged(_EditorTool.crop),
                ),
                _ToolButton(
                  label: 'Işık',
                  icon: Icons.light_mode_outlined,
                  selected: tool == _EditorTool.light,
                  accent: accent,
                  onTap: () => onToolChanged(_EditorTool.light),
                ),
                _ToolButton(
                  label: 'Renk',
                  icon: Icons.palette_outlined,
                  selected: tool == _EditorTool.color,
                  accent: accent,
                  onTap: () => onToolChanged(_EditorTool.color),
                ),
                _ToolButton(
                  label: 'Blur',
                  icon: Icons.blur_on_rounded,
                  selected: tool == _EditorTool.blur,
                  accent: accent,
                  onTap: () => onToolChanged(_EditorTool.blur),
                ),
                _ToolButton(
                  label: 'Filtre',
                  icon: Icons.auto_awesome_rounded,
                  selected: tool == _EditorTool.filter,
                  accent: accent,
                  onTap: () => onToolChanged(_EditorTool.filter),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 180),
            child: _toolBody(context),
          ),
        ],
      ),
    );
  }

  Widget _toolBody(BuildContext context) {
    switch (tool) {
      case _EditorTool.crop:
        return Column(
          key: const ValueKey('crop'),
          children: [
            Row(
              children: [
                Expanded(
                  child: _ChoiceButton(
                    label: 'Ekranı Doldur',
                    icon: Icons.fit_screen_rounded,
                    selected: fitMode == _FitMode.cover,
                    accent: accent,
                    onTap: () => onFitChanged(_FitMode.cover),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _ChoiceButton(
                    label: 'Tamamını Göster',
                    icon: Icons.aspect_ratio_rounded,
                    selected: fitMode == _FitMode.contain,
                    accent: accent,
                    onTap: () => onFitChanged(_FitMode.contain),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: _ChoiceButton(
                    label: 'Ana Ekran Önizleme',
                    icon: Icons.apps_rounded,
                    selected: previewTarget == _PreviewTarget.home,
                    accent: accent,
                    onTap: () => onPreviewChanged(_PreviewTarget.home),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _ChoiceButton(
                    label: 'Kilit Önizleme',
                    icon: Icons.lock_outline_rounded,
                    selected: previewTarget == _PreviewTarget.lock,
                    accent: accent,
                    onTap: () => onPreviewChanged(_PreviewTarget.lock),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: onResetTransform,
              icon: const Icon(Icons.center_focus_strong_rounded, size: 18),
              label: const Text('Yakınlaştırma ve konumu sıfırla'),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(42),
                foregroundColor: Colors.white70,
                side: const BorderSide(color: Colors.white12),
              ),
            ),
            const Padding(
              padding: EdgeInsets.only(top: 6),
              child: Text(
                'İki parmakla yakınlaştır • Sürükleyerek konumlandır',
                style: TextStyle(fontSize: 10, color: Colors.white38),
              ),
            ),
          ],
        );
      case _EditorTool.light:
        return Column(
          key: const ValueKey('light'),
          children: [
            _EditorSlider(
              icon: Icons.brightness_6_outlined,
              label: 'Parlaklık',
              value: brightness,
              min: -0.45,
              max: 0.45,
              display: '${(brightness * 100).round()}',
              onChanged: onBrightnessChanged,
            ),
            _EditorSlider(
              icon: Icons.contrast_rounded,
              label: 'Kontrast',
              value: contrast,
              min: 0.55,
              max: 1.55,
              display: '${((contrast - 1) * 100).round()}',
              onChanged: onContrastChanged,
            ),
          ],
        );
      case _EditorTool.color:
        return Column(
          key: const ValueKey('color'),
          children: [
            _EditorSlider(
              icon: Icons.color_lens_outlined,
              label: 'Doygunluk',
              value: saturation,
              min: 0,
              max: 2,
              display: '${((saturation - 1) * 100).round()}',
              onChanged: onSaturationChanged,
            ),
            const Padding(
              padding: EdgeInsets.only(top: 4),
              child: Text(
                'Negatif değerler daha sakin, pozitif değerler daha canlı renk verir.',
                style: TextStyle(fontSize: 10, color: Colors.white38),
              ),
            ),
          ],
        );
      case _EditorTool.blur:
        return Column(
          key: const ValueKey('blur'),
          children: [
            _EditorSlider(
              icon: Icons.blur_on_rounded,
              label: 'Bulanıklık',
              value: blur,
              min: 0,
              max: 9,
              display: blur.toStringAsFixed(1),
              onChanged: onBlurChanged,
            ),
            const Padding(
              padding: EdgeInsets.only(top: 4),
              child: Text(
                'Kilit ekranında ikon ve saat okunabilirliğini artırmak için hafif blur kullanabilirsin.',
                style: TextStyle(fontSize: 10, color: Colors.white38),
              ),
            ),
          ],
        );
      case _EditorTool.filter:
        return SizedBox(
          key: const ValueKey('filter'),
          height: 74,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              _PresetChip(
                label: 'Normal',
                selected: preset == _FilterPreset.normal,
                accent: accent,
                onTap: () => onPresetChanged(_FilterPreset.normal),
              ),
              _PresetChip(
                label: 'Canlı',
                selected: preset == _FilterPreset.vivid,
                accent: accent,
                onTap: () => onPresetChanged(_FilterPreset.vivid),
              ),
              _PresetChip(
                label: 'S/B',
                selected: preset == _FilterPreset.mono,
                accent: accent,
                onTap: () => onPresetChanged(_FilterPreset.mono),
              ),
              _PresetChip(
                label: 'Sıcak',
                selected: preset == _FilterPreset.warm,
                accent: accent,
                onTap: () => onPresetChanged(_FilterPreset.warm),
              ),
              _PresetChip(
                label: 'Soğuk',
                selected: preset == _FilterPreset.cool,
                accent: accent,
                onTap: () => onPresetChanged(_FilterPreset.cool),
              ),
            ],
          ),
        );
    }
  }
}

class _EditorSlider extends StatelessWidget {
  final IconData icon;
  final String label;
  final double value;
  final double min;
  final double max;
  final String display;
  final ValueChanged<double> onChanged;

  const _EditorSlider({
    required this.icon,
    required this.label,
    required this.value,
    required this.min,
    required this.max,
    required this.display,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 92,
          child: Row(
            children: [
              Icon(icon, size: 18, color: Colors.white60),
              const SizedBox(width: 6),
              Flexible(
                child: Text(
                  label,
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: Slider(
            value: value.clamp(min, max).toDouble(),
            min: min,
            max: max,
            onChanged: onChanged,
          ),
        ),
        SizedBox(
          width: 38,
          child: Text(
            display,
            textAlign: TextAlign.right,
            style: const TextStyle(fontSize: 11, color: Colors.white54),
          ),
        ),
      ],
    );
  }
}

class _ToolButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final Color accent;
  final VoidCallback onTap;

  const _ToolButton({
    required this.label,
    required this.icon,
    required this.selected,
    required this.accent,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 3),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 160),
          width: 66,
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: selected ? accent.withValues(alpha: .16) : Colors.transparent,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: selected ? accent.withValues(alpha: .45) : Colors.transparent,
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 20, color: selected ? accent : Colors.white60),
              const SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                  color: selected ? Colors.white : Colors.white54,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ChoiceButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final Color accent;
  final VoidCallback onTap;

  const _ChoiceButton({
    required this.label,
    required this.icon,
    required this.selected,
    required this.accent,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: selected ? accent.withValues(alpha: .14) : Colors.white.withValues(alpha: .04),
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 17, color: selected ? accent : Colors.white54),
              const SizedBox(width: 6),
              Flexible(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    color: selected ? Colors.white : Colors.white60,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PresetChip extends StatelessWidget {
  final String label;
  final bool selected;
  final Color accent;
  final VoidCallback onTap;

  const _PresetChip({
    required this.label,
    required this.selected,
    required this.accent,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        width: 78,
        margin: const EdgeInsets.only(right: 8),
        decoration: BoxDecoration(
          color: selected ? accent.withValues(alpha: .16) : Colors.white.withValues(alpha: .04),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: selected ? accent.withValues(alpha: .52) : Colors.white10,
          ),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w800,
              color: selected ? Colors.white : Colors.white60,
            ),
          ),
        ),
      ),
    );
  }
}

class _PhonePreviewOverlay extends StatelessWidget {
  final _PreviewTarget target;

  const _PhonePreviewOverlay({required this.target});

  @override
  Widget build(BuildContext context) {
    if (target == _PreviewTarget.lock) {
      return Stack(
        children: [
          const Positioned(
            top: 34,
            left: 0,
            right: 0,
            child: Column(
              children: [
                Text(
                  '21:47',
                  style: TextStyle(
                    fontSize: 46,
                    height: 1,
                    fontWeight: FontWeight.w300,
                    letterSpacing: -1.5,
                    shadows: [Shadow(color: Colors.black54, blurRadius: 12)],
                  ),
                ),
                SizedBox(height: 7),
                Text(
                  '18 Eylül • Cuma',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.white70,
                    shadows: [Shadow(color: Colors.black54, blurRadius: 8)],
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            left: 18,
            right: 18,
            bottom: 18,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: const [
                _PreviewCircle(icon: Icons.flashlight_on_rounded),
                _PreviewCircle(icon: Icons.camera_alt_outlined),
              ],
            ),
          ),
        ],
      );
    }

    return Stack(
      children: [
        Positioned(
          left: 16,
          right: 16,
          bottom: 22,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: .24),
              borderRadius: BorderRadius.circular(24),
            ),
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _FakeAppIcon(icon: Icons.phone_rounded),
                _FakeAppIcon(icon: Icons.chat_bubble_rounded),
                _FakeAppIcon(icon: Icons.public_rounded),
                _FakeAppIcon(icon: Icons.camera_alt_rounded),
              ],
            ),
          ),
        ),
        Positioned(
          top: 34,
          left: 18,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: .22),
              borderRadius: BorderRadius.circular(18),
            ),
            child: const Text(
              '21:47',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
            ),
          ),
        ),
      ],
    );
  }
}

class _PreviewCircle extends StatelessWidget {
  final IconData icon;

  const _PreviewCircle({required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 42,
      height: 42,
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: .35),
        shape: BoxShape.circle,
      ),
      child: Icon(icon, size: 20),
    );
  }
}

class _FakeAppIcon extends StatelessWidget {
  final IconData icon;

  const _FakeAppIcon({required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 38,
      height: 38,
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: .18),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Icon(icon, size: 19, color: Colors.white),
    );
  }
}

class _Badge extends StatelessWidget {
  final String text;
  final Color color;

  const _Badge({required this.text, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .88),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Text(
        text,
        style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w900),
      ),
    );
  }
}

class _TargetTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  const _TargetTile({
    required this.icon,
    required this.title,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: .05),
        borderRadius: BorderRadius.circular(18),
      ),
      child: ListTile(
        onTap: onTap,
        leading: Icon(icon),
        title: Text(title),
        trailing: const Icon(Icons.chevron_right_rounded),
      ),
    );
  }
}

class _EditorSuccessDialog extends StatelessWidget {
  final String title;
  final String target;

  const _EditorSuccessDialog({
    required this.title,
    required this.target,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      icon: Icon(
        Icons.auto_awesome_rounded,
        color: Theme.of(context).colorScheme.primary,
        size: 44,
      ),
      title: const Text('Düzenleme uygulandı'),
      content: Text(
        '$title düzenlenmiş haliyle $target için ayarlandı.',
        textAlign: TextAlign.center,
      ),
      actionsAlignment: MainAxisAlignment.center,
      actions: [
        FilledButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Tamam'),
        ),
      ],
    );
  }
}
