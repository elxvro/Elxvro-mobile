import 'package:flutter/material.dart';

import '../app_state.dart';
import '../data/local_wallpapers.dart';
import '../models/category_item.dart';
import '../models/wallpaper.dart';
import '../theme/app_theme.dart';
import '../utils/category_key.dart';
import '../widgets/wallpaper_image.dart';
import 'category_wallpapers_screen.dart';

class CategoriesScreen extends StatelessWidget {
  const CategoriesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final categories = state.categories;

    return SafeArea(
      child: RefreshIndicator(
        onRefresh: () => state.refreshCategories(force: true),
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(18, 20, 12, 14),
              sliver: SliverToBoxAdapter(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Kategoriler',
                            style: TextStyle(
                              fontSize: 27,
                              fontWeight: FontWeight.w900,
                              letterSpacing: -.4,
                            ),
                          ),
                          const SizedBox(height: 5),
                          Text(
                            '${categories.length} kategori • ${state.visibleMediaCount} duvar kağıdı',
                            style: const TextStyle(
                              color: AppTheme.textSecondary,
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(
                        color: AppTheme.surface,
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(color: AppTheme.border),
                      ),
                      child: state.categoriesLoading
                          ? const Padding(
                              padding: EdgeInsets.all(12),
                              child: SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              ),
                            )
                          : IconButton(
                              tooltip: 'Kategorileri yenile',
                              onPressed: () => state.refreshCategories(force: true),
                              icon: const Icon(Icons.refresh_rounded, size: 20),
                            ),
                    ),
                  ],
                ),
              ),
            ),
            if (categories.isEmpty)
              const SliverFillRemaining(
                hasScrollBody: false,
                child: _EmptyCategories(),
              )
            else
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 18),
                sliver: SliverGrid.builder(
                  itemCount: categories.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 1.02,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                  ),
                  itemBuilder: (context, index) {
                    final category = categories[index];
                    final categoryItems = _localItems(category);
                    final coverItem = categoryItems.isEmpty ? null : categoryItems.first;
                    return GestureDetector(
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => CategoryWallpapersScreen(
                            categoryName: category.name,
                            categorySlug: category.slug,
                          ),
                        ),
                      ),
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(25),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0x120E1420),
                              blurRadius: 20,
                              offset: Offset(0, 8),
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(25),
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              const ColoredBox(color: Color(0xFF252A35)),
                              if (coverItem != null)
                                WallpaperImage(
                                  item: coverItem,
                                  fit: BoxFit.cover,
                                  filterQuality: FilterQuality.low,
                                  useThumbnail: true,
                                ),
                              Container(
                                padding: const EdgeInsets.all(15),
                                alignment: Alignment.bottomLeft,
                                decoration: const BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [Color(0x12000000), Color(0xD8000000)],
                                  ),
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    if (coverItem == null) ...[
                                      const Icon(
                                        Icons.photo_library_outlined,
                                        color: Colors.white54,
                                      ),
                                      const SizedBox(height: 10),
                                    ],
                                    Text(
                                      category.name,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 17,
                                        fontWeight: FontWeight.w900,
                                      ),
                                    ),
                                    const SizedBox(height: 3),
                                    Text(
                                      '${categoryItems.length} duvar kağıdı',
                                      style: const TextStyle(
                                        fontSize: 10,
                                        color: Colors.white70,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Positioned(
                                top: 11,
                                right: 11,
                                child: Container(
                                  width: 30,
                                  height: 30,
                                  decoration: BoxDecoration(
                                    color: Colors.black.withValues(alpha: .30),
                                    shape: BoxShape.circle,
                                    border: Border.all(color: Colors.white24),
                                  ),
                                  child: const Icon(
                                    Icons.arrow_outward_rounded,
                                    color: Colors.white,
                                    size: 15,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            const SliverToBoxAdapter(child: SizedBox(height: 30)),
          ],
        ),
      ),
    );
  }

  List<WallpaperItem> _localItems(CategoryItem category) => wallpapers
      .where((item) => categoryKey(item.category) == category.slug ||
          categoryKey(item.category) == categoryKey(category.name))
      .toList(growable: false);
}

class _EmptyCategories extends StatelessWidget {
  const _EmptyCategories();

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 62,
                height: 62,
                decoration: const BoxDecoration(
                  color: AppTheme.surfaceSoft,
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.grid_view_rounded,
                  color: AppTheme.textSecondary,
                  size: 28,
                ),
              ),
              const SizedBox(height: 14),
              const Text(
                'Kategori bulunamadı',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 5),
              const Text(
                'Yenileme yaparak tekrar kontrol edebilirsin.',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppTheme.textSecondary, fontSize: 12),
              ),
            ],
          ),
        ),
      );
}
