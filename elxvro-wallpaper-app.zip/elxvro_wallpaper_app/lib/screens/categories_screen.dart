import 'package:flutter/material.dart';

import '../app_state.dart';
import '../data/local_wallpapers.dart';
import '../models/category_item.dart';
import '../models/wallpaper.dart';
import '../utils/category_key.dart';
import '../widgets/wallpaper_image.dart';
import 'category_wallpapers_screen.dart';

class CategoriesScreen extends StatelessWidget {
  const CategoriesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final categories = state.categories;

    return SafeArea(
      child: RefreshIndicator(
        onRefresh: () => state.refreshCategories(force: true),
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(18, 20, 10, 12),
              sliver: SliverToBoxAdapter(
                child: Row(
                  children: [
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Kategoriler',
                            style: TextStyle(
                              fontSize: 26,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            'Kategori listesi çevrimdışı önbellekle çalışır.',
                            style: TextStyle(
                              color: Color(0x73FFFFFF),
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (state.categoriesLoading)
                      const Padding(
                        padding: EdgeInsets.all(12),
                        child: SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                      )
                    else
                      IconButton(
                        tooltip: 'Kategorileri yenile',
                        onPressed: () => state.refreshCategories(force: true),
                        icon: const Icon(Icons.refresh_rounded),
                      ),
                  ],
                ),
              ),
            ),
            if (categories.isEmpty)
              const SliverFillRemaining(
                hasScrollBody: false,
                child: Center(
                  child: Text(
                    'Kategori bulunamadı.',
                    style: TextStyle(color: Colors.white60),
                  ),
                ),
              )
            else
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 18),
                sliver: SliverGrid.builder(
                  itemCount: categories.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 1.05,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                  ),
                  itemBuilder: (context, index) {
                    final category = categories[index];
                    final categoryItems = _localItems(category);
                    final coverItem = categoryItems.isEmpty
                        ? null
                        : categoryItems.first;
                    return GestureDetector(
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => CategoryWallpapersScreen(
                            categoryName: category.name,
                            categorySlug: category.slug,
                          ),
                        ),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(24),
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            const ColoredBox(color: Color(0xFF131722)),
                            if (coverItem != null)
                              WallpaperImage(
                                item: coverItem,
                                fit: BoxFit.cover,
                                filterQuality: FilterQuality.low,
                                useThumbnail: true,
                              ),
                            Container(
                              padding: const EdgeInsets.all(14),
                              alignment: Alignment.bottomLeft,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: coverItem == null
                                      ? const [
                                          Color(0xFF181D29),
                                          Color(0xFF090B11),
                                        ]
                                      : const [
                                          Colors.transparent,
                                          Color(0xCC000000),
                                        ],
                                ),
                              ),
                              child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if (coverItem == null) ...[
                                const Icon(
                                  Icons.photo_library_outlined,
                                  color: Colors.white38,
                                ),
                                const SizedBox(height: 10),
                              ],
                              Text(
                                category.name,
                                style: const TextStyle(
                                  fontSize: 17,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                '${categoryItems.length} duvar kağıdı',
                                style: const TextStyle(
                                  fontSize: 11,
                                  color: Colors.white70,
                                ),
                              ),
                            ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            const SliverToBoxAdapter(child: SizedBox(height: 30)),
          ],
        ),
      ),
    );
  }

  List<WallpaperItem> _localItems(CategoryItem category) => wallpapers
      .where((item) => categoryKey(item.category) == category.slug ||
          categoryKey(item.category) == categoryKey(category.name))
      .toList(growable: false);
}
