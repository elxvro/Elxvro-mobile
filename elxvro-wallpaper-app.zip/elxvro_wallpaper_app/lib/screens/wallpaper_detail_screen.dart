import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../app_state.dart';
import '../theme/app_theme.dart';
import '../data/local_wallpapers.dart';
import '../models/wallpaper.dart';
import '../services/wallpaper_service.dart';
import '../widgets/wallpaper_image.dart';
import 'wallpaper_editor_screen.dart';

class WallpaperDetailScreen extends StatefulWidget {
  final WallpaperItem item;

  const WallpaperDetailScreen({
    super.key,
    required this.item,
  });

  @override
  State<WallpaperDetailScreen> createState() => _WallpaperDetailScreenState();
}

class _WallpaperDetailScreenState extends State<WallpaperDetailScreen> {
  late final PageController _pageController;
  late int _currentIndex;
  bool setting = false;
  bool previewOnly = false;
  bool favoritePulse = false;

  WallpaperItem get _currentItem {
    if (wallpapers.isEmpty) return widget.item;
    final index = _currentIndex.clamp(0, wallpapers.length - 1).toInt();
    return wallpapers[index];
  }

  @override
  void initState() {
    super.initState();
    final found = wallpapers.indexWhere((item) => item.id == widget.item.id);
    _currentIndex = found < 0 ? 0 : found;
    _pageController = PageController(initialPage: _currentIndex);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _precacheAround(_currentIndex);
  }

  void _precacheAround(int index) {
    for (final candidate in <int>[index - 1, index, index + 1]) {
      if (candidate >= 0 && candidate < wallpapers.length) {
        final item = wallpapers[candidate];
        if (!item.isRemoteUrl) {
          precacheImage(wallpaperProvider(item), context);
        }
      }
    }
    if (index >= 0 && index < wallpapers.length) {
      final state = AppScope.of(context);
      final item = wallpapers[index];
      unawaited(() async {
        try {
          await state.ensureLocalMedia(item);
        } on Exception {
          // Görsel ekranda ağdan gösterilmeye devam eder.
        }
      }());
    }
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  WallpaperTarget? _targetFromSetting(String value) {
    switch (value) {
      case 'home':
        return WallpaperTarget.home;
      case 'lock':
        return WallpaperTarget.lock;
      case 'both':
        return WallpaperTarget.both;
      default:
        return null;
    }
  }

  String _targetLabel(WallpaperTarget target) {
    switch (target) {
      case WallpaperTarget.home:
        return 'Ana ekran';
      case WallpaperTarget.lock:
        return 'Kilit ekranı';
      case WallpaperTarget.both:
        return 'Ana + kilit ekranı';
    }
  }

  Future<void> _chooseTarget() async {
    final state = AppScope.of(context);
    final preferred = _targetFromSetting(state.defaultTarget);
    if (preferred != null) {
      await _applyTarget(preferred);
      return;
    }

    final target = await showModalBottomSheet<WallpaperTarget>(
      context: context,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Nerede ayarlamak istersin?',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 14),
              _TargetTile(
                icon: Icons.phone_android,
                title: 'Ana Ekran',
                onTap: () => Navigator.pop(context, WallpaperTarget.home),
              ),
              _TargetTile(
                icon: Icons.lock_outline,
                title: 'Kilit Ekranı',
                onTap: () => Navigator.pop(context, WallpaperTarget.lock),
              ),
              _TargetTile(
                icon: Icons.splitscreen,
                title: 'Ana Ekran ve Kilit Ekranı',
                onTap: () => Navigator.pop(context, WallpaperTarget.both),
              ),
              const SizedBox(height: 6),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('İptal'),
              ),
            ],
          ),
        ),
      ),
    );

    if (target != null && mounted) {
      await _applyTarget(target);
    }
  }

  Future<void> _applyTarget(WallpaperTarget target) async {
    final selectedItem = _currentItem;
    final state = AppScope.of(context);
    setState(() => setting = true);
    try {
      final localItem = await state.ensureLocalMedia(selectedItem);
      await WallpaperService.setFromItem(localItem, target);
      if (!mounted) return;
      state.markApplied(localItem.id);
      HapticFeedback.mediumImpact();
      await showDialog<void>(
        context: context,
        builder: (_) => _SuccessDialog(
          title: localItem.title,
          target: _targetLabel(target),
        ),
      );
    } on PlatformException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.message ?? 'Duvar kağıdı ayarlanamadı.')),
      );
    } on Exception {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Görsel hazırlanamadı. İnternet bağlantısını kontrol et.'),
        ),
      );
    } finally {
      if (mounted) setState(() => setting = false);
    }
  }

  void _toggleFavorite() {
    AppScope.of(context).toggleFavorite(_currentItem.id);
    HapticFeedback.selectionClick();
    setState(() => favoritePulse = true);
    Future<void>.delayed(const Duration(milliseconds: 170), () {
      if (mounted) setState(() => favoritePulse = false);
    });
  }

  void _onPageChanged(int index) {
    setState(() => _currentIndex = index);
    AppScope.of(context).markViewed(wallpapers[index].id);
    _precacheAround(index);
  }

  List<WallpaperItem> _similarItems(WallpaperItem source) {
    final items = wallpapers.where((candidate) {
      if (candidate.id == source.id) return false;
      if (candidate.category == source.category) return true;
      return candidate.tags.any(source.tags.contains);
    }).toList();
    if (items.length >= 4) return items.take(6).toList();
    final fallback = wallpapers
        .where((candidate) => candidate.id != source.id && !items.contains(candidate))
        .take(6 - items.length)
        .toList();
    return [...items, ...fallback];
  }


  Future<void> _openEditor() async {
    final item = _currentItem;
    final state = AppScope.of(context);
    WallpaperItem localItem;
    try {
      localItem = await state.ensureLocalMedia(item);
    } on Exception {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Düzenleyici için görsel hazırlanamadı.'),
        ),
      );
      return;
    }
    if (!mounted) return;
    await Navigator.of(context).push(
      PageRouteBuilder<void>(
        transitionDuration: const Duration(milliseconds: 320),
        reverseTransitionDuration: const Duration(milliseconds: 240),
        pageBuilder: (_, animation, __) => WallpaperEditorScreen(item: localItem),
        transitionsBuilder: (_, animation, __, child) {
          final curved = CurvedAnimation(
            parent: animation,
            curve: Curves.easeOutCubic,
            reverseCurve: Curves.easeInCubic,
          );
          return FadeTransition(
            opacity: curved,
            child: ScaleTransition(
              scale: Tween<double>(begin: .985, end: 1).animate(curved),
              child: child,
            ),
          );
        },
      ),
    );
  }

  Future<void> _showSimilar() async {
    final similar = _similarItems(_currentItem);
    await showModalBottomSheet<void>(
      context: context,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Benzer duvar kağıtları',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: 170,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: similar.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 10),
                  itemBuilder: (_, index) {
                    final item = similar[index];
                    return GestureDetector(
                      onTap: () {
                        Navigator.pop(sheetContext);
                        final targetIndex =
                            wallpapers.indexWhere((w) => w.id == item.id);
                        if (targetIndex < 0) return;
                        _pageController.animateToPage(
                          targetIndex,
                          duration: const Duration(milliseconds: 280),
                          curve: Curves.easeOut,
                        );
                      },
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(18),
                        child: SizedBox(
                          width: 105,
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              WallpaperImage(
                                item: item,
                                fit: BoxFit.cover,
                                filterQuality: FilterQuality.low,
                                useThumbnail: true,
                              ),
                              const DecoratedBox(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [Colors.transparent, Color(0xB0000000)],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final item = _currentItem;
    final quickTarget = _targetFromSetting(state.defaultTarget);

    return Theme(
      data: AppTheme.viewer(accent: state.accentColor),
      child: Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          GestureDetector(
            onDoubleTap: () => setState(() => previewOnly = !previewOnly),
            child: PageView.builder(
              controller: _pageController,
              itemCount: wallpapers.length,
              onPageChanged: _onPageChanged,
              itemBuilder: (context, index) => WallpaperImage(
                item: wallpapers[index],
                fit: BoxFit.cover,
                filterQuality: FilterQuality.medium,
                progressive: true,
              ),
            ),
          ),
          IgnorePointer(
            ignoring: previewOnly,
            child: AnimatedOpacity(
              opacity: previewOnly ? 0 : 1,
              duration: const Duration(milliseconds: 180),
              child: const DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color(0x66000000),
                      Colors.transparent,
                      Color(0xE6000000),
                    ],
                  ),
                ),
              ),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(
                    children: [
                      _CircleButton(
                        icon: Icons.arrow_back,
                        onTap: () => Navigator.pop(context),
                      ),
                      const Spacer(),
                      _CircleButton(
                        icon: previewOnly
                            ? Icons.visibility_off_outlined
                            : Icons.visibility_outlined,
                        onTap: () => setState(() => previewOnly = !previewOnly),
                      ),
                      const SizedBox(width: 8),
                      AnimatedScale(
                        scale: favoritePulse ? 1.2 : 1,
                        duration: const Duration(milliseconds: 150),
                        child: _CircleButton(
                          icon: state.isFavorite(item.id)
                              ? Icons.favorite
                              : Icons.favorite_border,
                          iconColor: state.isFavorite(item.id)
                              ? const Color(0xFFFF668F)
                              : Colors.white,
                          onTap: _toggleFavorite,
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  AnimatedOpacity(
                    opacity: previewOnly ? 0 : 1,
                    duration: const Duration(milliseconds: 180),
                    child: IgnorePointer(
                      ignoring: previewOnly,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              _GlassLabel(text: item.category),
                              if (state.wasApplied(item.id)) ...[
                                const SizedBox(width: 7),
                                const _GlassLabel(
                                  text: 'Uygulandı',
                                  icon: Icons.check_rounded,
                                ),
                              ],
                              const Spacer(),
                              _GlassLabel(
                                text: '${_currentIndex + 1} / ${wallpapers.length}',
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Text(
                            item.title,
                            style: const TextStyle(
                              fontSize: 26,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Wrap(
                            spacing: 7,
                            runSpacing: 7,
                            children: item.tags.map<Widget>((tag) {
                              return Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 6,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.black.withValues(alpha: .35),
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: Text('#$tag', style: const TextStyle(fontSize: 11)),
                              );
                            }).toList(),
                          ),
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              Expanded(
                                child: OutlinedButton.icon(
                                  onPressed: _showSimilar,
                                  icon: const Icon(Icons.auto_awesome_rounded, size: 18),
                                  label: const Text('Benzer'),
                                  style: OutlinedButton.styleFrom(
                                    foregroundColor: Colors.white,
                                    side: const BorderSide(color: Colors.white24),
                                    minimumSize: const Size.fromHeight(48),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: OutlinedButton.icon(
                                  onPressed: _openEditor,
                                  icon: const Icon(Icons.tune_rounded, size: 18),
                                  label: const Text('Düzenle'),
                                  style: OutlinedButton.styleFrom(
                                    foregroundColor: Colors.white,
                                    side: BorderSide(
                                      color: state.accentColor.withValues(alpha: .55),
                                    ),
                                    minimumSize: const Size.fromHeight(48),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 9),
                          FilledButton.icon(
                            onPressed: setting ? null : _chooseTarget,
                            icon: setting
                                ? const SizedBox(
                                    width: 18,
                                    height: 18,
                                    child: CircularProgressIndicator(strokeWidth: 2),
                                  )
                                : const Icon(Icons.wallpaper_rounded),
                            label: Text(
                              setting
                                  ? 'Ayarlanıyor...'
                                  : quickTarget == null
                                      ? 'Duvar Kağıdı Yap'
                                      : 'Uygula • ${_targetLabel(quickTarget)}',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            style: FilledButton.styleFrom(
                              backgroundColor: state.accentColor,
                              foregroundColor: Colors.white,
                              minimumSize: const Size.fromHeight(54),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(18),
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),
                          const Center(
                            child: Text(
                              'Sağa/sola kaydır • Çift dokun: tam ekran',
                              style: TextStyle(fontSize: 10, color: Colors.white54),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  if (previewOnly)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 13,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: .48),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Text(
                          'Tam ekran önizleme • Kaydırarak değiştir • Çift dokunarak kapat',
                          style: TextStyle(color: Colors.white70, fontSize: 11),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
      ),
    );
  }
}

class _CircleButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final Color iconColor;

  const _CircleButton({
    required this.icon,
    required this.onTap,
    this.iconColor = Colors.white,
  });

  @override
  Widget build(BuildContext context) => Material(
        color: Colors.black.withValues(alpha: .38),
        shape: const CircleBorder(),
        child: IconButton(
          onPressed: onTap,
          icon: Icon(icon, color: iconColor),
        ),
      );
}

class _GlassLabel extends StatelessWidget {
  final String text;
  final IconData? icon;

  const _GlassLabel({required this.text, this.icon});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: .40),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[
              Icon(icon, size: 13),
              const SizedBox(width: 4),
            ],
            Text(
              text,
              style: const TextStyle(fontSize: 11, color: Colors.white70),
            ),
          ],
        ),
      );
}

class _TargetTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  const _TargetTile({
    required this.icon,
    required this.title,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 8),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: .05),
          borderRadius: BorderRadius.circular(18),
        ),
        child: ListTile(
          onTap: onTap,
          leading: Icon(icon),
          title: Text(title),
          trailing: const Icon(Icons.chevron_right_rounded),
        ),
      );
}

class _SuccessDialog extends StatelessWidget {
  final String title;
  final String target;

  const _SuccessDialog({
    required this.title,
    required this.target,
  });

  @override
  Widget build(BuildContext context) => AlertDialog(
        icon: Icon(
          Icons.check_circle_rounded,
          color: Theme.of(context).colorScheme.primary,
          size: 48,
        ),
        title: const Text('Duvar kağıdı hazır'),
        content: Text(
          '$title başarıyla $target için ayarlandı.',
          textAlign: TextAlign.center,
        ),
        actionsAlignment: MainAxisAlignment.center,
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tamam'),
          ),
        ],
      );
}
