import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../app_state.dart';
import '../models/wallpaper.dart';
import '../services/wallpaper_service.dart';

class WallpaperDetailScreen extends StatefulWidget {
  final WallpaperItem item;
  const WallpaperDetailScreen({super.key, required this.item});
  @override
  State<WallpaperDetailScreen> createState() => _WallpaperDetailScreenState();
}

class _WallpaperDetailScreenState extends State<WallpaperDetailScreen> {
  bool setting = false;

  Future<void> _chooseTarget() async {
    final target = await showModalBottomSheet<WallpaperTarget>(
      context: context,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('Nerede ayarlamak istersin?', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 14),
            _TargetTile(icon: Icons.phone_android, title: 'Ana Ekran', onTap: () => Navigator.pop(context, WallpaperTarget.home)),
            _TargetTile(icon: Icons.lock_outline, title: 'Kilit Ekranı', onTap: () => Navigator.pop(context, WallpaperTarget.lock)),
            _TargetTile(icon: Icons.splitscreen, title: 'Ana Ekran ve Kilit Ekranı', onTap: () => Navigator.pop(context, WallpaperTarget.both)),
            const SizedBox(height: 6),
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('İptal')),
          ]),
        ),
      ),
    );
    if (target == null || !mounted) return;
    setState(() => setting = true);
    try {
      await WallpaperService.setFromAsset(widget.item.asset, target);
      if (!mounted) return;
      await showDialog<void>(context: context, builder: (_) => const _SuccessDialog());
    } on PlatformException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? 'Duvar kağıdı ayarlanamadı.')));
    } finally {
      if (mounted) setState(() => setting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final item = widget.item;
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(item.asset, fit: BoxFit.cover),
          const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0x55000000), Colors.transparent, Color(0xD9000000)]))),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(children: [
                    _CircleButton(icon: Icons.arrow_back, onTap: () => Navigator.pop(context)),
                    const Spacer(),
                    _CircleButton(icon: state.isFavorite(item.id) ? Icons.favorite : Icons.favorite_border, onTap: () => state.toggleFavorite(item.id)),
                  ]),
                  const Spacer(),
                  Align(
                    alignment: Alignment.bottomLeft,
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(item.title, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 10),
                      Wrap(
                        spacing: 7,
                        runSpacing: 7,
                        children: item.tags.map<Widget>((tag) {
                          return Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 6,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.black.withValues(alpha: .35),
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Text(
                              '#$tag',
                              style: const TextStyle(fontSize: 11),
                            ),
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 18),
                      SizedBox(
                        width: double.infinity,
                        height: 54,
                        child: FilledButton.icon(
                          onPressed: setting ? null : _chooseTarget,
                          icon: setting ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.wallpaper_rounded),
                          label: Text(setting ? 'Ayarlanıyor...' : 'Duvar Kağıdı Yap'),
                          style: FilledButton.styleFrom(backgroundColor: const Color(0xFF8068FF), foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
                        ),
                      ),
                    ]),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _CircleButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _CircleButton({required this.icon, required this.onTap});
  @override
  Widget build(BuildContext context) => Material(color: Colors.black.withValues(alpha: .38), shape: const CircleBorder(), child: IconButton(onPressed: onTap, icon: Icon(icon)));
}

class _TargetTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;
  const _TargetTile({required this.icon, required this.title, required this.onTap});
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 9),
    decoration: BoxDecoration(color: const Color(0xFF171D28), borderRadius: BorderRadius.circular(16)),
    child: ListTile(onTap: onTap, leading: Icon(icon), title: Text(title), trailing: const Icon(Icons.chevron_right)),
  );
}

class _SuccessDialog extends StatelessWidget {
  const _SuccessDialog();
  @override
  Widget build(BuildContext context) => AlertDialog(
    backgroundColor: const Color(0xFF10151E),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
    content: const Column(mainAxisSize: MainAxisSize.min, children: [
      CircleAvatar(radius: 38, backgroundColor: Color(0xFF173D38), child: Icon(Icons.check_rounded, size: 42, color: Color(0xFF73F2D1))),
      SizedBox(height: 18),
      Text('Duvar kağıdın ayarlandı!', textAlign: TextAlign.center, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
      SizedBox(height: 8),
      Text('Dünyan şimdi biraz daha senin gibi.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60)),
    ]),
    actions: [SizedBox(width: double.infinity, child: FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Harika!')))],
  );
}
