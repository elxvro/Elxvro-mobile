import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../app_state.dart';
import '../data/demo_wallpapers.dart';
import '../models/wallpaper.dart';
import '../services/wallpaper_service.dart';

class WallpaperDetailScreen extends StatefulWidget {
  final WallpaperItem item;

  const WallpaperDetailScreen({
    super.key,
    required this.item,
  });

  @override
  State<WallpaperDetailScreen> createState() => _WallpaperDetailScreenState();
}

class _WallpaperDetailScreenState extends State<WallpaperDetailScreen> {
  late final PageController _pageController;
  late int _currentIndex;
  bool setting = false;
  bool previewOnly = false;

  WallpaperItem get _currentItem => wallpapers[_currentIndex];

  @override
  void initState() {
    super.initState();
    final found = wallpapers.indexWhere((item) => item.id == widget.item.id);
    _currentIndex = found < 0 ? 0 : found;
    _pageController = PageController(initialPage: _currentIndex);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _chooseTarget() async {
    final selectedItem = _currentItem;
    final target = await showModalBottomSheet<WallpaperTarget>(
      context: context,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Nerede ayarlamak istersin?',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 14),
              _TargetTile(
                icon: Icons.phone_android,
                title: 'Ana Ekran',
                onTap: () =>
                    Navigator.pop(context, WallpaperTarget.home),
              ),
              _TargetTile(
                icon: Icons.lock_outline,
                title: 'Kilit Ekranı',
                onTap: () =>
                    Navigator.pop(context, WallpaperTarget.lock),
              ),
              _TargetTile(
                icon: Icons.splitscreen,
                title: 'Ana Ekran ve Kilit Ekranı',
                onTap: () =>
                    Navigator.pop(context, WallpaperTarget.both),
              ),
              const SizedBox(height: 6),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('İptal'),
              ),
            ],
          ),
        ),
      ),
    );

    if (target == null || !mounted) return;

    setState(() => setting = true);
    try {
      await WallpaperService.setFromAsset(selectedItem.asset, target);
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (_) => const _SuccessDialog(),
      );
    } on PlatformException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.message ?? 'Duvar kağıdı ayarlanamadı.'),
        ),
      );
    } finally {
      if (mounted) setState(() => setting = false);
    }
  }

  void _onPageChanged(int index) {
    setState(() => _currentIndex = index);
    AppScope.of(context).markViewed(wallpapers[index].id);
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final item = _currentItem;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          PageView.builder(
            controller: _pageController,
            itemCount: wallpapers.length,
            onPageChanged: _onPageChanged,
            itemBuilder: (context, index) => Image.asset(
              wallpapers[index].asset,
              fit: BoxFit.cover,
            ),
          ),
          IgnorePointer(
            ignoring: previewOnly,
            child: AnimatedOpacity(
              opacity: previewOnly ? 0 : 1,
              duration: const Duration(milliseconds: 180),
              child: const DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color(0x66000000),
                      Colors.transparent,
                      Color(0xE6000000),
                    ],
                  ),
                ),
              ),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(
                    children: [
                      _CircleButton(
                        icon: Icons.arrow_back,
                        onTap: () => Navigator.pop(context),
                      ),
                      const Spacer(),
                      _CircleButton(
                        icon: previewOnly
                            ? Icons.visibility_off_outlined
                            : Icons.visibility_outlined,
                        onTap: () => setState(() => previewOnly = !previewOnly),
                      ),
                      const SizedBox(width: 8),
                      _CircleButton(
                        icon: state.isFavorite(item.id)
                            ? Icons.favorite
                            : Icons.favorite_border,
                        onTap: () => state.toggleFavorite(item.id),
                      ),
                    ],
                  ),
                  const Spacer(),
                  AnimatedOpacity(
                    opacity: previewOnly ? 0 : 1,
                    duration: const Duration(milliseconds: 180),
                    child: IgnorePointer(
                      ignoring: previewOnly,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 6,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.black.withValues(alpha: .40),
                                  borderRadius: BorderRadius.circular(18),
                                ),
                                child: Text(
                                  item.category,
                                  style: const TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                              const Spacer(),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 6,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.black.withValues(alpha: .40),
                                  borderRadius: BorderRadius.circular(18),
                                ),
                                child: Text(
                                  '${_currentIndex + 1} / ${wallpapers.length}',
                                  style: const TextStyle(
                                    fontSize: 11,
                                    color: Colors.white70,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Text(
                            item.title,
                            style: const TextStyle(
                              fontSize: 26,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Wrap(
                            spacing: 7,
                            runSpacing: 7,
                            children: item.tags.map<Widget>((tag) {
                              return Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 6,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.black.withValues(alpha: .35),
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: Text(
                                  '#$tag',
                                  style: const TextStyle(fontSize: 11),
                                ),
                              );
                            }).toList(),
                          ),
                          const SizedBox(height: 9),
                          const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.swipe_rounded,
                                size: 17,
                                color: Colors.white54,
                              ),
                              SizedBox(width: 6),
                              Text(
                                'Diğer duvar kağıtları için sağa veya sola kaydır',
                                style: TextStyle(
                                  fontSize: 10,
                                  color: Colors.white54,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 13),
                          SizedBox(
                            width: double.infinity,
                            height: 54,
                            child: FilledButton.icon(
                              onPressed: setting ? null : _chooseTarget,
                              icon: setting
                                  ? const SizedBox(
                                      width: 18,
                                      height: 18,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                      ),
                                    )
                                  : const Icon(Icons.wallpaper_rounded),
                              label: Text(
                                setting
                                    ? 'Ayarlanıyor...'
                                    : 'Duvar Kağıdı Yap',
                              ),
                              style: FilledButton.styleFrom(
                                backgroundColor: const Color(0xFF8068FF),
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(18),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  if (previewOnly)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 13,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: .48),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Text(
                          'Tam ekran önizleme • Kaydırarak değiştir',
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 11,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _CircleButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _CircleButton({
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => Material(
        color: Colors.black.withValues(alpha: .42),
        shape: const CircleBorder(),
        child: IconButton(
          onPressed: onTap,
          icon: Icon(icon),
        ),
      );
}

class _TargetTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  const _TargetTile({
    required this.icon,
    required this.title,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 9),
        decoration: BoxDecoration(
          color: const Color(0xFF171D28),
          borderRadius: BorderRadius.circular(16),
        ),
        child: ListTile(
          onTap: onTap,
          leading: Icon(icon),
          title: Text(title),
          trailing: const Icon(Icons.chevron_right),
        ),
      );
}

class _SuccessDialog extends StatelessWidget {
  const _SuccessDialog();

  @override
  Widget build(BuildContext context) => AlertDialog(
        backgroundColor: const Color(0xFF10151E),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(28),
        ),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircleAvatar(
              radius: 38,
              backgroundColor: Color(0xFF173D38),
              child: Icon(
                Icons.check_rounded,
                size: 42,
                color: Color(0xFF73F2D1),
              ),
            ),
            SizedBox(height: 18),
            Text(
              'Duvar kağıdın ayarlandı!',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
            ),
            SizedBox(height: 8),
            Text(
              'Dünyan şimdi biraz daha senin gibi.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white60),
            ),
          ],
        ),
        actions: [
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Harika!'),
            ),
          ),
        ],
      );
}
