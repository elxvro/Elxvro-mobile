import 'package:flutter/material.dart';

import '../app_state.dart';
import '../data/local_wallpapers.dart';
import '../models/wallpaper.dart';
import '../theme/app_theme.dart';
import '../widgets/wallpaper_card.dart';
import '../widgets/wallpaper_image.dart';

enum CollectionMode { favorites, recent, applied, night, minimal }

class CollectionsScreen extends StatelessWidget {
  const CollectionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final nightItems = wallpapers.where(_isNight).toList(growable: false);
    final minimalItems = wallpapers.where(_isMinimal).toList(growable: false);
    final fallbackCover = wallpapers.isEmpty ? null : wallpapers.first;
    final secondCover = wallpapers.length > 1 ? wallpapers[1] : fallbackCover;
    final thirdCover = wallpapers.length > 2 ? wallpapers[2] : fallbackCover;

    return Scaffold(
      appBar: AppBar(title: const Text('Koleksiyonlar')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        children: [
          const Text(
            'Akıllı koleksiyonlar',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 5),
          const Text(
            'Favori, geçmiş ve içerik özelliklerine göre otomatik güncellenir.',
            style: TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 12,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 18),
          _CollectionTile(
            title: 'Favorilerim',
            subtitle: '${state.favorites.length} duvar kağıdı',
            icon: Icons.favorite_rounded,
            mode: CollectionMode.favorites,
            cover: state.favorites.isNotEmpty ? state.favorites.first : fallbackCover,
          ),
          _CollectionTile(
            title: 'Uyguladıklarım',
            subtitle: '${state.applied.length} duvar kağıdı',
            icon: Icons.done_all_rounded,
            mode: CollectionMode.applied,
            cover: state.applied.isNotEmpty ? state.applied.first : secondCover,
          ),
          _CollectionTile(
            title: 'Son baktıklarım',
            subtitle: '${state.recent.length} duvar kağıdı',
            icon: Icons.history_rounded,
            mode: CollectionMode.recent,
            cover: state.recent.isNotEmpty ? state.recent.first : thirdCover,
          ),
          _CollectionTile(
            title: 'Gece & Neon',
            subtitle: '${nightItems.length} duvar kağıdı',
            icon: Icons.nights_stay_rounded,
            mode: CollectionMode.night,
            cover: nightItems.isNotEmpty ? nightItems.first : fallbackCover,
          ),
          _CollectionTile(
            title: 'Minimal',
            subtitle: '${minimalItems.length} duvar kağıdı',
            icon: Icons.circle_outlined,
            mode: CollectionMode.minimal,
            cover: minimalItems.isNotEmpty ? minimalItems.first : fallbackCover,
          ),
        ],
      ),
    );
  }
}

class CollectionWallpapersScreen extends StatelessWidget {
  final CollectionMode mode;

  const CollectionWallpapersScreen({
    super.key,
    required this.mode,
  });

  String get _title {
    switch (mode) {
      case CollectionMode.favorites:
        return 'Favorilerim';
      case CollectionMode.recent:
        return 'Son Baktıklarım';
      case CollectionMode.applied:
        return 'Uyguladıklarım';
      case CollectionMode.night:
        return 'Gece & Neon';
      case CollectionMode.minimal:
        return 'Minimal';
    }
  }

  List<WallpaperItem> _items(AppState state) {
    switch (mode) {
      case CollectionMode.favorites:
        return state.favorites;
      case CollectionMode.recent:
        return state.recent;
      case CollectionMode.applied:
        return state.applied;
      case CollectionMode.night:
        return wallpapers.where(_isNight).toList();
      case CollectionMode.minimal:
        return wallpapers.where(_isMinimal).toList();
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final items = _items(state);
    final columns = state.compactGrid ? 3 : 2;

    return Scaffold(
      appBar: AppBar(title: Text(_title)),
      body: items.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(28),
                child: Text(
                  mode == CollectionMode.applied
                      ? 'Henüz uyguladığın bir duvar kağıdı yok.'
                      : 'Bu koleksiyon şu an boş.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: AppTheme.textSecondary),
                ),
              ),
            )
          : GridView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              itemCount: items.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: columns,
                childAspectRatio: .62,
                crossAxisSpacing: 11,
                mainAxisSpacing: 11,
              ),
              itemBuilder: (_, index) => WallpaperCard(item: items[index]),
            ),
    );
  }
}

class _CollectionTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final CollectionMode mode;
  final WallpaperItem? cover;

  const _CollectionTile({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.mode,
    required this.cover,
  });

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => CollectionWallpapersScreen(mode: mode),
          ),
        ),
        child: Container(
          height: 122,
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            boxShadow: const [
              BoxShadow(
                color: Color(0x120E1420),
                blurRadius: 20,
                offset: Offset(0, 8),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: Stack(
              fit: StackFit.expand,
              children: [
                const ColoredBox(color: Color(0xFF252A35)),
                if (cover != null)
                  WallpaperImage(
                    item: cover!,
                    fit: BoxFit.cover,
                    filterQuality: FilterQuality.low,
                    useThumbnail: true,
                  ),
                const DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.centerRight,
                      end: Alignment.centerLeft,
                      colors: [Color(0x22000000), Color(0xE5000000)],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Container(
                        width: 46,
                        height: 46,
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: .32),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: Colors.white24),
                        ),
                        child: Icon(icon, color: Colors.white),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              title,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 17,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              subtitle,
                              style: const TextStyle(
                                fontSize: 11,
                                color: Colors.white70,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Icon(Icons.chevron_right_rounded, color: Colors.white),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
}

bool _isNight(WallpaperItem item) =>
    item.tags.any((tag) => tag == 'Gece' || tag == 'Neon') ||
    item.title.toLowerCase().contains('gece');

bool _isMinimal(WallpaperItem item) =>
    item.category == 'Minimal' || item.tags.contains('Minimal');
