import 'package:flutter/material.dart';
import '../app_state.dart';
import '../data/demo_wallpapers.dart';
import '../models/wallpaper.dart';
import '../widgets/wallpaper_card.dart';

enum CollectionMode { favorites, recent, applied, night, minimal }

class CollectionsScreen extends StatelessWidget {
  const CollectionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final nightCount = wallpapers.where(_isNight).length;
    final minimalCount = wallpapers.where(_isMinimal).length;

    return Scaffold(
      appBar: AppBar(title: const Text('Koleksiyonlar')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        children: [
          const Text(
            'Akıllı koleksiyonlar',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 6),
          const Text(
            'Uygulama kullanımına göre otomatik güncellenir.',
            style: TextStyle(color: Colors.white54),
          ),
          const SizedBox(height: 18),
          _CollectionTile(
            title: 'Favorilerim',
            subtitle: '${state.favorites.length} duvar kağıdı',
            icon: Icons.favorite_rounded,
            mode: CollectionMode.favorites,
            cover: state.favorites.isNotEmpty
                ? state.favorites.first.asset
                : wallpapers.first.asset,
          ),
          _CollectionTile(
            title: 'Uyguladıklarım',
            subtitle: '${state.applied.length} duvar kağıdı',
            icon: Icons.done_all_rounded,
            mode: CollectionMode.applied,
            cover: state.applied.isNotEmpty
                ? state.applied.first.asset
                : wallpapers[1].asset,
          ),
          _CollectionTile(
            title: 'Son baktıklarım',
            subtitle: '${state.recent.length} duvar kağıdı',
            icon: Icons.history_rounded,
            mode: CollectionMode.recent,
            cover: state.recent.isNotEmpty
                ? state.recent.first.asset
                : wallpapers[2].asset,
          ),
          _CollectionTile(
            title: 'Gece & Neon',
            subtitle: '$nightCount duvar kağıdı',
            icon: Icons.nights_stay_rounded,
            mode: CollectionMode.night,
            cover: wallpapers.firstWhere(_isNight).asset,
          ),
          _CollectionTile(
            title: 'Minimal',
            subtitle: '$minimalCount duvar kağıdı',
            icon: Icons.circle_outlined,
            mode: CollectionMode.minimal,
            cover: wallpapers.firstWhere(_isMinimal).asset,
          ),
        ],
      ),
    );
  }
}

class CollectionWallpapersScreen extends StatelessWidget {
  final CollectionMode mode;

  const CollectionWallpapersScreen({
    super.key,
    required this.mode,
  });

  String get _title {
    switch (mode) {
      case CollectionMode.favorites:
        return 'Favorilerim';
      case CollectionMode.recent:
        return 'Son Baktıklarım';
      case CollectionMode.applied:
        return 'Uyguladıklarım';
      case CollectionMode.night:
        return 'Gece & Neon';
      case CollectionMode.minimal:
        return 'Minimal';
    }
  }

  List<WallpaperItem> _items(AppState state) {
    switch (mode) {
      case CollectionMode.favorites:
        return state.favorites;
      case CollectionMode.recent:
        return state.recent;
      case CollectionMode.applied:
        return state.applied;
      case CollectionMode.night:
        return wallpapers.where(_isNight).toList();
      case CollectionMode.minimal:
        return wallpapers.where(_isMinimal).toList();
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final items = _items(state);
    final columns = state.compactGrid ? 3 : 2;

    return Scaffold(
      appBar: AppBar(title: Text(_title)),
      body: items.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(28),
                child: Text(
                  mode == CollectionMode.applied
                      ? 'Henüz uyguladığın bir duvar kağıdı yok.'
                      : 'Bu koleksiyon şu an boş.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white60),
                ),
              ),
            )
          : GridView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              itemCount: items.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: columns,
                childAspectRatio: .62,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
              ),
              itemBuilder: (_, index) => WallpaperCard(item: items[index]),
            ),
    );
  }
}

class _CollectionTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final CollectionMode mode;
  final String cover;

  const _CollectionTile({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.mode,
    required this.cover,
  });

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => CollectionWallpapersScreen(mode: mode),
          ),
        ),
        child: Container(
          height: 118,
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            image: DecorationImage(image: AssetImage(cover), fit: BoxFit.cover),
          ),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              gradient: const LinearGradient(
                begin: Alignment.centerRight,
                end: Alignment.centerLeft,
                colors: [Color(0x22000000), Color(0xE0000000)],
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: .35),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Icon(icon),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        subtitle,
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.white70,
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right_rounded),
              ],
            ),
          ),
        ),
      );
}

bool _isNight(WallpaperItem item) =>
    item.tags.any((tag) => tag == 'Gece' || tag == 'Neon') ||
    item.title.toLowerCase().contains('gece');

bool _isMinimal(WallpaperItem item) =>
    item.category == 'Minimal' || item.tags.contains('Minimal');
