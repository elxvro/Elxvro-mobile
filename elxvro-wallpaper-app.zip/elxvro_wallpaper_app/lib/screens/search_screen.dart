import 'package:flutter/material.dart';
import '../app_state.dart';
import '../theme/app_theme.dart';
import '../data/local_wallpapers.dart';
import '../models/wallpaper.dart';
import '../utils/category_key.dart';
import '../widgets/wallpaper_card.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController controller = TextEditingController();
  String query = '';
  String selectedCategory = 'Tümü';
  String selectedTag = 'Tümü';
  bool favoritesOnly = false;
  int sortMode = 0;

  static const quickTags = <String>[
    'Tümü',
    'Gece',
    'Neon',
    'Minimal',
    'Mor',
    'Mavi',
    'Yeşil',
  ];

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  List<WallpaperItem> _results(AppState state) {
    final normalized = query.trim().toLowerCase();
    var items = wallpapers.where((item) {
      final haystack = <String>[
        item.title,
        item.category,
        ...item.tags,
      ].join(' ').toLowerCase();

      final matchesQuery = normalized.isEmpty || haystack.contains(normalized);
      final matchesCategory = selectedCategory == 'Tümü' ||
          categoryKey(item.category) == categoryKey(selectedCategory);
      final matchesTag = selectedTag == 'Tümü' ||
          item.tags.any((tag) => tag.toLowerCase() == selectedTag.toLowerCase());
      final matchesFavorite = !favoritesOnly || state.isFavorite(item.id);
      return matchesQuery && matchesCategory && matchesTag && matchesFavorite;
    }).toList();

    switch (sortMode) {
      case 1:
        items.sort((a, b) => a.title.compareTo(b.title));
        break;
      case 2:
        items.sort((a, b) => a.category.compareTo(b.category));
        break;
      case 3:
        items.sort((a, b) {
          final aFav = state.isFavorite(a.id) ? 0 : 1;
          final bFav = state.isFavorite(b.id) ? 0 : 1;
          if (aFav != bFav) return aFav.compareTo(bFav);
          return a.title.compareTo(b.title);
        });
        break;
    }
    return items;
  }

  Future<void> _showFilters(BuildContext context) async {
    final categoryNames = AppScope.of(context)
        .categories
        .map((item) => item.name)
        .toList(growable: false);
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (context) => StatefulBuilder(
        builder: (context, modalSetState) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Arama filtreleri',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 16),
                const Text('Kategori', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: ['Tümü', ...categoryNames].map((category) {
                    return ChoiceChip(
                      label: Text(category),
                      selected: selectedCategory == category,
                      onSelected: (_) {
                        modalSetState(() => selectedCategory = category);
                        setState(() {});
                      },
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: favoritesOnly,
                  onChanged: (value) {
                    modalSetState(() => favoritesOnly = value);
                    setState(() {});
                  },
                  title: const Text('Sadece favoriler'),
                  secondary: const Icon(Icons.favorite_border_rounded),
                ),
                const SizedBox(height: 6),
                const Text('Sıralama', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                SegmentedButton<int>(
                  segments: const [
                    ButtonSegment(value: 0, label: Text('Önerilen')),
                    ButtonSegment(value: 1, label: Text('A-Z')),
                    ButtonSegment(value: 3, label: Text('Favori')),
                  ],
                  selected: {sortMode == 2 ? 0 : sortMode},
                  onSelectionChanged: (values) {
                    final value = values.first;
                    modalSetState(() => sortMode = value);
                    setState(() {});
                  },
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Filtreleri uygula'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final items = _results(state);
    final columns = state.compactGrid ? 3 : 2;
    final hasFilters = selectedCategory != 'Tümü' ||
        selectedTag != 'Tümü' ||
        favoritesOnly ||
        sortMode != 0;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Ara'),
        actions: [
          IconButton(
            tooltip: 'Filtrele',
            onPressed: () => _showFilters(context),
            icon: Badge(
              isLabelVisible: hasFilters,
              child: const Icon(Icons.tune_rounded),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
            child: TextField(
              controller: controller,
              autofocus: true,
              onChanged: (value) => setState(() => query = value),
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                hintText: 'Doğa, uzay, neon, şehir...',
                prefixIcon: const Icon(Icons.search_rounded),
                suffixIcon: query.isEmpty
                    ? null
                    : IconButton(
                        onPressed: () {
                          controller.clear();
                          setState(() => query = '');
                        },
                        icon: const Icon(Icons.close_rounded),
                      ),
                filled: true,
                fillColor: Theme.of(context).colorScheme.surface,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          SizedBox(
            height: 40,
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              scrollDirection: Axis.horizontal,
              itemBuilder: (_, index) {
                final tag = quickTags[index];
                return ChoiceChip(
                  label: Text(tag),
                  selected: selectedTag == tag,
                  onSelected: (_) => setState(() => selectedTag = tag),
                );
              },
              separatorBuilder: (context, index) => const SizedBox(width: 8),
              itemCount: quickTags.length,
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 10, 18, 8),
            child: Row(
              children: [
                Text(
                  '${items.length} sonuç',
                  style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12),
                ),
                const Spacer(),
                if (hasFilters)
                  TextButton(
                    onPressed: () => setState(() {
                      selectedCategory = 'Tümü';
                      selectedTag = 'Tümü';
                      favoritesOnly = false;
                      sortMode = 0;
                    }),
                    child: const Text('Sıfırla'),
                  ),
              ],
            ),
          ),
          Expanded(
            child: items.isEmpty
                ? const Center(
                    child: Text(
                      'Filtrelere uyan duvar kağıdı bulunamadı.',
                      style: TextStyle(color: AppTheme.textSecondary),
                    ),
                  )
                : GridView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                    itemCount: items.length,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: columns,
                      childAspectRatio: .62,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                    ),
                    itemBuilder: (_, index) => WallpaperCard(item: items[index]),
                  ),
          ),
        ],
      ),
    );
  }
}
