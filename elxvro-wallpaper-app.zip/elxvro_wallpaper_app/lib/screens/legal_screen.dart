import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

enum LegalDocumentType { privacy, terms }

class LegalDocumentScreen extends StatelessWidget {
  final LegalDocumentType type;

  const LegalDocumentScreen({
    super.key,
    required this.type,
  });

  @override
  Widget build(BuildContext context) {
    final isPrivacy = type == LegalDocumentType.privacy;
    final title = isPrivacy ? 'Gizlilik Politikası' : 'Kullanım Koşulları';
    final sections = isPrivacy ? _privacySections : _termsSections;

    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                isPrivacy
                    ? 'ELXVRO, Google ile giriş ve uygulama içi kullanım sırasında hangi bilgilerin işlendiğini burada açıklar.'
                    : 'ELXVRO uygulamasını kullanırken geçerli temel kullanım kuralları burada yer alır.',
                style: const TextStyle(height: 1.45, color: AppTheme.textSecondary),
              ),
            ),
            const SizedBox(height: 18),
            ...sections.map(
              (section) => Padding(
                padding: const EdgeInsets.only(bottom: 18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      section.$1,
                      style: const TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 7),
                    Text(
                      section.$2,
                      style: const TextStyle(
                        color: AppTheme.textSecondary,
                        height: 1.55,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Son güncelleme: 19 Eylül 2026',
              style: TextStyle(color: AppTheme.textTertiary, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}

const _privacySections = <(String, String)>[
  (
    '1. Google ile giriş',
    "ELXVRO profil alanında yalnızca Google ile giriş kullanır. Google hesabınızın parolası ELXVRO tarafından görülmez veya saklanmaz. Giriş sırasında Google kimliği sunucuda doğrulanır; Google tarafından sağlanan sabit hesap kimliği, ad, e-posta adresi ve profil fotoğrafı URL'si ELXVRO hesabınızı oluşturmak ve yönetmek için MySQL veritabanında saklanır.",
  ),
  (
    '2. Uygulama kullanım verileri',
    'Bu sürümde favoriler, son görüntülenenler, uygulanan duvar kağıtları ve görünüm tercihleri cihaz üzerinde yerel olarak saklanır. Bu bilgiler uygulama deneyimini kişiselleştirmek için kullanılır.',
  ),
  (
    '3. Kategori verisi ve yerel görseller',
    'Uygulama kategori ve duvar kağıdı listesini ELXVRO servisinden alabilir. Galeri hızını artırmak için küçük önizlemeler ağ üzerinden gösterilebilir. Bir duvar kağıdını açtığınızda orijinal görsel, daha hızlı ve çevrimdışı kullanım amacıyla uygulamanın Android\'e özel dahili alanında yerel olarak saklanabilir; cihazın Galeri veya İndirilenler klasörüne eklenmez.',
  ),
  (
    '4. Duvar kağıdı işlemleri',
    'ELXVRO, seçtiğiniz görseli Android sisteminin duvar kağıdı özelliği üzerinden ana ekrana, kilit ekranına veya her ikisine uygulayabilir. Uygulama içinde görsel indirme özelliği bulunmaz.',
  ),
  (
    '5. Hesaptan çıkış ve veri silme',
    'Google hesabından çıkış yapmak MySQL üzerindeki ELXVRO hesap kaydını veya yerel favori ve geçmiş kayıtlarını otomatik olarak silmez. “ELXVRO hesabını sil” işlemi MySQL üzerindeki ELXVRO hesap kaydını siler, Google bağlantısını kaldırır ve cihazdaki favorileri, geçmişi, uygulananlar listesini ve tercihleri temizler. Bu işlem Google hesabınızın kendisini silmez.',
  ),
  (
    '6. İzinler ve güvenlik',
    "ELXVRO yalnızca uygulamanın çalışması için gereken Android özelliklerini kullanmayı amaçlar. Google kimlik doğrulaması Google hizmetleri tarafından yürütülür. ELXVRO sunucusu Google ID token'ını doğrular; Google parolası uygulamaya veya ELXVRO sunucusuna aktarılmaz.",
  ),
];

const _termsSections = <(String, String)>[
  (
    '1. Hizmetin kapsamı',
    'ELXVRO; duvar kağıtlarını keşfetme, önizleme, düzenleme, favorilere ekleme ve Android cihazınızda duvar kağıdı olarak ayarlama deneyimi sunar. Uygulama içinden görsel indirme özelliği sunulmaz.',
  ),
  (
    '2. Google hesabı',
    'Profil özelliklerini kullanmak için Google ile giriş yapmanız gerekir. Google hesabınızın güvenliği ve Google hizmetlerinin kullanım koşulları ayrıca Google tarafından yönetilir.',
  ),
  (
    '3. Kullanıcı sorumluluğu',
    'Uygulamayı hukuka uygun biçimde kullanmanız ve cihazınızda yaptığınız kişiselleştirme işlemlerinden sorumlu olmanız gerekir.',
  ),
  (
    '4. İçerik ve özellik değişiklikleri',
    'Uygulamadaki görseller, kategoriler, düzenleme araçları ve diğer özellikler yeni sürümlerde değiştirilebilir, geliştirilebilir veya kaldırılabilir.',
  ),
  (
    '5. Hesap silme',
    'Profil alanındaki “ELXVRO hesabını sil” seçeneğiyle MySQL üzerindeki ELXVRO hesap kaydınızı silebilir, ELXVRO bağlantınızı kaldırabilir ve uygulamada tutulan yerel kullanıcı verilerini temizleyebilirsiniz. Google hesabınız bu işlemden etkilenmez.',
  ),
];
