import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

// Uygulama içi metinler bilgilendirme amaçlı hazırlanmıştır.
// Yayına çıkmadan önce hedef pazarlardaki mevzuata göre hukuk danışmanı incelemesi önerilir.
enum LegalDocumentType { privacy, terms }

class LegalDocumentScreen extends StatelessWidget {
  final LegalDocumentType type;

  const LegalDocumentScreen({super.key, required this.type});

  @override
  Widget build(BuildContext context) {
    final isPrivacy = type == LegalDocumentType.privacy;
    final title = isPrivacy ? 'Gizlilik Politikası' : 'Kullanım Koşulları';
    final intro = isPrivacy
        ? 'Bu politika; ELXVRO hesabı, Google ile giriş, Google Drive yedekleme, yerel uygulama verileri ve duvar kağıdı hizmetleri kapsamında hangi verilerin nasıl işlendiğini açıklar.'
        : 'Bu koşullar ELXVRO uygulamasının kullanım kurallarını, kullanıcı sorumluluklarını, içerik haklarını, hizmet sınırlarını ve hesap işlemlerini düzenler.';
    final sections = isPrivacy ? _privacySections : _termsSections;

    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 6, 18, 34),
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFFF6EEFF), Color(0xFFFFFFFF)],
                ),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: const Color(0xFFE8D8FF)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: const Color(0xFF8B5CF6).withValues(alpha: .12),
                          borderRadius: BorderRadius.circular(13),
                        ),
                        child: Icon(
                          isPrivacy ? Icons.shield_outlined : Icons.gavel_rounded,
                          color: const Color(0xFF7C3AED),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          isPrivacy ? 'Gizliliğiniz önemlidir' : 'Açık ve adil kullanım kuralları',
                          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    intro,
                    style: const TextStyle(height: 1.55, color: AppTheme.textSecondary),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            ...sections.map(
              (section) => Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppTheme.surface,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: AppTheme.border),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      section.$1,
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 7),
                    Text(
                      section.$2,
                      style: const TextStyle(
                        color: AppTheme.textSecondary,
                        height: 1.58,
                        fontSize: 12.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Son güncelleme: 19 Eylül 2026 • Sürüm: 2026-09-19-v3',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppTheme.textTertiary, fontSize: 11),
            ),
          ],
        ),
      ),
    );
  }
}

const _privacySections = <(String, String)>[
  (
    '1. Veri sorumlusu ve kapsam',
    'ELXVRO, uygulama üzerinden sunulan hesap, kişiselleştirme, duvar kağıdı ve yedekleme işlevleri kapsamında işlenen veriler için hizmeti işleten taraftır. Bu politika uygulamanın Android sürümünü kapsar. Uygulanabilir KVKK, GDPR ve benzeri veri koruma düzenlemelerinden doğan zorunlu haklar saklıdır.',
  ),
  (
    '2. Google ile girişte işlenen bilgiler',
    'Profil alanı Google ile giriş kullanır. Google parolanız ELXVRO tarafından görülmez, alınmaz veya saklanmaz. Kimlik doğrulama sonrasında Google tarafından sağlanan sabit hesap kimliği, ad, e-posta adresi ve profil fotoğrafı bağlantısı ELXVRO hesabını oluşturmak, oturumu doğrulamak, kötüye kullanımı azaltmak ve hesap yönetimini sağlamak amacıyla MySQL veritabanında tutulabilir.',
  ),
  (
    '3. Google Drive yedekleme',
    'Google Drive yedekleme yalnızca kullanıcı tarafından başlatıldığında Drive erişim izni ister. ELXVRO, mümkün olan en dar kapsamlı Drive dosya iznini kullanarak kendi oluşturduğu “ELXVRO Backup.json” dosyasını oluşturur, günceller veya geri yükler. Bu yedek favori kimlikleri, son görüntülenenler, uygulanan duvar kağıdı kimlikleri ve desteklenen uygulama ayarlarını içerebilir. Google Drive erişimi reklam, davranışsal profil oluşturma veya ilgisiz dosyalara erişim amacıyla kullanılmaz.',
  ),
  (
    '4. Yerel uygulama verileri ve önbellek',
    'Favoriler, geçmiş, uygulananlar, görünüm tercihleri ve bazı oturum/izin kayıtları cihazın uygulamaya özel alanında tutulabilir. Galeri hızını ve çevrimdışı kullanımı artırmak için küçük önizlemeler ve açılan orijinal görseller cihazda önbelleğe alınabilir. Bu dosyalar uygulama tarafından Galeri veya İndirilenler klasörüne kullanıcı talebi olmadan aktarılmaz.',
  ),
  (
    '5. İşleme amaçları ve hukuki dayanak',
    'Veriler; talep edilen hizmeti sunmak, hesabı doğrulamak, tercihleri korumak, yedekleme ve geri yükleme işlemlerini gerçekleştirmek, güvenlik ve hata önleme sağlamak amacıyla işlenir. Hukuki dayanak; hizmetin ifası, kullanıcının açıkça başlattığı işlemler, meşru güvenlik ihtiyaçları ve uygulanabilir olduğu ölçüde kullanıcının rızası olabilir.',
  ),
  (
    '6. Üçüncü taraf hizmetleri',
    'Google ile giriş ve Google Drive özellikleri Google hizmetlerini kullanır ve bu hizmetlerin kendi gizlilik şartları ayrıca geçerlidir. ELXVRO içerik ve hesap servisleri barındırma/hosting sağlayıcısı üzerinden çalışabilir. Hizmet sağlayıcılarına yalnızca teknik olarak gerekli veriler aktarılabilir; ELXVRO kullanıcı verilerini reklamverenlere satmayı amaçlamaz.',
  ),
  (
    '7. Saklama süresi ve silme',
    'ELXVRO hesap kaydı hesap aktif olduğu sürece veya yasal/teknik gereklilikler ölçüsünde tutulabilir. “ELXVRO hesabını sil” işlemi sunucudaki ELXVRO hesap kaydını ve cihazdaki kullanıcı verilerini silmek için tasarlanmıştır; Google hesabını silmez. Google Drive’daki yedek kullanıcı Drive hesabında kalabilir ve kullanıcı tarafından Drive üzerinden ayrıca silinebilir.',
  ),
  (
    '8. Güvenlik',
    'Kimlik doğrulama belirteçleri aktarım sırasında HTTPS üzerinden iletilir ve Google ID token sunucuda doğrulanır. Makul teknik ve idari güvenlik önlemleri uygulanır; ancak hiçbir internet, cihaz veya depolama sistemi mutlak güvenlik garantisi veremez. Kullanıcı, cihaz ve Google hesabı güvenliğini korumaktan da sorumludur.',
  ),
  (
    '9. Kullanıcı hakları',
    'Uygulanabilir mevzuatın sağladığı ölçüde kullanıcılar verilerine erişme, düzeltme, silme, işlemeyi sınırlama veya izinleri geri çekme haklarına sahip olabilir. Google Drive izni Google hesabı izinlerinden kaldırılabilir. ELXVRO hesabı uygulamadaki hesap silme seçeneğiyle kaldırılabilir.',
  ),
  (
    '10. Çocukların gizliliği',
    'ELXVRO, uygulanabilir mevzuat kapsamında gerekli yaşın altındaki kişilerden bilerek kişisel veri toplamayı amaçlamaz. Reşit olmayan kullanıcıların hizmeti kullanması için gerekli olduğu durumlarda veli veya yasal temsilci izni aranmalıdır.',
  ),
  (
    '11. Politika değişiklikleri ve iletişim',
    'Özellikler, mevzuat veya veri işleme yöntemleri değiştiğinde bu politika güncellenebilir ve önemli değişikliklerde yeniden onay istenebilir. Gizlilik talepleri için ELXVRO web sitesindeki resmi iletişim kanalı kullanılabilir.',
  ),
];

const _termsSections = <(String, String)>[
  (
    '1. Koşulların kabulü',
    'ELXVRO uygulamasını kullanarak bu koşulları ve ilgili Gizlilik Politikasını kabul etmiş olursunuz. Zorunlu tüketici hakları ve uygulanabilir mevzuattan doğan vazgeçilemez haklar bu koşullarla ortadan kaldırılmaz.',
  ),
  (
    '2. Hizmetin kapsamı',
    'ELXVRO; duvar kağıtlarını keşfetme, önizleme, favorileme, düzenleme, cihazda duvar kağıdı olarak uygulama ve desteklenen kullanıcı verilerini Google Drive’a yedekleme işlevleri sunabilir. Özelliklerin tamamı her cihaz, Android sürümü veya bölgede aynı şekilde çalışmayabilir.',
  ),
  (
    '3. Hesap ve güvenlik',
    'Profil özellikleri Google hesabıyla kullanılabilir. Kullanıcı kendi Google hesabının ve cihazının güvenliğinden, yetkisiz erişimi önlemekten ve yanlış hesaba yapılan yedekleme/geri yükleme işlemlerini kontrol etmekten sorumludur. ELXVRO hiçbir zaman Google parolanızı istemez.',
  ),
  (
    '4. Google Drive yedeklerinin sorumluluğu',
    'Drive yedekleme kolaylık amacıyla sunulur. Ağ kesintisi, Google hizmeti, kullanıcı tarafından dosyanın silinmesi, izinlerin kaldırılması veya üçüncü taraf hizmet değişiklikleri nedeniyle yedek erişilemez hale gelebilir. Kritik veriler için kullanıcı ayrıca uygun yedekleme yöntemlerini kullanmalıdır.',
  ),
  (
    '5. İçerik ve fikri mülkiyet',
    'ELXVRO adı, logo, arayüz, yazılım, tasarım unsurları ve ELXVRO tarafından sağlanan içerikler ilgili hak sahiplerinin fikri mülkiyet haklarına tabi olabilir. Uygulamada bir görselin gösterilmesi, aksi açıkça belirtilmedikçe görsel üzerinde mülkiyet, yeniden satış, ticari dağıtım veya sınırsız yeniden kullanım hakkı vermez.',
  ),
  (
    '6. Yasaklanan kullanım',
    'Uygulamanın güvenlik mekanizmalarını aşmaya çalışmak, hizmete zarar vermek, API’leri kötüye kullanmak, otomatik aşırı trafik oluşturmak, başkalarının hesaplarına yetkisiz erişmek veya uygulamayı hukuka aykırı amaçlarla kullanmak yasaktır. Gerekli durumlarda erişim sınırlandırılabilir.',
  ),
  (
    '7. Düzenleme ve cihaz sonuçları',
    'Düzenleyici, ekran önizlemesi ve Android duvar kağıdı sonucu cihaz üreticisi, ekran oranı, sistem kırpması ve Android sürümüne göre farklılık gösterebilir. Kullanıcı uygulama öncesinde önizlemeyi kontrol etmelidir.',
  ),
  (
    '8. Hizmetin kullanılabilirliği',
    'ELXVRO kesintisiz, hatasız veya her zaman erişilebilir hizmet taahhüdü vermez. Bakım, güvenlik, hosting, üçüncü taraf servisleri veya teknik nedenlerle özellikler geçici olarak durabilir, değişebilir veya kaldırılabilir.',
  ),
  (
    '9. Garanti reddi ve sorumluluk sınırı',
    'Hizmet, uygulanabilir hukukun izin verdiği azami ölçüde mevcut haliyle sunulur. ELXVRO; dolaylı zararlar, cihaz üreticisine bağlı davranışlar, üçüncü taraf hizmet kesintileri, kullanıcı hatası veya kullanıcının kendi Drive/Google hesabındaki işlemlerden doğan kayıplar için mevzuatın izin verdiği ölçüde sorumluluğu sınırlandırır. Kasıt, ağır kusur veya kanunen sınırlandırılamayan sorumluluklar bu hükmün dışındadır.',
  ),
  (
    '10. Hesabın kapatılması',
    'Kullanıcı profil alanından ELXVRO hesabını silebilir. ELXVRO, güvenlik ihlali, hukuka aykırı kullanım veya hizmet bütünlüğünü tehdit eden davranışlarda hesabı ya da erişimi sınırlandırabilir. Google hesabının kendisi ELXVRO tarafından silinmez.',
  ),
  (
    '11. Değişiklikler ve geçerlilik',
    'Bu koşullar uygulama, iş modeli, teknik altyapı veya mevzuat değiştiğinde güncellenebilir. Bir hükmün geçersiz olması diğer hükümlerin geçerliliğini otomatik olarak etkilemez. Uyuşmazlıklarda uygulanacak zorunlu hukuk ve yetkili merciler kullanıcının bulunduğu ülkenin emredici kuralları saklı kalmak üzere belirlenir.',
  ),
];
