import 'package:flutter/material.dart';
import '../data/demo_wallpapers.dart';
import '../widgets/wallpaper_card.dart';

class CategoryWallpapersScreen extends StatelessWidget {
  final String category;
  const CategoryWallpapersScreen({super.key, required this.category});

  @override
  Widget build(BuildContext context) {
    final items = wallpapers.where((w) => w.category == category).toList();
    return Scaffold(
      appBar: AppBar(title: Text(category), backgroundColor: Colors.transparent),
      body: GridView.builder(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        itemCount: items.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: .62, crossAxisSpacing: 12, mainAxisSpacing: 12),
        itemBuilder: (_, i) => WallpaperCard(item: items[i]),
      ),
    );
  }
}
