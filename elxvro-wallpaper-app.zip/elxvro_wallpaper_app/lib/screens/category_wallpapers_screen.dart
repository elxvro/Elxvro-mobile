import 'dart:math';

import 'package:flutter/material.dart';

import '../app_state.dart';
import '../data/local_wallpapers.dart';
import '../models/wallpaper.dart';
import '../theme/app_theme.dart';
import '../utils/category_key.dart';
import '../widgets/wallpaper_card.dart';
import 'wallpaper_detail_screen.dart';

class CategoryWallpapersScreen extends StatefulWidget {
  final String categoryName;
  final String categorySlug;

  const CategoryWallpapersScreen({
    super.key,
    required this.categoryName,
    required this.categorySlug,
  });

  @override
  State<CategoryWallpapersScreen> createState() =>
      _CategoryWallpapersScreenState();
}

class _CategoryWallpapersScreenState extends State<CategoryWallpapersScreen> {
  int sortMode = 0;

  List<WallpaperItem> _items(AppState state) {
    final items = wallpapers.where((w) {
      final key = categoryKey(w.category);
      return key == widget.categorySlug || key == categoryKey(widget.categoryName);
    }).toList();
    switch (sortMode) {
      case 1:
        items.sort((a, b) => a.title.compareTo(b.title));
        break;
      case 2:
        items.sort((a, b) {
          final aFav = state.isFavorite(a.id) ? 0 : 1;
          final bFav = state.isFavorite(b.id) ? 0 : 1;
          if (aFav != bFav) return aFav.compareTo(bFav);
          return a.title.compareTo(b.title);
        });
        break;
      case 3:
        return items.reversed.toList();
    }
    return items;
  }

  String get _sortLabel {
    switch (sortMode) {
      case 1:
        return 'A-Z';
      case 2:
        return 'Favoriler önce';
      case 3:
        return 'En yeni';
      default:
        return 'Önerilen';
    }
  }

  void _openRandom(BuildContext context, List<WallpaperItem> items) {
    if (items.isEmpty) return;
    final item = items[Random().nextInt(items.length)];
    AppScope.of(context).markViewed(item.id);
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => WallpaperDetailScreen(item: item)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final items = _items(state);
    final columns = state.compactGrid ? 3 : 2;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.categoryName),
        actions: [
          IconButton(
            tooltip: 'Rastgele aç',
            onPressed: items.isEmpty ? null : () => _openRandom(context, items),
            icon: const Icon(Icons.shuffle_rounded),
          ),
          PopupMenuButton<int>(
            tooltip: 'Sırala',
            initialValue: sortMode,
            onSelected: (value) => setState(() => sortMode = value),
            itemBuilder: (_) => const [
              PopupMenuItem(value: 0, child: Text('Önerilen')),
              PopupMenuItem(value: 1, child: Text('A-Z')),
              PopupMenuItem(value: 2, child: Text('Favoriler önce')),
              PopupMenuItem(value: 3, child: Text('En yeni sıra')),
            ],
            icon: const Icon(Icons.sort_rounded),
          ),
        ],
      ),
      body: items.isEmpty
          ? const _EmptyCategory()
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
                    decoration: BoxDecoration(
                      color: AppTheme.surface,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppTheme.border),
                    ),
                    child: Row(
                      children: [
                        Text(
                          '${items.length} görsel',
                          style: const TextStyle(
                            color: AppTheme.textSecondary,
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const Spacer(),
                        const Icon(Icons.swap_vert_rounded, size: 15, color: AppTheme.textTertiary),
                        const SizedBox(width: 4),
                        Text(
                          _sortLabel,
                          style: const TextStyle(
                            color: AppTheme.textSecondary,
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: GridView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                    itemCount: items.length,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: columns,
                      childAspectRatio: .62,
                      crossAxisSpacing: 11,
                      mainAxisSpacing: 11,
                    ),
                    itemBuilder: (_, i) => WallpaperCard(item: items[i]),
                  ),
                ),
              ],
            ),
    );
  }
}

class _EmptyCategory extends StatelessWidget {
  const _EmptyCategory();

  @override
  Widget build(BuildContext context) => const Center(
        child: Padding(
          padding: EdgeInsets.all(30),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.photo_library_outlined,
                size: 52,
                color: AppTheme.textTertiary,
              ),
              SizedBox(height: 14),
              Text(
                'Bu kategoride henüz görsel yok.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: AppTheme.textSecondary,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      );
}
