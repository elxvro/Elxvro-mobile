import 'dart:math';
import 'package:flutter/material.dart';
import '../app_state.dart';
import '../data/demo_wallpapers.dart';
import '../models/wallpaper.dart';
import '../widgets/wallpaper_card.dart';
import 'wallpaper_detail_screen.dart';

class CategoryWallpapersScreen extends StatefulWidget {
  final String category;

  const CategoryWallpapersScreen({
    super.key,
    required this.category,
  });

  @override
  State<CategoryWallpapersScreen> createState() =>
      _CategoryWallpapersScreenState();
}

class _CategoryWallpapersScreenState extends State<CategoryWallpapersScreen> {
  int sortMode = 0;

  List<WallpaperItem> _items(AppState state) {
    final items = wallpapers.where((w) => w.category == widget.category).toList();
    switch (sortMode) {
      case 1:
        items.sort((a, b) => a.title.compareTo(b.title));
        break;
      case 2:
        items.sort((a, b) {
          final aFav = state.isFavorite(a.id) ? 0 : 1;
          final bFav = state.isFavorite(b.id) ? 0 : 1;
          if (aFav != bFav) return aFav.compareTo(bFav);
          return a.title.compareTo(b.title);
        });
        break;
      case 3:
        return items.reversed.toList();
    }
    return items;
  }

  void _openRandom(BuildContext context, List<WallpaperItem> items) {
    if (items.isEmpty) return;
    final item = items[Random().nextInt(items.length)];
    AppScope.of(context).markViewed(item.id);
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => WallpaperDetailScreen(item: item)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final items = _items(state);
    final columns = state.compactGrid ? 3 : 2;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.category),
        actions: [
          IconButton(
            tooltip: 'Rastgele aç',
            onPressed: items.isEmpty ? null : () => _openRandom(context, items),
            icon: const Icon(Icons.shuffle_rounded),
          ),
          PopupMenuButton<int>(
            tooltip: 'Sırala',
            initialValue: sortMode,
            onSelected: (value) => setState(() => sortMode = value),
            itemBuilder: (_) => const [
              PopupMenuItem(value: 0, child: Text('Önerilen')),
              PopupMenuItem(value: 1, child: Text('A-Z')),
              PopupMenuItem(value: 2, child: Text('Favoriler önce')),
              PopupMenuItem(value: 3, child: Text('En yeni sıra')),
            ],
            icon: const Icon(Icons.sort_rounded),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
            child: Row(
              children: [
                Text(
                  '${items.length} duvar kağıdı',
                  style: const TextStyle(color: Colors.white54),
                ),
                const Spacer(),
                Text(
                  state.compactGrid ? 'Kompakt görünüm' : 'Standart görünüm',
                  style: const TextStyle(color: Colors.white38, fontSize: 11),
                ),
              ],
            ),
          ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              itemCount: items.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: columns,
                childAspectRatio: .62,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
              ),
              itemBuilder: (_, i) => WallpaperCard(item: items[i]),
            ),
          ),
        ],
      ),
    );
  }
}
