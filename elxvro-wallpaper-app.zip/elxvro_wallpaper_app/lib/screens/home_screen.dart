import 'dart:math';

import 'package:flutter/material.dart';

import '../app_state.dart';
import '../data/local_wallpapers.dart';
import '../models/wallpaper.dart';
import '../theme/app_theme.dart';
import '../utils/category_key.dart';
import '../widgets/brand_wordmark.dart';
import '../widgets/wallpaper_card.dart';
import '../widgets/wallpaper_image.dart';
import 'collections_screen.dart';
import 'search_screen.dart';
import 'settings_screen.dart';
import 'wallpaper_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedFilter = 0;
  bool _categoryLoadRequested = false;
  static const filters = ['Tümü', 'Popüler', 'Yeni', 'Senin için'];

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_categoryLoadRequested) return;
    _categoryLoadRequested = true;
    final state = AppScope.of(context);
    Future.microtask(state.refreshCategories);
  }

  WallpaperItem get _dailyPick {
    final now = DateTime.now();
    final dayKey = DateTime(now.year, now.month, now.day)
        .difference(DateTime(2026))
        .inDays
        .abs();
    return wallpapers[dayKey % wallpapers.length];
  }

  List<WallpaperItem> _filtered(BuildContext context) {
    switch (selectedFilter) {
      case 1:
        final popular = wallpapers.where((item) {
          final key = categoryKey(item.category);
          return const {'anime', 'doga', 'hayvan', 'sehir'}.contains(key);
        }).toList();
        return popular.isEmpty ? wallpapers.take(24).toList() : popular;
      case 2:
        return wallpapers.reversed.toList();
      case 3:
        final state = AppScope.of(context);
        final favoriteCategories = state.favorites.map((e) => e.category).toSet();
        final recommended = wallpapers.where((item) {
          return favoriteCategories.contains(item.category) &&
              !state.isFavorite(item.id);
        }).toList();
        final fallback = wallpapers
            .where((item) => !state.isFavorite(item.id))
            .take(18)
            .toList();
        return <WallpaperItem>[
          ...state.favorites,
          ...(recommended.isEmpty ? fallback : recommended),
        ].take(36).toList();
      default:
        return wallpapers;
    }
  }

  void _openWallpaper(BuildContext context, WallpaperItem item) {
    AppScope.of(context).markViewed(item.id);
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => WallpaperDetailScreen(item: item)),
    );
  }

  void _openSurprise(BuildContext context) {
    final currentRecent = AppScope.of(context).recent;
    final lastViewedId = currentRecent.isEmpty ? null : currentRecent.first.id;
    final candidates = wallpapers
        .where((item) => item.id != lastViewedId)
        .toList(growable: false);
    final pool = candidates.isEmpty ? wallpapers : candidates;
    if (pool.isEmpty) return;
    final item = pool[Random().nextInt(pool.length)];
    _openWallpaper(context, item);
  }

  void _openSearch() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const SearchScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final featured = _dailyPick;
    final visibleItems = _filtered(context);
    final recent = state.recent.take(6).toList();
    final lastApplied = state.lastApplied;
    final columns = state.compactGrid ? 3 : 2;
    final accent = state.accentColor;

    return SafeArea(
      bottom: false,
      child: CustomScrollView(
        physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 18, 12, 10),
            sliver: SliverToBoxAdapter(
              child: Row(
                children: [
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        BrandWordmark(fontSize: 21, letterSpacing: 3.4),
                        SizedBox(height: 5),
                        Text(
                          'Duvarını yeniden keşfet',
                          style: TextStyle(
                            color: AppTheme.textSecondary,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  _HeaderButton(
                    icon: Icons.auto_awesome_mosaic_outlined,
                    tooltip: 'Koleksiyonlar',
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const CollectionsScreen()),
                    ),
                  ),
                  const SizedBox(width: 7),
                  _HeaderButton(
                    icon: Icons.tune_rounded,
                    tooltip: 'Ayarlar',
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const SettingsScreen()),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 8, 18, 4),
            sliver: SliverToBoxAdapter(
              child: InkWell(
                onTap: _openSearch,
                borderRadius: BorderRadius.circular(18),
                child: Container(
                  height: 54,
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  decoration: BoxDecoration(
                    color: AppTheme.surface,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: AppTheme.border),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x0B121826),
                        blurRadius: 18,
                        offset: Offset(0, 7),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.search_rounded, color: AppTheme.textSecondary),
                      const SizedBox(width: 10),
                      const Expanded(
                        child: Text(
                          'Duvar kağıdı, kategori veya etiket ara',
                          style: TextStyle(
                            color: AppTheme.textSecondary,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                        decoration: BoxDecoration(
                          color: accent.withValues(alpha: .09),
                          borderRadius: BorderRadius.circular(11),
                        ),
                        child: Text(
                          '${state.visibleMediaCount}',
                          style: TextStyle(
                            color: accent,
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 0),
            sliver: SliverToBoxAdapter(
              child: GestureDetector(
                onTap: () => _openWallpaper(context, featured),
                child: Container(
                  height: 238,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x220E1420),
                        blurRadius: 24,
                        offset: Offset(0, 10),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(30),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        WallpaperImage(
                          item: featured,
                          fit: BoxFit.cover,
                          progressive: true,
                        ),
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: const BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [Color(0x15000000), Color(0xE0000000)],
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 10,
                                      vertical: 6,
                                    ),
                                    decoration: BoxDecoration(
                                      color: Colors.white.withValues(alpha: .16),
                                      borderRadius: BorderRadius.circular(14),
                                      border: Border.all(color: Colors.white24),
                                    ),
                                    child: const Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(Icons.auto_awesome_rounded, size: 12, color: Colors.white),
                                        SizedBox(width: 5),
                                        Text(
                                          'GÜNÜN SEÇİMİ',
                                          style: TextStyle(
                                            fontSize: 9,
                                            letterSpacing: 1.2,
                                            color: Colors.white,
                                            fontWeight: FontWeight.w800,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const Spacer(),
                                  Text(
                                    featured.category,
                                    style: const TextStyle(
                                      fontSize: 11,
                                      color: Colors.white70,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),
                              const Text(
                                'Bugün ekranına\nyeni bir hava kat',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 25,
                                  height: 1.04,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 8),
                              const Row(
                                children: [
                                  Icon(Icons.touch_app_rounded, size: 14, color: Colors.white70),
                                  SizedBox(width: 5),
                                  Text(
                                    'Açmak için dokun',
                                    style: TextStyle(
                                      fontSize: 11,
                                      color: Colors.white70,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SliverPadding(
            padding: EdgeInsets.fromLTRB(18, 22, 18, 10),
            sliver: SliverToBoxAdapter(
              child: Text(
                'Hızlı Keşfet',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 18),
            sliver: SliverToBoxAdapter(
              child: Row(
                children: [
                  Expanded(
                    child: _QuickAction(
                      icon: Icons.new_releases_outlined,
                      label: 'Yeni',
                      accent: accent,
                      onTap: () => setState(() => selectedFilter = 2),
                    ),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: _QuickAction(
                      icon: Icons.shuffle_rounded,
                      label: 'Sürpriz',
                      accent: accent,
                      onTap: () => _openSurprise(context),
                    ),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: _QuickAction(
                      icon: Icons.auto_awesome_mosaic_outlined,
                      label: 'Koleksiyon',
                      accent: accent,
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const CollectionsScreen()),
                      ),
                    ),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: _QuickAction(
                      icon: Icons.search_rounded,
                      label: 'Ara',
                      accent: accent,
                      onTap: _openSearch,
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (lastApplied != null)
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 0),
              sliver: SliverToBoxAdapter(
                child: InkWell(
                  onTap: () => _openWallpaper(context, lastApplied),
                  borderRadius: BorderRadius.circular(20),
                  child: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: AppTheme.surface,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: AppTheme.border),
                    ),
                    child: Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(13),
                          child: WallpaperImage(
                            item: lastApplied,
                            width: 44,
                            height: 60,
                            fit: BoxFit.cover,
                            filterQuality: FilterQuality.low,
                            useThumbnail: true,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Son uygulanan',
                                style: TextStyle(
                                  fontSize: 10,
                                  color: AppTheme.textSecondary,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                lastApplied.category,
                                style: const TextStyle(fontWeight: FontWeight.w800),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: 34,
                          height: 34,
                          decoration: BoxDecoration(
                            color: accent.withValues(alpha: .08),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(Icons.chevron_right_rounded, color: accent),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          if (recent.isNotEmpty) ...[
            const SliverPadding(
              padding: EdgeInsets.fromLTRB(18, 22, 18, 10),
              sliver: SliverToBoxAdapter(
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Devam Et',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                      ),
                    ),
                    Text(
                      'Son baktıkların',
                      style: TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: SizedBox(
                height: 148,
                child: ListView.separated(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  scrollDirection: Axis.horizontal,
                  itemCount: recent.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 10),
                  itemBuilder: (_, index) {
                    final item = recent[index];
                    return GestureDetector(
                      onTap: () => _openWallpaper(context, item),
                      child: Container(
                        width: 94,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(19),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0x100E1420),
                              blurRadius: 16,
                              offset: Offset(0, 6),
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(19),
                          child: WallpaperImage(
                            item: item,
                            fit: BoxFit.cover,
                            filterQuality: FilterQuality.low,
                            useThumbnail: true,
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ],
          const SliverPadding(
            padding: EdgeInsets.fromLTRB(18, 26, 18, 9),
            sliver: SliverToBoxAdapter(
              child: Text(
                'Duvar Kağıtları',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 43,
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 18),
                scrollDirection: Axis.horizontal,
                itemCount: filters.length,
                itemBuilder: (_, index) => _FilterChip(
                  text: filters[index],
                  selected: selectedFilter == index,
                  onTap: () => setState(() => selectedFilter = index),
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 10),
            sliver: SliverToBoxAdapter(
              child: Row(
                children: [
                  Text(
                    filters[selectedFilter] == 'Tümü'
                        ? 'Öne Çıkanlar'
                        : filters[selectedFilter],
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
                  ),
                  const Spacer(),
                  Text(
                    '${visibleItems.length} görsel',
                    style: const TextStyle(
                      color: AppTheme.textSecondary,
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 0, 18, 30),
            sliver: SliverGrid.builder(
              itemCount: visibleItems.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: columns,
                childAspectRatio: .62,
                crossAxisSpacing: 11,
                mainAxisSpacing: 11,
              ),
              itemBuilder: (context, index) => WallpaperCard(item: visibleItems[index]),
            ),
          ),
        ],
      ),
    );
  }
}

class _HeaderButton extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final VoidCallback onTap;

  const _HeaderButton({
    required this.icon,
    required this.tooltip,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => Tooltip(
        message: tooltip,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(15),
          child: Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: AppTheme.surface,
              borderRadius: BorderRadius.circular(15),
              border: Border.all(color: AppTheme.border),
            ),
            child: Icon(icon, size: 20),
          ),
        ),
      );
}

class _QuickAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color accent;
  final VoidCallback onTap;

  const _QuickAction({
    required this.icon,
    required this.label,
    required this.accent,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          height: 77,
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 10),
          decoration: BoxDecoration(
            color: AppTheme.surface,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AppTheme.border),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 31,
                height: 31,
                decoration: BoxDecoration(
                  color: accent.withValues(alpha: .09),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, size: 17, color: accent),
              ),
              const SizedBox(height: 6),
              Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 9.5, fontWeight: FontWeight.w700),
              ),
            ],
          ),
        ),
      );
}

class _FilterChip extends StatelessWidget {
  final String text;
  final bool selected;
  final VoidCallback onTap;

  const _FilterChip({
    required this.text,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final accent = AppScope.of(context).accentColor;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 15),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: selected ? accent : AppTheme.surface,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: selected ? accent : AppTheme.border),
        ),
        child: Text(
          text,
          style: TextStyle(
            color: selected ? Colors.white : AppTheme.textSecondary,
            fontWeight: FontWeight.w700,
            fontSize: 11,
          ),
        ),
      ),
    );
  }
}
