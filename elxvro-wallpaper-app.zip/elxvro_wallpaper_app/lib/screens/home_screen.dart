import 'package:flutter/material.dart';
import '../data/demo_wallpapers.dart';
import '../widgets/wallpaper_card.dart';
import 'category_wallpapers_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final featured = wallpapers.first;
    return SafeArea(
      bottom: false,
      child: CustomScrollView(
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 10),
            sliver: SliverToBoxAdapter(
              child: Row(
                children: [
                  const Expanded(child: Text('E L X V R O', style: TextStyle(fontSize: 20, letterSpacing: 5, fontWeight: FontWeight.w500))),
                  IconButton(onPressed: () {}, icon: const Icon(Icons.search_rounded)),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 44,
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 18),
                scrollDirection: Axis.horizontal,
                children: const [
                  _Chip('Tümü', selected: true), _Chip('Popüler'), _Chip('Yeni'), _Chip('Senin için'),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 0),
            sliver: SliverToBoxAdapter(
              child: GestureDetector(
                onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => CategoryWallpapersScreen(category: featured.category))),
                child: Container(
                  height: 220,
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(28), image: DecorationImage(image: AssetImage(featured.asset), fit: BoxFit.cover)),
                  child: Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(28),
                      gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Color(0xCC05070C)]),
                    ),
                    child: const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text('GÜNÜN SEÇİMİ', style: TextStyle(fontSize: 11, letterSpacing: 2, color: Colors.white70)),
                        SizedBox(height: 5),
                        Text('Daha geniş bir dünyaya bak.', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w700)),
                        SizedBox(height: 4),
                        Text('İndirmen gerekmez. Beğen, önizle ve uygula.', style: TextStyle(fontSize: 13, color: Colors.white70)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 22, 18, 12),
            sliver: SliverToBoxAdapter(
              child: Row(children: [
                const Expanded(child: Text('Kategoriler', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w700))),
                TextButton(onPressed: () {}, child: const Text('Tümünü Gör')),
              ]),
            ),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 92,
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 18),
                scrollDirection: Axis.horizontal,
                itemBuilder: (context, i) {
                  final category = categories[i];
                  final item = wallpapers.firstWhere((w) => w.category == category);
                  return GestureDetector(
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => CategoryWallpapersScreen(category: category))),
                    child: Container(
                      width: 118,
                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), image: DecorationImage(image: AssetImage(item.asset), fit: BoxFit.cover)),
                      child: Container(
                        alignment: Alignment.bottomLeft,
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Color(0xC0000000)])),
                        child: Text(category, style: const TextStyle(fontWeight: FontWeight.w600)),
                      ),
                    ),
                  );
                },
                separatorBuilder: (_, __) => const SizedBox(width: 10),
                itemCount: categories.length,
              ),
            ),
          ),
          const SliverPadding(
            padding: EdgeInsets.fromLTRB(18, 24, 18, 12),
            sliver: SliverToBoxAdapter(child: Text('Öne Çıkanlar', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w700))),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 0, 18, 28),
            sliver: SliverGrid.builder(
              itemCount: wallpapers.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: .62, crossAxisSpacing: 12, mainAxisSpacing: 12),
              itemBuilder: (context, i) => WallpaperCard(item: wallpapers[i]),
            ),
          ),
        ],
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  final String text;
  final bool selected;
  const _Chip(this.text, {this.selected = false});
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(right: 8),
    padding: const EdgeInsets.symmetric(horizontal: 16),
    alignment: Alignment.center,
    decoration: BoxDecoration(color: selected ? const Color(0xFFE4DEFF) : const Color(0xFF111722), borderRadius: BorderRadius.circular(22)),
    child: Text(text, style: TextStyle(color: selected ? Colors.black : Colors.white70, fontWeight: FontWeight.w600, fontSize: 12)),
  );
}
