import 'dart:math';
import 'package:flutter/material.dart';
import '../app_state.dart';
import '../data/local_wallpapers.dart';
import '../models/wallpaper.dart';
import '../utils/category_key.dart';
import '../widgets/wallpaper_card.dart';
import 'categories_screen.dart';
import 'category_wallpapers_screen.dart';
import 'collections_screen.dart';
import 'search_screen.dart';
import 'settings_screen.dart';
import 'wallpaper_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedFilter = 0;
  bool _categoryLoadRequested = false;
  static const filters = ['Tümü', 'Popüler', 'Yeni', 'Senin için'];


  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_categoryLoadRequested) return;
    _categoryLoadRequested = true;
    Future.microtask(() => AppScope.of(context).refreshCategories());
  }

  WallpaperItem get _dailyPick {
    final now = DateTime.now();
    final dayKey = DateTime(now.year, now.month, now.day)
        .difference(DateTime(2026))
        .inDays
        .abs();
    return wallpapers[dayKey % wallpapers.length];
  }

  List<WallpaperItem> _filtered(BuildContext context) {
    switch (selectedFilter) {
      case 1:
        const ids = {'n1', 'c1', 's1', 'a1', 'h1', 'v1'};
        return wallpapers.where((item) => ids.contains(item.id)).toList();
      case 2:
        return wallpapers.reversed.toList();
      case 3:
        final state = AppScope.of(context);
        final favoriteCategories = state.favorites.map((e) => e.category).toSet();
        final recommended = wallpapers.where((item) {
          return favoriteCategories.contains(item.category) &&
              !state.isFavorite(item.id);
        }).toList();
        final fallback = wallpapers
            .where((item) => !state.isFavorite(item.id))
            .take(6)
            .toList();
        return <WallpaperItem>[
          ...state.favorites,
          ...(recommended.isEmpty ? fallback : recommended),
        ].take(12).toList();
      default:
        return wallpapers;
    }
  }

  void _openWallpaper(BuildContext context, WallpaperItem item) {
    AppScope.of(context).markViewed(item.id);
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => WallpaperDetailScreen(item: item)),
    );
  }

  void _openSurprise(BuildContext context) {
    final currentRecent = AppScope.of(context).recent;
    final lastViewedId = currentRecent.isEmpty ? null : currentRecent.first.id;
    final candidates = wallpapers
        .where((item) => item.id != lastViewedId)
        .toList(growable: false);
    final pool = candidates.isEmpty ? wallpapers : candidates;
    final item = pool[Random().nextInt(pool.length)];
    _openWallpaper(context, item);
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final featured = _dailyPick;
    final visibleItems = _filtered(context);
    final recent = state.recent.take(6).toList();
    final lastApplied = state.lastApplied;
    final columns = state.compactGrid ? 3 : 2;

    return SafeArea(
      bottom: false,
      child: CustomScrollView(
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 18, 10, 10),
            sliver: SliverToBoxAdapter(
              child: Row(
                children: [
                  const Expanded(
                    child: Text(
                      'E L X V R O',
                      style: TextStyle(
                        fontSize: 20,
                        letterSpacing: 5,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: 'Koleksiyonlar',
                    onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const CollectionsScreen()),
                    ),
                    icon: const Icon(Icons.auto_awesome_mosaic_outlined),
                  ),
                  IconButton(
                    tooltip: 'Ara',
                    onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const SearchScreen()),
                    ),
                    icon: const Icon(Icons.search_rounded),
                  ),
                  IconButton(
                    tooltip: 'Ayarlar',
                    onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const SettingsScreen()),
                    ),
                    icon: const Icon(Icons.tune_rounded),
                  ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 44,
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 18),
                scrollDirection: Axis.horizontal,
                itemCount: filters.length + 1,
                itemBuilder: (_, index) {
                  if (index == filters.length) {
                    return _FilterChip(
                      text: 'Sürpriz',
                      selected: false,
                      icon: Icons.shuffle_rounded,
                      onTap: () => _openSurprise(context),
                    );
                  }
                  return _FilterChip(
                    text: filters[index],
                    selected: selectedFilter == index,
                    onTap: () => setState(() => selectedFilter = index),
                  );
                },
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 0),
            sliver: SliverToBoxAdapter(
              child: GestureDetector(
                onTap: () => _openWallpaper(context, featured),
                child: Container(
                  height: 225,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(28),
                    image: DecorationImage(
                      image: AssetImage(featured.asset),
                      fit: BoxFit.cover,
                    ),
                  ),
                  child: Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(28),
                      gradient: const LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.transparent, Color(0xDD05070C)],
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 9,
                                vertical: 5,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.black.withValues(alpha: .35),
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: const Text(
                                'GÜNÜN SEÇİMİ',
                                style: TextStyle(
                                  fontSize: 10,
                                  letterSpacing: 1.5,
                                  color: Colors.white70,
                                ),
                              ),
                            ),
                            const Spacer(),
                            Text(
                              featured.category,
                              style: const TextStyle(
                                fontSize: 11,
                                color: Colors.white70,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(
                          featured.title,
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 4),
                        const Text(
                          'Her gün otomatik değişir • İndirme yok',
                          style: TextStyle(fontSize: 12, color: Colors.white70),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
          if (lastApplied != null)
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 0),
              sliver: SliverToBoxAdapter(
                child: GestureDetector(
                  onTap: () => _openWallpaper(context, lastApplied),
                  child: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.surface,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.asset(
                            lastApplied.asset,
                            width: 42,
                            height: 58,
                            fit: BoxFit.cover,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Son uygulanan',
                                style: TextStyle(
                                  fontSize: 10,
                                  color: Colors.white54,
                                ),
                              ),
                              const SizedBox(height: 3),
                              Text(
                                lastApplied.title,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right_rounded),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          if (recent.isNotEmpty) ...[
            const SliverPadding(
              padding: EdgeInsets.fromLTRB(18, 22, 18, 10),
              sliver: SliverToBoxAdapter(
                child: Text(
                  'Devam Et',
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.w700),
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: SizedBox(
                height: 145,
                child: ListView.separated(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  scrollDirection: Axis.horizontal,
                  itemCount: recent.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 10),
                  itemBuilder: (_, index) {
                    final item = recent[index];
                    return GestureDetector(
                      onTap: () => _openWallpaper(context, item),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(18),
                        child: SizedBox(
                          width: 92,
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              Image.asset(item.asset, fit: BoxFit.cover),
                              const DecoratedBox(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [Colors.transparent, Color(0xB0000000)],
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 8,
                                right: 8,
                                bottom: 8,
                                child: Text(
                                  item.title,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ],
          SliverPadding(
            padding: EdgeInsets.fromLTRB(18, recent.isEmpty ? 22 : 24, 18, 12),
            sliver: SliverToBoxAdapter(
              child: Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Kategoriler',
                      style: TextStyle(fontSize: 19, fontWeight: FontWeight.w700),
                    ),
                  ),
                  TextButton(
                    onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const CategoriesScreen()),
                    ),
                    child: const Text('Tümünü Gör'),
                  ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 92,
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 18),
                scrollDirection: Axis.horizontal,
                itemBuilder: (context, index) {
                  final category = state.categories[index];
                  final categoryItems = wallpapers
                      .where((w) => categoryKey(w.category) == category.slug ||
                          categoryKey(w.category) == categoryKey(category.name))
                      .toList(growable: false);
                  final cover =
                      categoryItems.isEmpty ? null : categoryItems.first.asset;
                  return GestureDetector(
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => CategoryWallpapersScreen(
                          categoryName: category.name,
                          categorySlug: category.slug,
                        ),
                      ),
                    ),
                    child: Container(
                      width: 118,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(18),
                        color: const Color(0xFF131722),
                        image: cover == null
                            ? null
                            : DecorationImage(
                                image: AssetImage(cover),
                                fit: BoxFit.cover,
                              ),
                      ),
                      child: Container(
                        alignment: Alignment.bottomLeft,
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(18),
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: cover == null
                                ? const [
                                    Color(0xFF181D29),
                                    Color(0xFF090B11),
                                  ]
                                : const [
                                    Colors.transparent,
                                    Color(0xC0000000),
                                  ],
                          ),
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (cover == null)
                              const Padding(
                                padding: EdgeInsets.only(bottom: 5),
                                child: Icon(
                                  Icons.photo_library_outlined,
                                  size: 15,
                                  color: Colors.white38,
                                ),
                              ),
                            Text(
                              category.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontWeight: FontWeight.w700),
                            ),
                            Text(
                              '${categoryItems.length} yerel',
                              style: const TextStyle(
                                fontSize: 9,
                                color: Colors.white60,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
                separatorBuilder: (_, __) => const SizedBox(width: 10),
                itemCount: state.categories.length,
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 24, 18, 12),
            sliver: SliverToBoxAdapter(
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      filters[selectedFilter] == 'Tümü'
                          ? 'Öne Çıkanlar'
                          : filters[selectedFilter],
                      style: const TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  Text(
                    '${visibleItems.length}',
                    style: const TextStyle(color: Colors.white38),
                  ),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 0, 18, 28),
            sliver: SliverGrid.builder(
              itemCount: visibleItems.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: columns,
                childAspectRatio: .62,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
              ),
              itemBuilder: (context, index) =>
                  WallpaperCard(item: visibleItems[index]),
            ),
          ),
        ],
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String text;
  final bool selected;
  final VoidCallback onTap;
  final IconData? icon;

  const _FilterChip({
    required this.text,
    required this.selected,
    required this.onTap,
    this.icon,
  });

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          margin: const EdgeInsets.only(right: 8),
          padding: const EdgeInsets.symmetric(horizontal: 15),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: selected
                ? Theme.of(context).colorScheme.primaryContainer
                : Theme.of(context).colorScheme.surface,
            borderRadius: BorderRadius.circular(22),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (icon != null) ...[
                Icon(icon, size: 15),
                const SizedBox(width: 5),
              ],
              Text(
                text,
                style: TextStyle(
                  color: selected
                      ? Theme.of(context).colorScheme.onPrimaryContainer
                      : Colors.white70,
                  fontWeight: FontWeight.w600,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
      );
}
