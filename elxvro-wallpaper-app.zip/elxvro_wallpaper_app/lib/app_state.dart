import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'data/demo_wallpapers.dart';
import 'models/wallpaper.dart';

class AppState extends ChangeNotifier {
  static const _channel = MethodChannel('com.elxvro.wallpaper/channel');

  final Set<String> _favorites = {'n1', 'c1', 's1'};
  final List<String> _recentIds = <String>[];

  AppState() {
    _restoreLocalState();
  }

  bool isFavorite(String id) => _favorites.contains(id);

  void toggleFavorite(String id) {
    if (!_favorites.add(id)) {
      _favorites.remove(id);
    }
    notifyListeners();
    _saveLocalState();
  }

  void markViewed(String id) {
    _recentIds.remove(id);
    _recentIds.insert(0, id);
    if (_recentIds.length > 20) {
      _recentIds.removeRange(20, _recentIds.length);
    }
    notifyListeners();
    _saveLocalState();
  }

  void clearRecent() {
    _recentIds.clear();
    notifyListeners();
    _saveLocalState();
  }

  List<WallpaperItem> get favorites =>
      wallpapers.where((item) => _favorites.contains(item.id)).toList();

  List<WallpaperItem> get recent => _recentIds
      .map((id) => wallpapers.where((item) => item.id == id).firstOrNull)
      .whereType<WallpaperItem>()
      .toList();

  Future<void> _restoreLocalState() async {
    try {
      final saved = await _channel.invokeMapMethod<String, dynamic>('loadState');
      if (saved == null || saved['hasState'] != true) return;

      final favoriteIds = (saved['favorites'] as List<dynamic>? ?? const [])
          .whereType<String>()
          .where(_knownWallpaperId)
          .toSet();
      final recentIds = (saved['recent'] as List<dynamic>? ?? const [])
          .whereType<String>()
          .where(_knownWallpaperId)
          .take(20)
          .toList();

      _favorites
        ..clear()
        ..addAll(favoriteIds);
      _recentIds
        ..clear()
        ..addAll(recentIds);
      notifyListeners();
    } on MissingPluginException {
      // Widget testleri veya Android dışı ortamlarda yerel kayıt kullanılamaz.
    } on PlatformException {
      // Yerel kayıt okunamazsa uygulama varsayılan durumla çalışmaya devam eder.
    }
  }

  Future<void> _saveLocalState() async {
    try {
      await _channel.invokeMethod<void>('saveState', {
        'favorites': _favorites.toList(growable: false),
        'recent': _recentIds.toList(growable: false),
      });
    } on MissingPluginException {
      // Widget testleri veya Android dışı ortamlarda sessizce atla.
    } on PlatformException {
      // Kayıt hatası ana uygulama akışını engellememeli.
    }
  }

  bool _knownWallpaperId(String id) => wallpapers.any((item) => item.id == id);
}

extension _FirstOrNullExtension<T> on Iterable<T> {
  T? get firstOrNull {
    final iterator = this.iterator;
    if (!iterator.moveNext()) return null;
    return iterator.current;
  }
}

class AppScope extends InheritedNotifier<AppState> {
  const AppScope({
    super.key,
    required AppState notifier,
    required super.child,
  }) : super(notifier: notifier);

  static AppState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope bulunamadı');
    return scope!.notifier!;
  }
}
