import 'package:flutter/material.dart';
import 'data/demo_wallpapers.dart';
import 'models/wallpaper.dart';

class AppState extends ChangeNotifier {
  final Set<String> _favorites = {'n1', 'c1', 's1'};

  bool isFavorite(String id) => _favorites.contains(id);

  void toggleFavorite(String id) {
    if (!_favorites.add(id)) _favorites.remove(id);
    notifyListeners();
  }

  List<WallpaperItem> get favorites =>
      wallpapers.where((item) => _favorites.contains(item.id)).toList();
}

class AppScope extends InheritedNotifier<AppState> {
  const AppScope({super.key, required AppState notifier, required super.child})
      : super(notifier: notifier);

  static AppState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope bulunamadı');
    return scope!.notifier!;
  }
}
