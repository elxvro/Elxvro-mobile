import 'package:flutter/material.dart';
import 'data/demo_wallpapers.dart';
import 'models/wallpaper.dart';

class AppState extends ChangeNotifier {
  final Set<String> _favorites = {'n1', 'c1', 's1'};
  final List<String> _recentIds = <String>[];

  bool isFavorite(String id) => _favorites.contains(id);

  void toggleFavorite(String id) {
    if (!_favorites.add(id)) {
      _favorites.remove(id);
    }
    notifyListeners();
  }

  void markViewed(String id) {
    _recentIds.remove(id);
    _recentIds.insert(0, id);
    if (_recentIds.length > 20) {
      _recentIds.removeRange(20, _recentIds.length);
    }
    notifyListeners();
  }

  void clearRecent() {
    _recentIds.clear();
    notifyListeners();
  }

  List<WallpaperItem> get favorites =>
      wallpapers.where((item) => _favorites.contains(item.id)).toList();

  List<WallpaperItem> get recent => _recentIds
      .map((id) => wallpapers.where((item) => item.id == id).firstOrNull)
      .whereType<WallpaperItem>()
      .toList();
}

extension _FirstOrNullExtension<T> on Iterable<T> {
  T? get firstOrNull {
    final iterator = this.iterator;
    if (!iterator.moveNext()) return null;
    return iterator.current;
  }
}

class AppScope extends InheritedNotifier<AppState> {
  const AppScope({
    super.key,
    required AppState notifier,
    required super.child,
  }) : super(notifier: notifier);

  static AppState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope bulunamadı');
    return scope!.notifier!;
  }
}
