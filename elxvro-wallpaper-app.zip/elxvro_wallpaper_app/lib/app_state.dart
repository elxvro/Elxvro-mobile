import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'data/demo_wallpapers.dart';
import 'models/wallpaper.dart';

class AppState extends ChangeNotifier {
  static const _channel = MethodChannel('com.elxvro.wallpaper/channel');

  final Set<String> _favorites = {'n1', 'c1', 's1'};
  final List<String> _recentIds = <String>[];
  final List<String> _appliedIds = <String>[];

  String _defaultTarget = 'ask';
  String _accent = 'violet';
  bool _oledMode = false;
  bool _compactGrid = false;
  bool _showCardTitles = true;

  AppState() {
    _restoreLocalState();
  }

  bool isFavorite(String id) => _favorites.contains(id);
  bool wasApplied(String id) => _appliedIds.contains(id);

  String get defaultTarget => _defaultTarget;
  String get accent => _accent;
  bool get oledMode => _oledMode;
  bool get compactGrid => _compactGrid;
  bool get showCardTitles => _showCardTitles;

  Color get accentColor {
    switch (_accent) {
      case 'cyan':
        return const Color(0xFF48C7FF);
      case 'pink':
        return const Color(0xFFFF5E9B);
      case 'violet':
      default:
        return const Color(0xFF8B6CFF);
    }
  }

  void toggleFavorite(String id) {
    if (!_favorites.add(id)) {
      _favorites.remove(id);
    }
    notifyListeners();
    _saveLocalState();
  }

  void markViewed(String id) {
    _recentIds.remove(id);
    _recentIds.insert(0, id);
    if (_recentIds.length > 20) {
      _recentIds.removeRange(20, _recentIds.length);
    }
    notifyListeners();
    _saveLocalState();
  }

  void markApplied(String id) {
    _appliedIds.remove(id);
    _appliedIds.insert(0, id);
    if (_appliedIds.length > 20) {
      _appliedIds.removeRange(20, _appliedIds.length);
    }
    notifyListeners();
    _saveLocalState();
  }

  void clearRecent() {
    _recentIds.clear();
    notifyListeners();
    _saveLocalState();
  }

  void clearApplied() {
    _appliedIds.clear();
    notifyListeners();
    _saveLocalState();
  }

  void setDefaultTarget(String value) {
    if (!const {'ask', 'home', 'lock', 'both'}.contains(value)) return;
    if (_defaultTarget == value) return;
    _defaultTarget = value;
    notifyListeners();
    _saveLocalState();
  }

  void setAccent(String value) {
    if (!const {'violet', 'cyan', 'pink'}.contains(value)) return;
    if (_accent == value) return;
    _accent = value;
    notifyListeners();
    _saveLocalState();
  }

  void setOledMode(bool value) {
    if (_oledMode == value) return;
    _oledMode = value;
    notifyListeners();
    _saveLocalState();
  }

  void setCompactGrid(bool value) {
    if (_compactGrid == value) return;
    _compactGrid = value;
    notifyListeners();
    _saveLocalState();
  }

  void setShowCardTitles(bool value) {
    if (_showCardTitles == value) return;
    _showCardTitles = value;
    notifyListeners();
    _saveLocalState();
  }

  List<WallpaperItem> get favorites =>
      wallpapers.where((item) => _favorites.contains(item.id)).toList();

  List<WallpaperItem> get recent => _itemsFromIds(_recentIds);
  List<WallpaperItem> get applied => _itemsFromIds(_appliedIds);

  WallpaperItem? get lastApplied => applied.isEmpty ? null : applied.first;

  List<WallpaperItem> _itemsFromIds(List<String> ids) => ids
      .map((id) => wallpapers.where((item) => item.id == id).firstOrNull)
      .whereType<WallpaperItem>()
      .toList();

  Future<void> _restoreLocalState() async {
    try {
      final saved = await _channel.invokeMapMethod<String, dynamic>('loadState');
      if (saved == null || saved['hasState'] != true) return;

      final favoriteIds = (saved['favorites'] as List<dynamic>? ?? const [])
          .whereType<String>()
          .where(_knownWallpaperId)
          .toSet();
      final recentIds = (saved['recent'] as List<dynamic>? ?? const [])
          .whereType<String>()
          .where(_knownWallpaperId)
          .take(20)
          .toList();
      final appliedIds = (saved['applied'] as List<dynamic>? ?? const [])
          .whereType<String>()
          .where(_knownWallpaperId)
          .take(20)
          .toList();

      _favorites
        ..clear()
        ..addAll(favoriteIds);
      _recentIds
        ..clear()
        ..addAll(recentIds);
      _appliedIds
        ..clear()
        ..addAll(appliedIds);

      final defaultTarget = saved['defaultTarget'];
      if (defaultTarget is String &&
          const {'ask', 'home', 'lock', 'both'}.contains(defaultTarget)) {
        _defaultTarget = defaultTarget;
      }

      final accent = saved['accent'];
      if (accent is String && const {'violet', 'cyan', 'pink'}.contains(accent)) {
        _accent = accent;
      }

      _oledMode = saved['oledMode'] == true;
      _compactGrid = saved['compactGrid'] == true;
      if (saved['showCardTitles'] is bool) {
        _showCardTitles = saved['showCardTitles'] as bool;
      }

      notifyListeners();
    } on MissingPluginException {
      // Widget testleri veya Android dışı ortamlarda yerel kayıt kullanılamaz.
    } on PlatformException {
      // Yerel kayıt okunamazsa uygulama varsayılan durumla çalışmaya devam eder.
    }
  }

  Future<void> _saveLocalState() async {
    try {
      await _channel.invokeMethod<void>('saveState', {
        'favorites': _favorites.toList(growable: false),
        'recent': _recentIds.toList(growable: false),
        'applied': _appliedIds.toList(growable: false),
        'defaultTarget': _defaultTarget,
        'accent': _accent,
        'oledMode': _oledMode,
        'compactGrid': _compactGrid,
        'showCardTitles': _showCardTitles,
      });
    } on MissingPluginException {
      // Widget testleri veya Android dışı ortamlarda sessizce atla.
    } on PlatformException {
      // Kayıt hatası ana uygulama akışını engellememeli.
    }
  }

  bool _knownWallpaperId(String id) => wallpapers.any((item) => item.id == id);
}

extension _FirstOrNullExtension<T> on Iterable<T> {
  T? get firstOrNull {
    final iterator = this.iterator;
    if (!iterator.moveNext()) return null;
    return iterator.current;
  }
}

class AppScope extends InheritedNotifier<AppState> {
  const AppScope({
    super.key,
    required AppState notifier,
    required super.child,
  }) : super(notifier: notifier);

  static AppState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope bulunamadı');
    return scope!.notifier!;
  }
}
