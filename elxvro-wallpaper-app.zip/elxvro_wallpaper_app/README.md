# ELXVRO Wallpaper — Flutter Android

Bu paket, hazırlanan ELXVRO görsel konseptinin çalışan ilk Android sürümüdür.

## Özellikler
- İndirme butonu yok.
- Duvar kağıdını doğrudan Ana Ekran / Kilit Ekranı / İkisi Birden olarak ayarlar.
- Android `WallpaperManager` doğrudan Kotlin üzerinden kullanılır; wallpaper için üçüncü parti paket yoktur.
- Uygulama tarafında görsel önizleme `BoxFit.cover`, Android tarafında da merkezden crop uygulanır; önizleme ile gerçek duvar kağıdı görünümü mümkün olduğunca yakın tutulur.
- Keşfet, Kategoriler, Kategori grid'i, Favoriler, Profil ve başarı ekranı vardır.
- 14 adet yerel demo wallpaper içerir; internetsiz açılır.

## Çalıştırma
```bash
flutter pub get
flutter run
```

## APK
```bash
flutter build apk --release
```
Çıktı: `build/app/outputs/flutter-apk/app-release.apk`

## GitHub Actions
`.github/workflows/elxvro-apk.yml` dosyası hazırdır. Projeyi GitHub'a yükleyip `main` dalına push yapınca APK artifact olarak üretilir.

## Önemli
Release yapılandırması şu an test kolaylığı için debug signing kullanır. Google Play yayını öncesi kendi release keystore'unu bağla.

## Wallpaper değiştirme
Yeni görseli `assets/wallpapers/` altına koy ve `lib/data/demo_wallpapers.dart` içine ekle. `pubspec.yaml` klasörün tamamını zaten asset olarak tanımlar.
