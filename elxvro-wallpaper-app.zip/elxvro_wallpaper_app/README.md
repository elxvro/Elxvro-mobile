# ELXVRO Wallpaper App v1.0.11

Android için Flutter tabanlı ELXVRO duvar kağıdı uygulaması.

## v1.0.11 - Local Media System
- Duvar kağıdı görselleri yalnızca uygulamanın `assets/wallpapers/` klasöründen okunur.
- Wallpaper ekranlarında `Image.network` / uzak görsel URL'si kullanılmaz.
- Kategori isimleri `https://elxvro.com/api/v1/categories.php` adresinden alınır.
- Kategori cevabı cihazda 24 saat önbelleğe alınır; uygulama her ekranda siteye tekrar tekrar istek atmaz.
- Kullanıcı isterse Kategoriler ekranından aşağı çekerek veya yenile butonuyla kategori listesini elle güncelleyebilir.
- Site geçici olarak kapalıysa son başarılı kategori önbelleği kullanılır.
- Daha önce hiç önbellek oluşmamışsa yerel yedek kategori listesi kullanılır.
- Sitedeki wallpaper görselleri uygulama tarafından çekilmez.
- Google profil, gizlilik/kullanım koşulları ve hesap silme özellikleri korunur.
- Görsel indirme özelliği yoktur.

## Yerel görsel ekleme
Ayrıntılı adımlar için `YEREL_GORSEL_SISTEMI.md` dosyasına bakın.

## Google giriş
Android OAuth kaydında paket adı `com.elxvro.wallpaper` olmalıdır ve APK/AAB imzasının SHA-1 değeri Google tarafında kayıtlı olmalıdır. Ayrıntı için `GOOGLE_GIRIS_KURULUMU.md` dosyasına bakın.

## Build
Mevcut `.github/workflows/build-apk.yml` değiştirilmemiştir.
