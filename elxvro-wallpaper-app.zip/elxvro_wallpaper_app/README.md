# ELXVRO Wallpaper v1.0.7

ELXVRO, Android için Flutter ile hazırlanmış indirmesiz duvar kağıdı uygulamasıdır. Görseller uygulama içinden önizlenir ve Android `WallpaperManager` üzerinden doğrudan ana ekran, kilit ekranı veya ikisine birden uygulanır.

## v1.0.7 özellikleri

- İndirme/kaydetme butonu yok.
- Ana ekran, kilit ekranı veya ikisine birden doğrudan uygulama.
- Varsayılan hedef seçimi: her seferinde sor / ana ekran / kilit ekranı / ikisi.
- Günün seçimi her gün otomatik değişir.
- Akıllı koleksiyonlar: Favoriler, Uyguladıklarım, Son Baktıklarım, Gece & Neon, Minimal.
- Uygulanan duvar kağıtları cihazda yerel geçmişe kaydedilir.
- Favoriler ve son görüntülenenler kalıcıdır.
- Gelişmiş arama: kategori, hızlı etiketler, favoriler ve sıralama filtreleri.
- Kategori içinde A-Z / favoriler önce / yeni sıra ve rastgele açma.
- Tam ekran önizleme, sağa-sola kaydırma ve komşu görselleri ön yükleme.
- Benzer duvar kağıtları paneli.
- OLED siyah modu.
- Mor / mavi / pembe vurgu rengi.
- Kompakt 3 sütunlu galeri seçeneği.
- Kart başlıklarını aç/kapat.
- Profil kullanım istatistikleri ve son uygulanan kartı.
- Tüm tercihler native SharedPreferences ile cihazda saklanır; ek Flutter depolama paketi kullanılmaz.

## GitHub Actions

Projede bulunan `.github/workflows/build-apk.yml` daha önce çalışan sabit akıştır. v1.0.7 için değiştirilmemiştir.

Repository ana dizininde ZIP dosyasını `elxvro-wallpaper-app.zip` adıyla tutun. Workflow ZIP'i açar, temiz Android Flutter projesi oluşturur, kaynakları aktarır, analiz eder ve APK/AAB üretir.
