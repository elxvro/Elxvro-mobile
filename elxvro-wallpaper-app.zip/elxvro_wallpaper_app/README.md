# ELXVRO Wallpaper App v1.0.9

Android için Flutter tabanlı ELXVRO duvar kağıdı uygulaması.

## Bu sürüm
- Profil yalnızca Google ile giriş yapınca açılır.
- Google adı, e-posta ve profil fotoğrafı gösterilir.
- Favoriler, uygulananlar, son görüntülenenler ve koleksiyonlar profil içinde erişilebilir.
- Yerel kullanıcı verileri ayrı ayrı temizlenebilir.
- Google hesabından çıkış yapılabilir.
- ELXVRO hesabını sil işlemi Google bağlantısını kaldırır ve cihazdaki ELXVRO kullanıcı verilerini temizler.
- Google hesabının kendisi silinmez.
- Wallpaper düzenleyici v1.0.8 özellikleri korunur.
- Görsel indirme özelliği yoktur.

## Google giriş
Android OAuth kaydında paket adı `com.elxvro.wallpaper` olmalıdır ve APK/AAB imzasının SHA-1 değeri Google tarafında kayıtlı olmalıdır. Ayrıntı için `GOOGLE_GIRIS_KURULUMU.md` dosyasına bakın.

## Build
Mevcut `.github/workflows/build-apk.yml` değiştirilmemiştir.
