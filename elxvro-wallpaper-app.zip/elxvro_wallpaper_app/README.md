# ELXVRO Wallpaper v1.0.8

ELXVRO, görselleri dosya olarak indirtmeden Android ana ekranına veya kilit ekranına duvar kağıdı olarak uygulayan Flutter uygulamasıdır.

## v1.0.8 — Düzenleme & Görünüm

Bu sürümde uygulama içi wallpaper editörü eklendi:

- Yakınlaştırma ve sürükleyerek konumlandırma
- Ekranı doldur / görselin tamamını göster kırpma seçenekleri
- Parlaklık, kontrast ve doygunluk
- Blur ayarı
- Normal, Canlı, Siyah-Beyaz, Sıcak ve Soğuk filtreler
- Tek dokunuşla tüm düzenlemeleri sıfırlama
- Önce / Sonra karşılaştırması
- Ana ekran ve kilit ekranı telefon önizlemeleri
- Tam ekran düzenleme önizlemesi; çift dokunarak kontrolleri gizleme
- Düzenlenmiş kompozisyonu doğrudan wallpaper olarak uygulama
- Düzenlenen görsel cihaz depolamasına kaydedilmez ve indirme butonu yoktur
- Detay ekranına modern Düzenle akışı ve yumuşak geçiş animasyonu

## Derleme

Repository ana dizininde uygulama ZIP dosyasını `elxvro-wallpaper-app.zip` adıyla tut.

Projede bulunan `.github/workflows/build-apk.yml` daha önce çalışan sabit akıştır. v1.0.8 için değiştirilmemiştir.

GitHub Actions çıktıları:

- `ELXVRO-APK` → `ELXVRO.apk`
- `ELXVRO-AAB` → `ELXVRO.aab`
