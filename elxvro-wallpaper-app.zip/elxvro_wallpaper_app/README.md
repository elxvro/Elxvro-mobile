# ELXVRO Wallpaper App v1.0.13

Flutter Android duvar kağıdı uygulaması. Kullanıcıya görsel indirme/galeriye kaydetme özelliği sunmaz; görseller önizlenir, düzenlenir ve doğrudan duvar kağıdı olarak uygulanır.

## v1.0.12 - Local Mirror Sync

- Kategoriler mevcut ELXVRO site API'sinden gelir ve 24 saat cihazda cache edilir.
- Mobil wallpaper manifesti `https://elxvro.com/app-api/v1/media-manifest.php` adresinden alınır.
- Uygulama yalnızca yeni/değişen `ELX-M-*` dosyalarını Android'in uygulamaya özel depolama alanına kopyalar.
- Keşfet, kategori, arama, önizleme, düzenleyici ve wallpaper uygulama işlemleri hosting URL'sini kullanmaz; cihazdaki kopyayı kullanır.
- Otomatik manifest kontrolü 24 saatte en fazla bir kez yapılır. Başarısız deneme de bu aralığa dahildir; site kapalıyken her uygulama açılışında tekrar istek atılmaz.
- Ayarlar > Yerel medya > Görselleri eşitle ile manuel kontrol yapılabilir.
- Hosting kapalıysa mevcut yerel kopyalar çalışmaya devam eder.
- İlk kurulumda henüz eşitlenmiş medya yoksa APK içindeki demo görseller yalnızca fallback olarak kullanılır.
- Google profil, Gizlilik Politikası, Kullanım Koşulları, hesap silme, favoriler, geçmiş, koleksiyonlar ve wallpaper düzenleyici korunur.

## Dosya adlandırma

Hostingdeki mobil görseller `ELX-M-` ile başlamalıdır:

- `ELX-M-0001.webp`
- `ELX-M-0002.webp`

WebP önerilir. JPG/JPEG/PNG de manifest tarafından kabul edilir.

## GitHub

Çalışan `.github/workflows/build-apk.yml` değiştirilmemiştir. Repository ana dizinindeki ZIP dosyasını `elxvro-wallpaper-app.zip` adıyla kullanabilirsiniz.


## v1.0.13 Sync Manager

Ayarlar > Yerel medya > Sync Manager ekranı, Local Mirror durumunu ve eşitleme ilerlemesini gösterir. Uygulama sadece yeni/değişen medya dosyalarını indirir; mevcut dosyaları tekrar indirmez. Tek dosya hatası toplu eşitlemeyi durdurmaz. Güvenli temizlik sadece katalogda kullanılmayan yerel dosyalara uygulanır.
