# ELXVRO Wallpaper App v1.0.20

Flutter Android duvar kağıdı uygulaması. Kullanıcıya görseli Galeri/İndirilenler klasörüne kaydetme özelliği sunmaz; görseller keşfedilir, önizlenir, düzenlenir ve Android duvar kağıdı olarak uygulanır.

## Güncel medya akışı

- Uygulama mobil wallpaper listesini `https://elxvro.com/app-api/v1/media-manifest.php` üzerinden alır.
- Galeri kartlarında küçük `_thumb.webp` önizlemeler kullanılır; tam boyutlu dosya galeri açılışını yavaşlatmaz.
- Bir görsel detayda açıldığında gerekirse orijinal dosya Android uygulama-private depolamaya alınır.
- Yerel kopya hazır olduğunda önizleme, düzenleme ve duvar kağıdı uygulama işlemleri bu kopyayı kullanabilir.
- Hosting erişilemiyorsa daha önce yerelleştirilmiş görseller çevrimdışı kullanılmaya devam eder.
- Ayarlar > Yerel medya > Sync Manager üzerinden tüm koleksiyon isteğe bağlı olarak çevrimdışı hazırlanabilir.

## Arayüz v1.0.20

- Ana uygulama yüzeyi açık, yumuşak beyaz bir tasarıma sahiptir.
- Görselleri öne çıkarmak için nötr arka plan, beyaz kartlar ve düşük kontrastlı sınırlar kullanılır.
- Görsel detay ve düzenleyici ekranları fotoğraf odaklı koyu arayüz olarak korunur.
- Keşfet ekranında arama, Günün Seçimi, Hızlı Keşfet, kategoriler ve dinamik galeri bulunur.
- Wallpaper isimleri galeri kartlarında gösterilmez; yalnızca detay ekranında görünür.


## Google + MySQL hesap sistemi

- Profil girişi yalnızca Google hesabıyla yapılır; ayrı ELXVRO parolası yoktur.
- Android uygulaması Google ID token alır ve `https://elxvro.com/app-api/v1/auth/google-login.php` adresine gönderir.
- Sunucu tokenı Google ile doğruladıktan sonra hesap kimliği, e-posta, görünen ad, profil fotoğrafı URL'si, yasal onay sürümü ve giriş zamanlarını `elxvro_app_users` MySQL tablosunda saklar.
- Google parolası ELXVRO uygulamasına veya MySQL veritabanına ulaşmaz.
- “ELXVRO hesabını sil” işlemi MySQL hesap kaydını ve cihazdaki kullanıcı verilerini siler; Google hesabını silmez.
- Favoriler, geçmiş, uygulananlar ve uygulama tercihleri bu sürümde cihaz üzerinde yerel kalır.

## Dosya adlandırma

Hostingdeki mobil orijinal görseller `ELX-M-` ile başlamalıdır. Örnek:

- `ELX-M-0001.webp`
- `ELX-M-0002.webp`

WebP önerilir.

## GitHub

Çalışan `.github/workflows/build-apk.yml` değiştirilmemiştir. Repository ana dizinindeki proje ZIP'i `elxvro-wallpaper-app.zip` adıyla kullanılabilir.
