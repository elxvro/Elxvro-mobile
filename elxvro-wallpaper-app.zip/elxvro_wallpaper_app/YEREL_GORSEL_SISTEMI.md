# ELXVRO Yerel Görsel Sistemi

## Temel kural
Wallpaper dosyaları internetten veya ELXVRO sitesinden indirilmez. Uygulama yalnızca APK/AAB içine eklenmiş `assets/wallpapers/` dosyalarını gösterir.

## Yeni wallpaper ekleme
1. Görseli `assets/wallpapers/` klasörüne koyun.
2. Önerilen dosya adı: `ELX-M-0001.webp`, `ELX-M-0002.webp` ...
3. `lib/data/local_wallpapers.dart` dosyasındaki `wallpapers` listesine yeni kayıt ekleyin.

Örnek:

```dart
WallpaperItem(
  id: 'ELX-M-0001',
  title: 'Gece Şehri',
  category: 'Şehir',
  asset: 'assets/wallpapers/ELX-M-0001.webp',
  tags: ['Şehir', 'Gece', 'Neon'],
),
```

`category` alanı sitedeki kategori adıyla aynı olmalıdır. Türkçe karakterler eşleştirmede normalize edilir; örneğin `Doğa` -> `doga`, `Şehir` -> `sehir`, `Araçlar` -> `araclar`.

## Kategoriler nasıl çalışır?
- Uygulama kategori listesini yalnızca `https://elxvro.com/api/v1/categories.php` üzerinden alır.
- Başarılı cevap 24 saat cihazda saklanır.
- 24 saat dolmadan tekrar siteye kategori isteği gönderilmez.
- Kategoriler ekranındaki manuel yenileme bu süreyi beklemeden tek bir kategori isteği gönderir.
- API çalışmazsa önbellekteki kategori listesi kullanılmaya devam eder.

## Önemli
Kategori API'sindeki bir kategori için APK içinde wallpaper yoksa kategori yine görünür ancak `0 yerel duvar kağıdı` yazar. Böylece site kategorileri ile uygulamadaki yerel içerik birbirinden bağımsız kalır.
