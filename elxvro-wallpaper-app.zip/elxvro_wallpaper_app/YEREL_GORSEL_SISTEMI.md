# ELXVRO Yerel Görsel Sistemi v1.0.16

## Instant Gallery + Local Mirror

- Manifest: `https://elxvro.com/app-api/v1/media-manifest.php`
- Galeri önizleme kaynağı: `https://elxvro.com/app-media/thumbs/<kategori>/<dosya>_thumb.webp`
- Orijinal medya: `https://elxvro.com/app-media/mobile/<kategori>/<dosya>.webp`
- Orijinaller yalnızca ihtiyaç olduğunda veya kullanıcı Sync Manager'dan tam çevrimdışı eşitleme istediğinde uygulama-private depolamaya alınır.
- Uygulama-private kopyalar Galeri/Downloads içine yazılmaz.
- Uygulama kaldırılırsa Android bu özel dosyaları da kaldırır.
- Manifest `signature` değeri değiştiğinde eski yerel kopya geçersiz kabul edilir.
- `_thumb` dosyaları orijinal Local Mirror katalog girdisi olarak kabul edilmez.
