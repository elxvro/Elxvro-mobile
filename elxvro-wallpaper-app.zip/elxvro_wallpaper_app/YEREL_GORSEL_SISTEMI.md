# ELXVRO Yerel Görsel Sistemi v1.0.12

Bu sürümde wallpaper dosyaları normal kullanım sırasında siteden görüntülenmez.

## Sistem

1. Hostingde `app-media/mobile/<kategori>/ELX-M-*.webp` dosyaları bulunur.
2. `app-api/v1/media-manifest.php` yalnızca hafif bir dosya listesi ve değişiklik imzası döndürür.
3. Uygulama 24 saatte en fazla bir kez manifesti kontrol eder.
4. Yeni veya değişmiş görsel varsa dosyayı Android'in yalnızca ELXVRO'ya ait özel klasörüne kopyalar.
5. Bundan sonra tüm ekranlar `FileImage` ile bu yerel kopyayı kullanır.
6. Aynı dosya değişmediyse yeniden indirilmez.
7. Site/API kapalıysa yerel kopyalar çalışır.

## İlk kurulum fallback'i

APK içindeki `assets/wallpapers/` görselleri yalnızca cihazda henüz eşitlenmiş bir katalog yoksa kullanılır. Hosting eşitlemesi tamamlandığında aktif katalog cihazdaki kopyalara geçer.

## Manuel eşitleme

Ayarlar > Yerel medya > Görselleri eşitle.

Bu düğme 24 saat beklemeden manifest kontrolü yapar. Normal otomatik akışta ise uygulama siteyi sürekli sorgulamaz.
