# Google Giriş Kurulumu

Uygulama `google_sign_in 6.3.0` kullanır. Android tarafında `google-services.json` zorunlu değildir.

Google Cloud / Firebase tarafında Android OAuth istemcisi oluştururken:

- Paket adı: `com.elxvro.wallpaper`
- GitHub Actions ile üretilen APK'nın imza SHA-1 değeri kayıtlı olmalıdır.
- OAuth onay ekranının gerekli alanları doldurulmalıdır.

Bu sürüm yalnızca temel Google kimliği (`email/profile`) için giriş yapar; Google Drive veya People gibi ek izin istemez.


## v1.0.20 MySQL hesap + Google Drive

Uygulama Google ID token almak için Web OAuth Client ID'yi `serverClientId` olarak kullanır.
Google ile girişten sonra token `https://elxvro.com/app-api/v1/auth/google-login.php` adresine gönderilir. Sunucu token'i Google ile doğrular ve `elxvro_app_users` MySQL tablosuna hesap kaydını ekler/günceller.

Hosting tarafında önce `https://elxvro.com/app-api/v1/auth/health.php` adresinin `ok:true` döndürdüğünü doğrulayın.

Google parolası hiçbir zaman uygulamaya veya ELXVRO MySQL veritabanına yazılmaz.


## Google Drive yedekleme
- Google Cloud projesinde **Google Drive API** etkin olmalıdır.
- Uygulama yalnızca `drive.file` kapsamını ister; ELXVRO kendi oluşturduğu yedek dosyasını yönetir.
- Yedek dosyası adı: `ELXVRO Backup.json`.
