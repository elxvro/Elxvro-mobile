# Google Giriş Kurulumu

Uygulama `google_sign_in 6.3.0` kullanır. Android tarafında `google-services.json` zorunlu değildir.

Google Cloud / Firebase tarafında Android OAuth istemcisi oluştururken:

- Paket adı: `com.elxvro.wallpaper`
- GitHub Actions ile üretilen APK'nın imza SHA-1 değeri kayıtlı olmalıdır.
- OAuth onay ekranının gerekli alanları doldurulmalıdır.

Bu sürüm yalnızca temel Google kimliği (`email/profile`) için giriş yapar; Google Drive veya People gibi ek izin istemez.
