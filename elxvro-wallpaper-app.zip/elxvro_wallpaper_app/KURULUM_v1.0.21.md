# ELXVRO v1.0.21 kurulum

1. `elxvro-wallpaper-app-v1.0.21.zip` dosyasını GitHub depo köküne `elxvro-wallpaper-app.zip` adıyla yükle.
2. Mevcut `.github/workflows/build-apk.yml` dosyasını değiştirme.
3. GitHub Actions ile APK/AAB derlemesini çalıştır.
4. Bu sürüm sunucu koruması için istekleri sınırlar, thumbnail dosyalarını uygulama özel alanında kalıcı önbelleğe alır ve manifest kontrolünü 6 saatlik önbellekten kullanır.
