import 'dart:io';

class ElxvroHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    final client = super.createHttpClient(context);
    client.maxConnectionsPerHost = 8;
    client.connectionTimeout = const Duration(seconds: 10);
    client.idleTimeout = const Duration(seconds: 15);
    return client;
  }
}

class ElxvroRequestGate {
  static DateTime _nextAllowed = DateTime.fromMillisecondsSinceEpoch(0);

  static Future<void> waitTurn({
    Duration minimumSpacing = const Duration(milliseconds: 40),
  }) async {
    final now = DateTime.now();
    final slot = _nextAllowed.isAfter(now) ? _nextAllowed : now;
    _nextAllowed = slot.add(minimumSpacing);
    final delay = slot.difference(now);
    if (!delay.isNegative && delay > Duration.zero) {
      await Future<void>.delayed(delay);
    }
  }

  static void penalize(int statusCode, {String? retryAfter}) {
    Duration penalty;
    final seconds = int.tryParse((retryAfter ?? '').trim());
    if (seconds != null && seconds > 0) {
      penalty = Duration(seconds: seconds.clamp(1, 180).toInt());
    } else if (statusCode == 429) {
      penalty = const Duration(seconds: 60);
    } else {
      penalty = const Duration(seconds: 25);
    }
    final candidate = DateTime.now().add(penalty);
    if (candidate.isAfter(_nextAllowed)) _nextAllowed = candidate;
  }
}
