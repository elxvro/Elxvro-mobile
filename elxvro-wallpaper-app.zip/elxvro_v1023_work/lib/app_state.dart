import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'data/local_wallpapers.dart';
import 'models/category_item.dart';
import 'models/wallpaper.dart';
import 'services/category_service.dart';
import 'services/mirror_sync_service.dart';
import 'services/thumbnail_cache_service.dart';
import 'utils/category_key.dart';

class AppState extends ChangeNotifier {
  static const _channel = MethodChannel('com.elxvro.wallpaper/channel');

  final Set<String> _favorites = <String>{};
  final List<String> _recentIds = <String>[];
  final List<String> _appliedIds = <String>[];

  List<CategoryItem> _categories = List<CategoryItem>.from(localCategoryFallback);
  bool _categoriesLoading = false;
  String _categorySource = 'local';
  bool _categoryCacheStale = true;
  DateTime? _categoriesUpdatedAt;

  bool _mediaSyncing = false;
  String _mediaMessage = 'Yerel medya hazırlanıyor.';
  DateTime? _mediaUpdatedAt;
  int _mediaDownloadedLast = 0;
  int _mediaReusedLast = 0;
  int _mediaFailedLast = 0;
  int _mediaRemovedLast = 0;
  int _mediaManifestCount = 0;
  int _mediaProcessed = 0;
  int _mediaTotal = 0;
  double _mediaProgress = 0;
  String _mediaCurrentId = '';
  bool _mediaCleaning = false;
  String _mediaCleanupMessage = '';
  bool _usingMirroredMedia = false;

  String _defaultTarget = 'ask';
  String _accent = 'violet';
  bool _oledMode = false;
  bool _compactGrid = false;
  bool _showCardTitles = false;

  AppState() {
    _restoreLocalState();
    refreshCategories();
    refreshMedia();
  }

  bool isFavorite(String id) => _favorites.contains(id);
  bool wasApplied(String id) => _appliedIds.contains(id);

  String get defaultTarget => _defaultTarget;
  String get accent => _accent;
  bool get oledMode => _oledMode;
  bool get compactGrid => _compactGrid;
  bool get showCardTitles => _showCardTitles;

  List<CategoryItem> get categories => List.unmodifiable(_categories);
  bool get categoriesLoading => _categoriesLoading;
  String get categorySource => _categorySource;
  bool get categoryCacheStale => _categoryCacheStale;
  DateTime? get categoriesUpdatedAt => _categoriesUpdatedAt;

  bool get mediaSyncing => _mediaSyncing;
  String get mediaMessage => _mediaMessage;
  DateTime? get mediaUpdatedAt => _mediaUpdatedAt;
  int get mediaDownloadedLast => _mediaDownloadedLast;
  int get mediaReusedLast => _mediaReusedLast;
  int get mediaFailedLast => _mediaFailedLast;
  int get mediaRemovedLast => _mediaRemovedLast;
  int get mediaManifestCount => _mediaManifestCount;
  int get mediaProcessed => _mediaProcessed;
  int get mediaTotal => _mediaTotal;
  double get mediaProgress => _mediaProgress;
  String get mediaCurrentId => _mediaCurrentId;
  bool get mediaCleaning => _mediaCleaning;
  String get mediaCleanupMessage => _mediaCleanupMessage;
  bool get usingMirroredMedia => _usingMirroredMedia;
  int get localMediaCount => wallpapers.where((item) => item.isLocalFile).length;
  int get visibleMediaCount => wallpapers.length;

  Color get accentColor {
    switch (_accent) {
      case 'cyan':
        return const Color(0xFF0D9AA6);
      case 'pink':
        return const Color(0xFFDD4F78);
      case 'violet':
      default:
        return const Color(0xFF8B5CF6);
    }
  }

  Future<void> refreshCategories({bool force = false}) async {
    if (_categoriesLoading) return;
    _categoriesLoading = true;
    notifyListeners();

    try {
      final result = await CategoryService.load(
        fallback: localCategoryFallback,
        forceRefresh: force,
      );
      if (result.categories.isNotEmpty) {
        _categories = List<CategoryItem>.from(result.categories);
      }
      _mergeCategoriesWithWallpapers();
      _applyCategoryLabels();
      _categorySource = result.source;
      _categoryCacheStale = result.stale;
      _categoriesUpdatedAt = result.updatedAt;
    } catch (_) {
      _categorySource = 'local';
      _categoryCacheStale = true;
    } finally {
      _categoriesLoading = false;
      notifyListeners();
    }
  }


  Future<void> refreshMedia({bool force = false}) async {
    if (_mediaSyncing) return;
    _mediaSyncing = true;
    _mediaProcessed = 0;
    _mediaTotal = 0;
    _mediaProgress = 0;
    _mediaCurrentId = '';
    _mediaDownloadedLast = 0;
    _mediaReusedLast = 0;
    _mediaFailedLast = 0;
    _mediaRemovedLast = 0;
    _mediaCleanupMessage = '';
    _mediaMessage = force ? 'Görseller kontrol ediliyor…' : _mediaMessage;
    notifyListeners();

    final fallback = List<WallpaperItem>.from(wallpapers);
    try {
      final result = await MirrorSyncService.load(
        fallback: fallback,
        forceRefresh: force,
        onProgress: (progress) {
          _mediaProcessed = progress.processed;
          _mediaTotal = progress.total;
          _mediaManifestCount = progress.total;
          _mediaProgress = progress.fraction.clamp(0.0, 1.0).toDouble();
          _mediaCurrentId = progress.currentId;
          _mediaDownloadedLast = progress.downloaded;
          _mediaReusedLast = progress.reused;
          _mediaFailedLast = progress.failed;
          _mediaMessage = progress.total > 0
              ? 'Eşitleniyor: ${progress.processed}/${progress.total}'
              : 'Manifest okunuyor…';
          notifyListeners();
        },
      );
      if (result.wallpapers.isNotEmpty) {
        wallpapers
          ..clear()
          ..addAll(result.wallpapers);
      }
      _mediaDownloadedLast = result.downloaded;
      _mediaReusedLast = result.reused;
      _mediaFailedLast = result.failed;
      _mediaRemovedLast = result.removed;
      _mediaManifestCount = result.manifestCount;
      _mediaUpdatedAt = result.lastCheckedAt;
      _mediaMessage = result.message;
      _mediaProcessed = result.manifestCount;
      _mediaTotal = result.manifestCount;
      _mediaProgress = result.manifestCount > 0 ? 1 : 0;
      _mediaCurrentId = '';
      _mergeCategoriesWithWallpapers();
      _applyCategoryLabels();
      _usingMirroredMedia = wallpapers.any((item) => item.isLocalFile);
      ThumbnailCacheService.prefetch(wallpapers, limit: 16);
    } catch (_) {
      _mediaMessage = 'Yerel medya kullanılıyor.';
      _mediaCurrentId = '';
      _usingMirroredMedia = wallpapers.any((item) => item.isLocalFile);
    } finally {
      _mediaSyncing = false;
      notifyListeners();
    }
  }

  Future<WallpaperItem> ensureLocalMedia(WallpaperItem item) async {
    if (!item.isRemoteUrl) return item;
    final local = await MirrorSyncService.ensureLocal(item);
    final index = wallpapers.indexWhere((candidate) => candidate.id == item.id);
    if (index >= 0) {
      wallpapers[index] = local;
      _usingMirroredMedia = true;
      notifyListeners();
    }
    return local;
  }

  Future<void> cleanupLocalMedia() async {
    if (_mediaSyncing || _mediaCleaning) return;
    _mediaCleaning = true;
    _mediaCleanupMessage = 'Yerel artıklar kontrol ediliyor…';
    notifyListeners();
    try {
      final result = await MirrorSyncService.cleanupLocalMedia();
      _mediaRemovedLast = result.removedFiles;
      if (result.removedFiles == 0) {
        _mediaCleanupMessage = 'Temizlenecek gereksiz dosya yok.';
      } else {
        _mediaCleanupMessage =
            '${result.removedFiles} gereksiz yerel dosya güvenle temizlendi.';
      }
    } catch (_) {
      _mediaCleanupMessage = 'Yerel temizlik tamamlanamadı.';
    } finally {
      _mediaCleaning = false;
      notifyListeners();
    }
  }

  void _mergeCategoriesWithWallpapers() {
    final preferredNames = <String, String>{
      for (final category in localCategoryFallback) category.slug: category.name,
    };
    final merged = <CategoryItem>[];
    final seen = <String>{};

    for (final category in _categories) {
      final slug = categoryKey(category.slug.isEmpty ? category.name : category.slug);
      if (slug.isEmpty || !seen.add(slug)) continue;
      merged.add(
        CategoryItem(
          name: preferredNames[slug] ?? category.name,
          slug: slug,
        ),
      );
    }

    for (final wallpaper in wallpapers) {
      final slug = categoryKey(wallpaper.category);
      if (slug.isEmpty || !seen.add(slug)) continue;
      merged.add(
        CategoryItem(
          name: preferredNames[slug] ?? wallpaper.category,
          slug: slug,
        ),
      );
    }

    _categories = merged;
  }

  void _applyCategoryLabels() {
    if (_categories.isEmpty || wallpapers.isEmpty) return;
    for (var i = 0; i < wallpapers.length; i++) {
      final current = wallpapers[i];
      final key = categoryKey(current.category);
      CategoryItem? match;
      for (final category in _categories) {
        if (category.slug == key || categoryKey(category.name) == key) {
          match = category;
          break;
        }
      }
      if (match != null && current.category != match.name) {
        wallpapers[i] = current.copyWith(category: match.name);
      }
    }
  }

  void toggleFavorite(String id) {
    if (!_favorites.add(id)) {
      _favorites.remove(id);
    }
    notifyListeners();
    _saveLocalState();
  }

  void markViewed(String id) {
    _recentIds.remove(id);
    _recentIds.insert(0, id);
    if (_recentIds.length > 20) {
      _recentIds.removeRange(20, _recentIds.length);
    }
    notifyListeners();
    _saveLocalState();
  }

  void markApplied(String id) {
    _appliedIds.remove(id);
    _appliedIds.insert(0, id);
    if (_appliedIds.length > 20) {
      _appliedIds.removeRange(20, _appliedIds.length);
    }
    notifyListeners();
    _saveLocalState();
  }

  void clearRecent() {
    _recentIds.clear();
    notifyListeners();
    _saveLocalState();
  }

  void clearApplied() {
    _appliedIds.clear();
    notifyListeners();
    _saveLocalState();
  }

  void clearFavorites() {
    _favorites.clear();
    notifyListeners();
    _saveLocalState();
  }

  Future<void> resetUserData() async {
    _favorites.clear();
    _recentIds.clear();
    _appliedIds.clear();
    _defaultTarget = 'ask';
    _accent = 'violet';
    _oledMode = false;
    _compactGrid = false;
    _showCardTitles = false;
    notifyListeners();
    await _saveLocalState();
  }

  void setDefaultTarget(String value) {
    if (!const {'ask', 'home', 'lock', 'both'}.contains(value)) return;
    if (_defaultTarget == value) return;
    _defaultTarget = value;
    notifyListeners();
    _saveLocalState();
  }

  void setAccent(String value) {
    if (!const {'violet', 'cyan', 'pink'}.contains(value)) return;
    if (_accent == value) return;
    _accent = value;
    notifyListeners();
    _saveLocalState();
  }

  void setOledMode(bool value) {
    if (_oledMode == value) return;
    _oledMode = value;
    notifyListeners();
    _saveLocalState();
  }

  void setCompactGrid(bool value) {
    if (_compactGrid == value) return;
    _compactGrid = value;
    notifyListeners();
    _saveLocalState();
  }

  void setShowCardTitles(bool value) {
    if (_showCardTitles == value) return;
    _showCardTitles = value;
    notifyListeners();
    _saveLocalState();
  }

  List<WallpaperItem> get favorites =>
      wallpapers.where((item) => _favorites.contains(item.id)).toList();

  List<WallpaperItem> get recent => _itemsFromIds(_recentIds);
  List<WallpaperItem> get applied => _itemsFromIds(_appliedIds);

  WallpaperItem? get lastApplied => applied.isEmpty ? null : applied.first;

  List<WallpaperItem> _itemsFromIds(List<String> ids) => ids
      .map((id) => wallpapers.where((item) => item.id == id).firstOrNull)
      .whereType<WallpaperItem>()
      .toList();

  Future<void> _restoreLocalState() async {
    try {
      final saved = await _channel.invokeMapMethod<String, dynamic>('loadState');
      if (saved == null || saved['hasState'] != true) return;

      final favoriteIds = (saved['favorites'] as List<dynamic>? ?? const [])
          .whereType<String>()
          .toSet();
      final recentIds = (saved['recent'] as List<dynamic>? ?? const [])
          .whereType<String>()
          .take(20)
          .toList();
      final appliedIds = (saved['applied'] as List<dynamic>? ?? const [])
          .whereType<String>()
          .take(20)
          .toList();

      _favorites
        ..clear()
        ..addAll(favoriteIds);
      _recentIds
        ..clear()
        ..addAll(recentIds);
      _appliedIds
        ..clear()
        ..addAll(appliedIds);

      final defaultTarget = saved['defaultTarget'];
      if (defaultTarget is String &&
          const {'ask', 'home', 'lock', 'both'}.contains(defaultTarget)) {
        _defaultTarget = defaultTarget;
      }

      final accent = saved['accent'];
      if (accent is String && const {'violet', 'cyan', 'pink'}.contains(accent)) {
        _accent = accent;
      }

      _oledMode = false;
      _compactGrid = saved['compactGrid'] == true;
      // v1.0.16: Liste/kart ekranlarında görsel adı gösterilmez.
      _showCardTitles = false;

      notifyListeners();
    } on MissingPluginException {
      // Widget testleri veya Android dışı ortamlarda yerel kayıt kullanılamaz.
    } on PlatformException {
      // Yerel kayıt okunamazsa uygulama varsayılan durumla çalışmaya devam eder.
    }
  }

  Future<void> _saveLocalState() async {
    try {
      await _channel.invokeMethod<void>('saveState', {
        'favorites': _favorites.toList(growable: false),
        'recent': _recentIds.toList(growable: false),
        'applied': _appliedIds.toList(growable: false),
        'defaultTarget': _defaultTarget,
        'accent': _accent,
        'oledMode': _oledMode,
        'compactGrid': _compactGrid,
        'showCardTitles': _showCardTitles,
      });
    } on MissingPluginException {
      // Widget testleri veya Android dışı ortamlarda sessizce atla.
    } on PlatformException {
      // Kayıt hatası ana uygulama akışını engellememeli.
    }
  }


  Map<String, dynamic> exportBackupData() => <String, dynamic>{
        'schema': 1,
        'app': 'ELXVRO',
        'version': '1.0.23',
        'exported_at': DateTime.now().toUtc().toIso8601String(),
        'favorites': _favorites.toList(growable: false),
        'recent': _recentIds.toList(growable: false),
        'applied': _appliedIds.toList(growable: false),
        'settings': <String, dynamic>{
          'defaultTarget': _defaultTarget,
          'accent': _accent,
          'oledMode': _oledMode,
          'compactGrid': _compactGrid,
          'showCardTitles': false,
        },
      };

  Future<void> importBackupData(Map<String, dynamic> backup) async {
    if (backup['app'] != 'ELXVRO') {
      throw const FormatException('ELXVRO yedek dosyası değil.');
    }

    Set<String> stringSet(dynamic value) => value is List
        ? value.whereType<String>().where((id) => id.trim().isNotEmpty).toSet()
        : <String>{};

    List<String> stringList(dynamic value) => value is List
        ? value
            .whereType<String>()
            .where((id) => id.trim().isNotEmpty)
            .take(20)
            .toList()
        : <String>[];

    _favorites
      ..clear()
      ..addAll(stringSet(backup['favorites']));
    _recentIds
      ..clear()
      ..addAll(stringList(backup['recent']));
    _appliedIds
      ..clear()
      ..addAll(stringList(backup['applied']));

    final rawSettings = backup['settings'];
    if (rawSettings is Map) {
      final settings = Map<String, dynamic>.from(rawSettings);
      final defaultTarget = settings['defaultTarget'];
      if (defaultTarget is String &&
          const {'ask', 'home', 'lock', 'both'}.contains(defaultTarget)) {
        _defaultTarget = defaultTarget;
      }
      final accent = settings['accent'];
      if (accent is String && const {'violet', 'cyan', 'pink'}.contains(accent)) {
        _accent = accent;
      }
      _oledMode = settings['oledMode'] == true;
      _compactGrid = settings['compactGrid'] == true;
    }

    // ELXVRO tasarım kuralı: galeri kartlarında isim gösterilmez.
    _showCardTitles = false;
    notifyListeners();
    await _saveLocalState();
  }

}

extension _FirstOrNullExtension<T> on Iterable<T> {
  T? get firstOrNull {
    final iterator = this.iterator;
    if (!iterator.moveNext()) return null;
    return iterator.current;
  }
}

class AppScope extends InheritedNotifier<AppState> {
  const AppScope({
    super.key,
    required AppState notifier,
    required super.child,
  }) : super(notifier: notifier);

  static AppState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope bulunamadı');
    return scope!.notifier!;
  }
}
