# ELXVRO v1.0.23

## Statik medya hız katmanı
- Manifest artık PHP yerine `/app-media/media-manifest.json` statik dosyasından okunur.
- Thumbnail indirme kuyruğu 8 kontrollü paralel bağlantıya çıkarıldı.
- İlk 16 thumbnail arka planda hazırlanır.
- Statik medya için istek aralığı düşürüldü; 403/429 geri çekilme koruması korunur.
- Disk önbelleği ve orijinal görsel yerel saklama sistemi korunur.

## Hızlı Galeri v1.0.23
- Thumbnail istekleri 4 kontrollü paralel bağlantı ve kalıcı HTTP keep-alive ile hızlandırıldı.
- İlk 8 küçük görsel açılış ekranı sırasında düşük öncelikle önceden hazırlanır.
- Ekranda istenen thumbnail, arka plan ön yüklemelerinin önüne geçer.
- Ana sayfadaki büyük vitrin artık tam çözünürlüklü dosyayı galeri açılışında indirmez; thumbnail kullanır.
- 403/429 geri çekilme koruması ve disk önbelleği korunur.

- Sunucu/IP koruması: ELXVRO istekleri aralıklı gönderilir ve eşzamanlı bağlantı sayısı sınırlandırılır.
- 403/429 yanıtlarında otomatik bekleme uygulanır; uygulama aynı endpointi tekrar tekrar zorlamaz.
- Thumbnail görselleri uygulamanın özel alanında disk önbelleğine alınır; aynı görsel tekrar sunucudan istenmez.
- Galeride thumbnail başarısız olduğunda tam çözünürlüklü görsele otomatik saldırgan fallback kaldırıldı.
- Tam çözünürlüklü görseller tek istekle yerel mirror alanına alınır ve tekrar kullanılır.
- Manifest her uygulama açılışında yeniden istenmez; 6 saat boyunca yerel katalog kullanılır.
- Mevcut beyaz/lila/mor tema ve Google/MySQL hesap sistemi korunur.

- Yeni beyaz/lila/mor başlangıç ekranı ve profesyonel ELXVRO wordmark.
- Yeni ELXVRO launcher/APK ikonu.
- Keşfet sayfasındaki kategori şeridi kaldırıldı.
- Wallpaper detayında sağ/sol kaydırmayı engelleyen overlay düzeltildi; hızlı geçiş okları eklendi.
- Düzenleyiciye sıcaklık, vinyet ve yeni filtre presetleri eklendi.
- Profil tasarımı geliştirildi; hesap bilgileri ve Google Drive yedekleme/geri yükleme eklendi.
- Gizlilik Politikası ve Kullanım Koşulları kapsamlı biçimde güncellendi.
- Açık tema mor/lila marka renkleriyle rafine edildi.

# ELXVRO v1.0.19

- Google Sign-In Android entegrasyonu 6.x legacy SDK'dan 7.2 Credential Manager tabanlı yapıya geçirildi.
- Google Sign-In artık tekil `GoogleSignIn.instance` üzerinden initialize ediliyor.
- Etkileşimli giriş `authenticate()`, oturum geri yükleme `attemptLightweightAuthentication()` kullanıyor.
- Google yapılandırma hataları yeni yapılandırılmış hata kodlarıyla kullanıcıya daha net gösteriliyor.
- MySQL hesap servisi ve Web OAuth client ID yapısı korunuyor.
- GitHub Actions workflow değiştirilmedi.

# 1.0.19

- Google girişine sunucu tarafı MySQL hesap kaydı eklendi.
- Google ID token, ELXVRO PHP auth servisi tarafından Google ile doğrulanmadan kullanıcı kaydı oluşturulmaz.
- `elxvro_app_users` tablosunda Google hesap kimliği, e-posta, görünen ad, avatar URL'si, yasal onay sürümü ve giriş zamanları tutulur.
- Profilde MySQL senkron durumu ve ELXVRO hesap ID'si gösterilir.
- Hesap silme işlemi önce sunucudaki MySQL hesabını siler, ardından cihazdaki ELXVRO kullanıcı verilerini ve Google bağlantısını temizler.
- Sessiz oturum geri yüklemede MySQL servisi geçici olarak ulaşılamazsa Google oturumu korunur ve profil içinde senkron uyarısı gösterilir.
- Google parolası hiçbir zaman ELXVRO sunucusuna gönderilmez veya saklanmaz.
- Gizlilik Politikası MySQL hesap depolama davranışına göre güncellendi.
- Çalışan GitHub Actions workflow dosyası değiştirilmedi.

# 1.0.16

- ELXVRO arayüzü baştan sona açık, yumuşak beyaz Material 3 tasarıma geçirildi.
- Arka plan, yüzey, sınır, metin ve vurgu renkleri profesyonel bir tasarım sistemi altında standardize edildi.
- Keşfet ekranına büyük arama alanı ve “Hızlı Keşfet” kısayolları eklendi.
- Günün seçimi, kategori kartları, geçmiş, son uygulanan ve ana galeri yeniden düzenlendi.
- Alt navigasyon, ayarlar, profil, favoriler, kategoriler, koleksiyonlar, arama ve Sync Manager açık temaya uyarlandı.
- Galeri kartlarında görsel adı gösterilmiyor; ad yalnızca detay ekranında gösteriliyor.
- Görsel detay ve düzenleyici ekranları fotoğraf odaklı koyu modda bırakıldı.
- Görsel kartlarına daha yumuşak köşeler, gölge ve tutarlı boşluk sistemi eklendi.
- Boş durum ekranları ve yardımcı metinler yeniden tasarlandı.
- Ayarlar ekranında açık tema bilgisi, yeni vurgu paleti ve daha düzenli ayar grupları eklendi.
- Gizlilik metni güncel Local Mirror / thumbnail çalışma biçimine göre güncellendi.
- Çalışan GitHub Actions workflow dosyası değiştirilmedi.

# 1.0.15

- Instant Gallery: ilk açılışta 286 görselin toplu indirilmesi kaldırıldı.
- Uygulama yalnızca manifesti alır ve galeri hemen kullanılabilir olur.
- Görseller ekranda ihtiyaç oldukça ağdan yüklenir.
- Detayda açılan görsel uygulamaya özel depolamaya otomatik alınır ve çevrimdışı kullanılabilir.
- Duvar kağıdı yapma ve düzenleyici açma sırasında gerekli dosya yerel kopyaya güvenli biçimde hazırlanır.
- Sync Manager içindeki tam eşitleme isteğe bağlıdır: “Tümünü çevrimdışı hazırla”.
- Mevcut yerel dosyalar korunur; imzası değişmiş eski kopyalar ağ sürümüne geçirilir.

# 1.0.13

- Sync Manager eklendi: canlı ilerleme, manifest/cihaz/yeni/değişmemiş/hata/temizlenen sayaçları.
- Local Mirror yalnızca yeni veya imzası değişen dosyaları indirir; tek dosya hatasında diğer dosyalar devam eder.
- Son başarılı eşitleme zamanı korunur; kısmi hata başarılı eşitleme zamanını ezmez.
- Başarılı tam eşitleme sonrası güvenli orphan temizliği ve manuel güvenli temizlik eklendi.
- Manifest schema 2 tekil ID yapısıyla uyum sağlandı.
- `_thumb` medya dosyaları istemci tarafında da reddedilir.