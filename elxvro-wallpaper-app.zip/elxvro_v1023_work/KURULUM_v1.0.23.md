# ELXVRO v1.0.23 kurulum

1. ZIP dosyasını GitHub depo köküne `elxvro-wallpaper-app.zip` adıyla yükle.
2. Mevcut çalışan `.github/workflows/build-apk.yml` dosyasını değiştirme.
3. GitHub Actions derlemesini çalıştır.
4. Oluşan release APK'yı telefona kur.

Bu sürüm galeri thumbnail hızını artırırken 403/429 sunucu geri çekilme korumasını ve kalıcı disk önbelleğini korur.
