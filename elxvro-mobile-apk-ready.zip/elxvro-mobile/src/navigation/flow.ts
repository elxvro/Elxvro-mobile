export const routes = {
  home: '/' as const,
  explore: '/explore' as const,
  categories: '/categories' as const,
  favorites: '/favorites' as const,
  profile: '/profile' as const,
  onboarding: '/onboarding' as const,
  wallpaper: (id: string) => `/wallpaper/${encodeURIComponent(id)}` as const,
  category: (slug: string) => `/category/${encodeURIComponent(slug)}` as const
};

export const appFlow = [
  'Onboarding',
  'Home',
  'Explore / Categories',
  'Wallpaper Detail',
  'Favorite',
  'Favorites / Profile'
] as const;
