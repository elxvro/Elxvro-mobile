import { apiRequest, toAbsoluteMediaUrl } from '@/api/client';
import type {
  Category,
  Wallpaper,
  WallpaperListResult,
  WallpaperSort
} from '@/types/wallpaper';

type UnknownRecord = Record<string, unknown>;

type RawListResponse = {
  ok?: boolean;
  page?: number;
  limit?: number;
  total?: number;
  pages?: number;
  data?: unknown[];
};

function asRecord(value: unknown): UnknownRecord {
  return value && typeof value === 'object' ? (value as UnknownRecord) : {};
}

function stringValue(value: unknown, fallback = ''): string {
  return typeof value === 'string' ? value : fallback;
}

function numberValue(value: unknown, fallback = 0): number {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function booleanValue(value: unknown): boolean {
  return value === true || value === 1 || value === '1' || value === 'true';
}

function normalizeWallpaper(value: unknown): Wallpaper {
  const raw = asRecord(value);
  const categoryRaw = asRecord(raw.category ?? raw.kategori);

  const categoryName = stringValue(categoryRaw.name ?? categoryRaw.ad);
  const categorySlug = stringValue(categoryRaw.slug);

  return {
    code: stringValue(raw.code ?? raw.kod ?? raw.id, 'unknown'),
    deviceType: stringValue(raw.device_type ?? raw.device ?? raw.cihaz_turu, 'mobile'),
    category:
      categoryName || categorySlug
        ? { name: categoryName || categorySlug, slug: categorySlug || categoryName }
        : undefined,
    width: numberValue(raw.width ?? raw.genislik) || undefined,
    height: numberValue(raw.height ?? raw.yukseklik) || undefined,
    orientation: stringValue(raw.orientation ?? raw.yonlendirme) || undefined,
    views: numberValue(raw.views ?? raw.goruntulemeler),
    favorites: numberValue(raw.favorites ?? raw.favoriler),
    thumbUrl: toAbsoluteMediaUrl(stringValue(raw.thumb ?? raw.kucuk_resim) || undefined),
    previewUrl: toAbsoluteMediaUrl(stringValue(raw.preview ?? raw.onizleme) || undefined),
    fullUrl: toAbsoluteMediaUrl(stringValue(raw.full ?? raw.tam) || undefined),
    downloadEnabled: booleanValue(raw.download_enabled ?? raw.indirme_etkin)
  };
}

function normalizeCategory(value: unknown): Category {
  const raw = asRecord(value);
  const name = stringValue(raw.name ?? raw.ad);
  const slug = stringValue(raw.slug, name.toLowerCase());

  return {
    id: typeof raw.id === 'string' || typeof raw.id === 'number' ? raw.id : undefined,
    name: name || slug,
    slug,
    count: numberValue(raw.count ?? raw.total ?? raw.adet) || undefined,
    coverUrl: toAbsoluteMediaUrl(
      stringValue(raw.cover ?? raw.cover_url ?? raw.thumb ?? raw.image) || undefined
    )
  };
}

function unwrapObject(value: unknown): unknown {
  const raw = asRecord(value);
  const candidate = raw.data ?? raw.wallpaper ?? raw.item;
  if (Array.isArray(candidate)) return candidate[0] ?? {};
  return candidate ?? value;
}

function unwrapArray(value: unknown): unknown[] {
  if (Array.isArray(value)) return value;
  const raw = asRecord(value);
  const candidates = [raw.data, raw.categories, raw.items];
  return candidates.find(Array.isArray) as unknown[] | undefined ?? [];
}

export type ListWallpapersOptions = {
  page?: number;
  limit?: number;
  category?: string;
  sort?: WallpaperSort;
};

export const wallpaperService = {
  async list(options: ListWallpapersOptions = {}): Promise<WallpaperListResult> {
    const page = Math.max(1, options.page ?? 1);
    const limit = Math.min(60, Math.max(1, options.limit ?? 24));
    const sort = options.sort ?? 'new';

    const params = [
      'device=mobile',
      `page=${page}`,
      `limit=${limit}`,
      `sort=${encodeURIComponent(sort)}`
    ];

    if (options.category) {
      params.push(`category=${encodeURIComponent(options.category)}`);
    }

    const response = await apiRequest<RawListResponse>(
      `/wallpapers.php?${params.join('&')}`
    );

    const data = Array.isArray(response.data)
      ? response.data.map(normalizeWallpaper)
      : [];

    return {
      page: numberValue(response.page, page),
      limit: numberValue(response.limit, limit),
      total: numberValue(response.total, data.length),
      pages: numberValue(response.pages, 1),
      data
    };
  },

  async getByCode(code: string): Promise<Wallpaper> {
    const response = await apiRequest<unknown>(
      `/wallpaper.php?code=${encodeURIComponent(code)}&device=mobile`
    );
    return normalizeWallpaper(unwrapObject(response));
  },

  async categories(): Promise<Category[]> {
    const response = await apiRequest<unknown>('/categories.php');
    return unwrapArray(response)
      .map(normalizeCategory)
      .filter((category) => category.slug.length > 0);
  },

  byCategory(slug: string, page = 1, limit = 24) {
    return this.list({ category: slug, page, limit, sort: 'new' });
  },

  status() {
    return apiRequest<unknown>('/status.php');
  }
};
