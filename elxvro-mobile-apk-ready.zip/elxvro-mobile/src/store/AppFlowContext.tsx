import { PropsWithChildren, createContext, useContext, useMemo, useState } from 'react';

type AppFlowContextValue = {
  onboardingCompleted: boolean;
  favorites: string[];
  completeOnboarding: () => void;
  resetOnboarding: () => void;
  isFavorite: (id: string) => boolean;
  toggleFavorite: (id: string) => void;
};

const AppFlowContext = createContext<AppFlowContextValue | null>(null);

export function AppFlowProvider({ children }: PropsWithChildren) {
  const [onboardingCompleted, setOnboardingCompleted] = useState(false);
  const [favorites, setFavorites] = useState<string[]>([]);

  const value = useMemo<AppFlowContextValue>(
    () => ({
      onboardingCompleted,
      favorites,
      completeOnboarding: () => setOnboardingCompleted(true),
      resetOnboarding: () => setOnboardingCompleted(false),
      isFavorite: (id) => favorites.includes(id),
      toggleFavorite: (id) => {
        setFavorites((current) =>
          current.includes(id)
            ? current.filter((favoriteId) => favoriteId !== id)
            : [...current, id]
        );
      }
    }),
    [favorites, onboardingCompleted]
  );

  return <AppFlowContext.Provider value={value}>{children}</AppFlowContext.Provider>;
}

export function useAppFlow() {
  const context = useContext(AppFlowContext);

  if (!context) {
    throw new Error('useAppFlow must be used inside AppFlowProvider');
  }

  return context;
}
