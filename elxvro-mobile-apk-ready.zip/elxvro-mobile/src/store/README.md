# store

Application state (favorites, session, preferences) will live here.
