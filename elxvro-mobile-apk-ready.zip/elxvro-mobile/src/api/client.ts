const DEFAULT_API_BASE_URL = 'https://elxvro.com/api';

export const API_BASE_URL = (
  process.env.EXPO_PUBLIC_API_BASE_URL || DEFAULT_API_BASE_URL
).replace(/\/+$/, '');

const originMatch = API_BASE_URL.match(/^(https?:\/\/[^/]+)/i);
export const SITE_BASE_URL = originMatch?.[1] ?? 'https://elxvro.com';

export class ApiError extends Error {
  status: number;

  constructor(message: string, status: number) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

export function toAbsoluteMediaUrl(value?: string | null): string | undefined {
  if (!value) return undefined;
  if (/^https?:\/\//i.test(value)) return value;
  if (value.startsWith('/')) return `${SITE_BASE_URL}${value}`;
  return `${SITE_BASE_URL}/${value.replace(/^\/+/, '')}`;
}

export async function apiRequest<T>(
  path: string,
  init: RequestInit = {}
): Promise<T> {
  const url = `${API_BASE_URL}/${path.replace(/^\/+/, '')}`;

  const response = await fetch(url, {
    ...init,
    headers: {
      Accept: 'application/json',
      ...init.headers
    }
  });

  if (!response.ok) {
    let message = `API isteği başarısız (${response.status})`;

    try {
      const body = (await response.json()) as { message?: string };
      if (body.message) message = body.message;
    } catch {
      // JSON olmayan hata cevaplarında varsayılan mesaj kullanılır.
    }

    throw new ApiError(message, response.status);
  }

  if (response.status === 204) {
    return undefined as T;
  }

  return (await response.json()) as T;
}
