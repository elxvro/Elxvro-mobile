import { router } from 'expo-router';
import { StyleSheet, Text, View } from 'react-native';
import { theme } from '@/constants/theme';
import type { Wallpaper } from '@/types/wallpaper';
import { WallpaperCard } from '@/components/WallpaperCard';

type Props = {
  items: Wallpaper[];
  emptyText?: string;
};

export function WallpaperGrid({ items, emptyText = 'İçerik bulunamadı.' }: Props) {
  if (items.length === 0) {
    return (
      <View style={styles.empty}>
        <Text style={styles.emptyText}>{emptyText}</Text>
      </View>
    );
  }

  return (
    <View style={styles.grid}>
      {items.map((item) => (
        <WallpaperCard
          key={item.code}
          item={item}
          onPress={() => router.push(`/wallpaper/${encodeURIComponent(item.code)}`)}
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    rowGap: theme.spacing.md
  },
  empty: {
    padding: theme.spacing.lg,
    borderRadius: theme.radius.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
    backgroundColor: theme.colors.surface
  },
  emptyText: {
    color: theme.colors.textMuted,
    lineHeight: 21
  }
});
