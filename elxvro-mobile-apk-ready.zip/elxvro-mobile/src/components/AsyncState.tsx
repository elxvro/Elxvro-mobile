import { ActivityIndicator, Pressable, StyleSheet, Text, View } from 'react-native';
import { theme } from '@/constants/theme';

type Props = {
  loading?: boolean;
  error?: string | null;
  onRetry?: () => void;
};

export function AsyncState({ loading, error, onRetry }: Props) {
  if (loading) {
    return (
      <View style={styles.box}>
        <ActivityIndicator />
        <Text style={styles.text}>ELXVRO verileri yükleniyor…</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.box}>
        <Text style={styles.errorTitle}>API bağlantısı kurulamadı.</Text>
        <Text style={styles.text}>{error}</Text>
        {onRetry ? (
          <Pressable style={styles.button} onPress={onRetry}>
            <Text style={styles.buttonText}>Tekrar Dene</Text>
          </Pressable>
        ) : null}
      </View>
    );
  }

  return null;
}

const styles = StyleSheet.create({
  box: {
    padding: theme.spacing.lg,
    borderRadius: theme.radius.md,
    backgroundColor: theme.colors.surface,
    borderWidth: 1,
    borderColor: theme.colors.border,
    alignItems: 'center',
    gap: 10
  },
  errorTitle: {
    color: theme.colors.text,
    fontWeight: '900',
    fontSize: 16
  },
  text: {
    color: theme.colors.textMuted,
    textAlign: 'center',
    lineHeight: 20
  },
  button: {
    marginTop: 4,
    minHeight: 42,
    paddingHorizontal: 18,
    borderRadius: theme.radius.sm,
    borderWidth: 1,
    borderColor: theme.colors.accent,
    alignItems: 'center',
    justifyContent: 'center'
  },
  buttonText: {
    color: theme.colors.accent,
    fontWeight: '900'
  }
});
