import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { theme } from '@/constants/theme';
import type { Wallpaper } from '@/types/wallpaper';

type Props = {
  item: Wallpaper;
  onPress: () => void;
};

export function WallpaperCard({ item, onPress }: Props) {
  const imageUrl = item.thumbUrl || item.previewUrl;

  return (
    <Pressable accessibilityRole="button" style={styles.card} onPress={onPress}>
      <View style={styles.imageWrap}>
        {imageUrl ? (
          <Image source={{ uri: imageUrl }} style={styles.image} resizeMode="cover" />
        ) : (
          <View style={styles.imageFallback}>
            <Text style={styles.fallbackText}>ELXVRO</Text>
          </View>
        )}
      </View>
      <View style={styles.meta}>
        <Text numberOfLines={1} style={styles.code}>{item.code}</Text>
        <Text numberOfLines={1} style={styles.category}>
          {item.category?.name ?? 'Wallpaper'}
        </Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    width: '48.5%',
    gap: 8
  },
  imageWrap: {
    aspectRatio: 0.56,
    overflow: 'hidden',
    borderRadius: theme.radius.md,
    backgroundColor: theme.colors.surfaceMuted,
    borderWidth: 1,
    borderColor: theme.colors.border
  },
  image: {
    width: '100%',
    height: '100%'
  },
  imageFallback: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  fallbackText: {
    color: theme.colors.accent,
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 2
  },
  meta: {
    paddingHorizontal: 2
  },
  code: {
    color: theme.colors.text,
    fontSize: 12,
    fontWeight: '800'
  },
  category: {
    color: theme.colors.textMuted,
    fontSize: 11,
    marginTop: 2
  }
});
