import type { ReactNode } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { theme } from '@/constants/theme';

type Props = {
  title: string;
  description: string;
  badge?: string;
  onPress?: () => void;
  footer?: ReactNode;
};

export function ActionCard({ title, description, badge, onPress, footer }: Props) {
  return (
    <Pressable
      accessibilityRole={onPress ? 'button' : undefined}
      onPress={onPress}
      style={({ pressed }) => [styles.card, pressed && onPress ? styles.pressed : null]}
    >
      <View style={styles.row}>
        <Text style={styles.title}>{title}</Text>
        {badge ? <Text style={styles.badge}>{badge}</Text> : null}
      </View>
      <Text style={styles.description}>{description}</Text>
      {footer}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    padding: theme.spacing.md,
    borderRadius: theme.radius.md,
    backgroundColor: theme.colors.surface,
    borderWidth: 1,
    borderColor: theme.colors.border,
    gap: 10
  },
  pressed: {
    opacity: 0.78
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
    alignItems: 'center'
  },
  title: {
    flex: 1,
    color: theme.colors.text,
    fontSize: 18,
    fontWeight: '800'
  },
  badge: {
    overflow: 'hidden',
    color: theme.colors.accentText,
    backgroundColor: theme.colors.accent,
    paddingHorizontal: 9,
    paddingVertical: 4,
    borderRadius: 999,
    fontSize: 11,
    fontWeight: '900'
  },
  description: {
    color: theme.colors.textMuted,
    fontSize: 14,
    lineHeight: 20
  }
});
