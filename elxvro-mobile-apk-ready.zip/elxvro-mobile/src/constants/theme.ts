export const theme = {
  colors: {
    background: '#08090B',
    surface: '#111318',
    surfaceMuted: '#181B21',
    border: '#252932',
    text: '#F6F7F9',
    textMuted: '#9AA1AC',
    accent: '#E7FF5B',
    accentText: '#0B0C0E',
    danger: '#FF6B6B'
  },
  radius: {
    sm: 10,
    md: 16,
    lg: 24
  },
  spacing: {
    xs: 6,
    sm: 10,
    md: 16,
    lg: 24,
    xl: 32
  }
} as const;
