export type WallpaperCategory = {
  name: string;
  slug: string;
};

export type Wallpaper = {
  code: string;
  deviceType: 'mobile' | 'pc' | string;
  category?: WallpaperCategory;
  width?: number;
  height?: number;
  orientation?: string;
  views: number;
  favorites: number;
  thumbUrl?: string;
  previewUrl?: string;
  fullUrl?: string;
  downloadEnabled: boolean;
};

export type Category = {
  id?: string | number;
  name: string;
  slug: string;
  count?: number;
  coverUrl?: string;
};

export type WallpaperListResult = {
  page: number;
  limit: number;
  total: number;
  pages: number;
  data: Wallpaper[];
};

export type WallpaperSort = 'new' | 'popular' | 'favorites' | 'random';
