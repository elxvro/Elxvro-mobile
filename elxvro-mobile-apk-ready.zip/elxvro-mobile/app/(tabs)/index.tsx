import { router } from 'expo-router';
import { useCallback, useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { AsyncState } from '@/components/AsyncState';
import { PageHeader } from '@/components/PageHeader';
import { Screen } from '@/components/Screen';
import { WallpaperGrid } from '@/components/WallpaperGrid';
import { theme } from '@/constants/theme';
import { wallpaperService } from '@/services/wallpaper.service';
import type { Wallpaper } from '@/types/wallpaper';

export default function HomeScreen() {
  const [items, setItems] = useState<Wallpaper[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await wallpaperService.list({ limit: 6, sort: 'new' });
      setItems(result.data);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Bilinmeyen API hatası');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <Screen>
      <PageHeader
        eyebrow="ELXVRO"
        title="Yeni wallpaper'lar"
        subtitle="Bu ekran doğrudan elxvro.com JSON API'sindeki mobil içerikleri kullanır."
      />

      <View style={styles.hero}>
        <Text style={styles.heroTag}>LIVE API</Text>
        <Text style={styles.heroTitle}>ELXVRO Mobile artık gerçek sunucuya bağlı.</Text>
        <Text style={styles.heroText}>Yeni içerikler, kategoriler ve detay sayfaları API üzerinden yüklenir.</Text>
        <Pressable style={styles.heroButton} onPress={() => router.push('/explore')}>
          <Text style={styles.heroButtonText}>Tümünü Keşfet</Text>
        </Pressable>
      </View>

      <AsyncState loading={loading} error={error} onRetry={load} />
      {!loading && !error ? <WallpaperGrid items={items} /> : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  hero: {
    padding: theme.spacing.lg,
    marginBottom: theme.spacing.lg,
    borderRadius: theme.radius.lg,
    backgroundColor: theme.colors.surfaceMuted,
    borderWidth: 1,
    borderColor: theme.colors.border,
    gap: 10
  },
  heroTag: {
    color: theme.colors.accent,
    fontSize: 12,
    fontWeight: '900',
    letterSpacing: 2
  },
  heroTitle: {
    color: theme.colors.text,
    fontSize: 27,
    lineHeight: 31,
    fontWeight: '900'
  },
  heroText: {
    color: theme.colors.textMuted,
    fontSize: 14,
    lineHeight: 21
  },
  heroButton: {
    alignSelf: 'flex-start',
    marginTop: 8,
    minHeight: 44,
    paddingHorizontal: 16,
    borderRadius: theme.radius.sm,
    backgroundColor: theme.colors.accent,
    alignItems: 'center',
    justifyContent: 'center'
  },
  heroButtonText: {
    color: theme.colors.accentText,
    fontWeight: '900'
  }
});
