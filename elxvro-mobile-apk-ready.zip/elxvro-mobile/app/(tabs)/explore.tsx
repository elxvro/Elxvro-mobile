import { useCallback, useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { AsyncState } from '@/components/AsyncState';
import { PageHeader } from '@/components/PageHeader';
import { Screen } from '@/components/Screen';
import { WallpaperGrid } from '@/components/WallpaperGrid';
import { theme } from '@/constants/theme';
import { wallpaperService } from '@/services/wallpaper.service';
import type { Wallpaper, WallpaperSort } from '@/types/wallpaper';

const filters: { label: string; value: WallpaperSort }[] = [
  { label: 'Yeni', value: 'new' },
  { label: 'Popüler', value: 'popular' },
  { label: 'Rastgele', value: 'random' }
];

export default function ExploreScreen() {
  const [sort, setSort] = useState<WallpaperSort>('new');
  const [items, setItems] = useState<Wallpaper[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await wallpaperService.list({ page: 1, limit: 24, sort });
      setItems(result.data);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Bilinmeyen API hatası');
    } finally {
      setLoading(false);
    }
  }, [sort]);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <Screen>
      <PageHeader
        eyebrow="DISCOVER"
        title="Keşfet"
        subtitle="ELXVRO API'deki mobil wallpaper koleksiyonunu görüntüle."
      />

      <View style={styles.filters}>
        {filters.map((filter) => {
          const active = filter.value === sort;
          return (
            <Pressable
              key={filter.value}
              style={[styles.filter, active && styles.filterActive]}
              onPress={() => setSort(filter.value)}
            >
              <Text style={[styles.filterText, active && styles.filterTextActive]}>
                {filter.label}
              </Text>
            </Pressable>
          );
        })}
      </View>

      <AsyncState loading={loading} error={error} onRetry={load} />
      {!loading && !error ? <WallpaperGrid items={items} /> : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  filters: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: theme.spacing.lg
  },
  filter: {
    minHeight: 40,
    paddingHorizontal: 14,
    borderRadius: 99,
    borderWidth: 1,
    borderColor: theme.colors.border,
    alignItems: 'center',
    justifyContent: 'center'
  },
  filterActive: {
    backgroundColor: theme.colors.accent,
    borderColor: theme.colors.accent
  },
  filterText: {
    color: theme.colors.textMuted,
    fontWeight: '800'
  },
  filterTextActive: {
    color: theme.colors.accentText
  }
});
