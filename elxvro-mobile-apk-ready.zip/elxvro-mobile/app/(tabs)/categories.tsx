import { router } from 'expo-router';
import { useCallback, useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { AsyncState } from '@/components/AsyncState';
import { PageHeader } from '@/components/PageHeader';
import { Screen } from '@/components/Screen';
import { theme } from '@/constants/theme';
import { wallpaperService } from '@/services/wallpaper.service';
import type { Category } from '@/types/wallpaper';

export default function CategoriesScreen() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setCategories(await wallpaperService.categories());
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Bilinmeyen API hatası');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <Screen>
      <PageHeader
        eyebrow="LIBRARY"
        title="Kategoriler"
        subtitle="Kategoriler doğrudan /api/categories.php endpoint'inden gelir."
      />

      <AsyncState loading={loading} error={error} onRetry={load} />

      {!loading && !error ? (
        <View style={styles.list}>
          {categories.map((category) => (
            <Pressable
              key={category.slug}
              style={styles.item}
              onPress={() => router.push(`/category/${encodeURIComponent(category.slug)}`)}
            >
              <View>
                <Text style={styles.name}>{category.name}</Text>
                <Text style={styles.slug}>/{category.slug}</Text>
              </View>
              <View style={styles.right}>
                {typeof category.count === 'number' ? (
                  <Text style={styles.count}>{category.count}</Text>
                ) : null}
                <Text style={styles.arrow}>›</Text>
              </View>
            </Pressable>
          ))}
          {categories.length === 0 ? <Text style={styles.empty}>Kategori bulunamadı.</Text> : null}
        </View>
      ) : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  list: {
    gap: theme.spacing.sm
  },
  item: {
    minHeight: 80,
    padding: theme.spacing.md,
    borderRadius: theme.radius.md,
    backgroundColor: theme.colors.surface,
    borderWidth: 1,
    borderColor: theme.colors.border,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  name: {
    color: theme.colors.text,
    fontSize: 17,
    fontWeight: '900'
  },
  slug: {
    marginTop: 4,
    color: theme.colors.textMuted,
    fontSize: 12
  },
  right: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10
  },
  count: {
    color: theme.colors.accent,
    fontWeight: '900'
  },
  arrow: {
    color: theme.colors.textMuted,
    fontSize: 28
  },
  empty: {
    color: theme.colors.textMuted,
    padding: theme.spacing.lg,
    textAlign: 'center'
  }
});
