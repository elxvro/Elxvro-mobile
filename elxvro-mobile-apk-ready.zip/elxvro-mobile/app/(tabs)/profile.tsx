import { Pressable, StyleSheet, Text, View } from 'react-native';
import { PageHeader } from '@/components/PageHeader';
import { Screen } from '@/components/Screen';
import { theme } from '@/constants/theme';
import { useAppFlow } from '@/store/AppFlowContext';

export default function ProfileScreen() {
  const { favorites, resetOnboarding } = useAppFlow();

  return (
    <Screen>
      <PageHeader
        eyebrow="ACCOUNT"
        title="Profil"
        subtitle="Kimlik doğrulama, premium durumu ve kullanıcı ayarları bu akışa bağlanacak."
      />

      <View style={styles.card}>
        <Text style={styles.label}>DURUM</Text>
        <Text style={styles.value}>Guest</Text>
        <Text style={styles.meta}>{favorites.length} favori kayıtlı</Text>
      </View>

      <Pressable accessibilityRole="button" style={styles.button} onPress={resetOnboarding}>
        <Text style={styles.buttonText}>Onboarding'i Tekrar Göster</Text>
      </Pressable>
    </Screen>
  );
}

const styles = StyleSheet.create({
  card: {
    padding: theme.spacing.lg,
    borderRadius: theme.radius.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
    backgroundColor: theme.colors.surface,
    gap: 8,
    marginBottom: theme.spacing.md
  },
  label: {
    color: theme.colors.accent,
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 2
  },
  value: {
    color: theme.colors.text,
    fontSize: 24,
    fontWeight: '800'
  },
  meta: {
    color: theme.colors.textMuted
  },
  button: {
    minHeight: 50,
    borderRadius: theme.radius.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
    alignItems: 'center',
    justifyContent: 'center'
  },
  buttonText: {
    color: theme.colors.text,
    fontWeight: '800'
  }
});
