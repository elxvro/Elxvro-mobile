import { router } from 'expo-router';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { PageHeader } from '@/components/PageHeader';
import { Screen } from '@/components/Screen';
import { theme } from '@/constants/theme';
import { useAppFlow } from '@/store/AppFlowContext';
import { routes } from '@/navigation/flow';

export default function FavoritesScreen() {
  const { favorites } = useAppFlow();

  return (
    <Screen>
      <PageHeader
        eyebrow="SAVED"
        title="Favoriler"
        subtitle="ELXVRO wallpaper kodları cihazdaki uygulama oturumunda favori olarak tutulur."
      />

      {favorites.length === 0 ? (
        <View style={styles.empty}>
          <Text style={styles.title}>Henüz favori yok.</Text>
          <Text style={styles.text}>Bir wallpaper açıp “Favoriye Ekle” seçeneğini kullan.</Text>
        </View>
      ) : (
        <View style={styles.list}>
          {favorites.map((code) => (
            <Pressable key={code} style={styles.item} onPress={() => router.push(routes.wallpaper(code))}>
              <View>
                <Text style={styles.itemEyebrow}>ELXVRO WALLPAPER</Text>
                <Text style={styles.itemTitle}>{code}</Text>
              </View>
              <Text style={styles.arrow}>›</Text>
            </Pressable>
          ))}
        </View>
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  empty: {
    padding: theme.spacing.lg,
    borderRadius: theme.radius.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
    backgroundColor: theme.colors.surface,
    gap: 8
  },
  title: {
    color: theme.colors.text,
    fontSize: 18,
    fontWeight: '800'
  },
  text: {
    color: theme.colors.textMuted,
    lineHeight: 21
  },
  list: {
    gap: theme.spacing.sm
  },
  item: {
    minHeight: 88,
    padding: theme.spacing.md,
    borderRadius: theme.radius.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
    backgroundColor: theme.colors.surface,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  itemEyebrow: {
    color: theme.colors.accent,
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 1.5,
    marginBottom: 6
  },
  itemTitle: {
    color: theme.colors.text,
    fontSize: 18,
    fontWeight: '800'
  },
  arrow: {
    color: theme.colors.textMuted,
    fontSize: 30
  }
});
