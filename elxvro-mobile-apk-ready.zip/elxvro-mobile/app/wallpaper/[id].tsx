import { useLocalSearchParams } from 'expo-router';
import { useCallback, useEffect, useState } from 'react';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { AsyncState } from '@/components/AsyncState';
import { Screen } from '@/components/Screen';
import { theme } from '@/constants/theme';
import { wallpaperService } from '@/services/wallpaper.service';
import { useAppFlow } from '@/store/AppFlowContext';
import type { Wallpaper } from '@/types/wallpaper';

export default function WallpaperDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const wallpaperCode = decodeURIComponent(id ?? '');
  const { isFavorite, toggleFavorite } = useAppFlow();
  const favorite = isFavorite(wallpaperCode);
  const [item, setItem] = useState<Wallpaper | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!wallpaperCode) return;
    setLoading(true);
    setError(null);
    try {
      setItem(await wallpaperService.getByCode(wallpaperCode));
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Bilinmeyen API hatası');
    } finally {
      setLoading(false);
    }
  }, [wallpaperCode]);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <Screen>
      <AsyncState loading={loading} error={error} onRetry={load} />

      {!loading && !error && item ? (
        <>
          <View style={styles.preview}>
            {item.previewUrl || item.thumbUrl ? (
              <Image
                source={{ uri: item.previewUrl || item.thumbUrl }}
                style={styles.image}
                resizeMode="cover"
              />
            ) : (
              <Text style={styles.previewLabel}>ELXVRO PREVIEW</Text>
            )}
          </View>

          <Text style={styles.eyebrow}>{item.category?.name ?? 'WALLPAPER'}</Text>
          <Text style={styles.title}>{item.code}</Text>

          <View style={styles.metaGrid}>
            <Meta label="Çözünürlük" value={item.width && item.height ? `${item.width} × ${item.height}` : '—'} />
            <Meta label="Görüntülenme" value={String(item.views)} />
            <Meta label="Favori" value={String(item.favorites)} />
            <Meta label="Yön" value={item.orientation ?? '—'} />
          </View>

          <Pressable
            accessibilityRole="button"
            style={[styles.button, favorite && styles.buttonActive]}
            onPress={() => toggleFavorite(wallpaperCode)}
          >
            <Text style={[styles.buttonText, favorite && styles.buttonTextActive]}>
              {favorite ? 'Favorilerden Çıkar' : 'Favoriye Ekle'}
            </Text>
          </Pressable>

          {!item.downloadEnabled ? (
            <Text style={styles.note}>Bu wallpaper için API şu anda indirmeyi kapalı bildiriyor.</Text>
          ) : null}
        </>
      ) : null}
    </Screen>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.metaItem}>
      <Text style={styles.metaLabel}>{label}</Text>
      <Text style={styles.metaValue}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  preview: {
    aspectRatio: 0.56,
    maxHeight: 560,
    marginTop: theme.spacing.md,
    marginBottom: theme.spacing.lg,
    borderRadius: theme.radius.lg,
    backgroundColor: theme.colors.surfaceMuted,
    borderWidth: 1,
    borderColor: theme.colors.border,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center'
  },
  image: {
    width: '100%',
    height: '100%'
  },
  previewLabel: {
    color: theme.colors.accent,
    fontWeight: '900',
    letterSpacing: 2
  },
  eyebrow: {
    color: theme.colors.accent,
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 1.5,
    marginBottom: 6
  },
  title: {
    color: theme.colors.text,
    fontSize: 28,
    fontWeight: '900',
    marginBottom: theme.spacing.md
  },
  metaGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: theme.spacing.lg
  },
  metaItem: {
    width: '47%',
    padding: theme.spacing.md,
    borderRadius: theme.radius.md,
    backgroundColor: theme.colors.surface,
    borderWidth: 1,
    borderColor: theme.colors.border
  },
  metaLabel: {
    color: theme.colors.textMuted,
    fontSize: 11,
    marginBottom: 5
  },
  metaValue: {
    color: theme.colors.text,
    fontWeight: '900'
  },
  button: {
    minHeight: 52,
    borderRadius: theme.radius.md,
    borderWidth: 1,
    borderColor: theme.colors.accent,
    alignItems: 'center',
    justifyContent: 'center'
  },
  buttonActive: {
    backgroundColor: theme.colors.accent
  },
  buttonText: {
    color: theme.colors.accent,
    fontWeight: '900'
  },
  buttonTextActive: {
    color: theme.colors.accentText
  },
  note: {
    color: theme.colors.textMuted,
    fontSize: 12,
    lineHeight: 18,
    marginTop: 12,
    textAlign: 'center'
  }
});
