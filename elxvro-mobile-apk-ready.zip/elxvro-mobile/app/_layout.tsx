import 'react-native-gesture-handler';
import { Stack, router, useSegments } from 'expo-router';
import { useEffect } from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { theme } from '@/constants/theme';
import { AppFlowProvider, useAppFlow } from '@/store/AppFlowContext';

function RootNavigator() {
  const segments = useSegments();
  const { onboardingCompleted } = useAppFlow();

  useEffect(() => {
    const isOnboarding = segments[0] === 'onboarding';

    if (!onboardingCompleted && !isOnboarding) {
      router.replace('/onboarding');
      return;
    }

    if (onboardingCompleted && isOnboarding) {
      router.replace('/');
    }
  }, [onboardingCompleted, segments]);

  return (
    <Stack
      screenOptions={{
        headerStyle: { backgroundColor: theme.colors.background },
        headerTintColor: theme.colors.text,
        contentStyle: { backgroundColor: theme.colors.background }
      }}
    >
      <Stack.Screen name="onboarding" options={{ headerShown: false }} />
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen name="wallpaper/[id]" options={{ title: 'Wallpaper' }} />
      <Stack.Screen name="category/[slug]" options={{ title: 'Kategori' }} />
    </Stack>
  );
}

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <AppFlowProvider>
        <StatusBar style="light" />
        <RootNavigator />
      </AppFlowProvider>
    </SafeAreaProvider>
  );
}
