import { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Screen } from '@/components/Screen';
import { theme } from '@/constants/theme';
import { useAppFlow } from '@/store/AppFlowContext';

const steps = [
  {
    eyebrow: '01 / DISCOVER',
    title: 'ELXVRO dünyasını keşfet.',
    text: 'Yeni, öne çıkan ve kategori bazlı wallpaper koleksiyonlarına tek akıştan ulaş.'
  },
  {
    eyebrow: '02 / SAVE',
    title: 'Beğendiklerini kaydet.',
    text: 'Wallpaper detayından favoriye ekle; Favoriler sekmesinde tek yerde yönet.'
  },
  {
    eyebrow: '03 / PERSONALIZE',
    title: 'Deneyimini kişiselleştir.',
    text: 'Profil, hesap ve premium akışları aynı navigasyon mimarisine bağlanmaya hazır.'
  }
] as const;

export default function OnboardingScreen() {
  const [step, setStep] = useState(0);
  const { completeOnboarding } = useAppFlow();
  const current = steps[step];
  const isLast = step === steps.length - 1;

  return (
    <Screen>
      <View style={styles.page}>
        <View style={styles.brandRow}>
          <Text style={styles.brand}>ELXVRO</Text>
          <Text style={styles.counter}>{step + 1}/{steps.length}</Text>
        </View>

        <View style={styles.visual}>
          <Text style={styles.visualText}>ELXVRO MOBILE</Text>
        </View>

        <View style={styles.copy}>
          <Text style={styles.eyebrow}>{current.eyebrow}</Text>
          <Text style={styles.title}>{current.title}</Text>
          <Text style={styles.text}>{current.text}</Text>
        </View>

        <View style={styles.footer}>
          <View style={styles.dots}>
            {steps.map((_, index) => (
              <View key={index} style={[styles.dot, index === step && styles.dotActive]} />
            ))}
          </View>

          <Pressable
            accessibilityRole="button"
            style={styles.button}
            onPress={() => {
              if (isLast) {
                completeOnboarding();
              } else {
                setStep((currentStep) => currentStep + 1);
              }
            }}
          >
            <Text style={styles.buttonText}>{isLast ? 'Uygulamaya Gir' : 'Devam Et'}</Text>
          </Pressable>
        </View>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  page: {
    flex: 1,
    minHeight: 680,
    paddingTop: theme.spacing.lg,
    paddingBottom: theme.spacing.lg,
    justifyContent: 'space-between',
    gap: theme.spacing.lg
  },
  brandRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  brand: {
    color: theme.colors.text,
    fontSize: 18,
    fontWeight: '900',
    letterSpacing: 3
  },
  counter: {
    color: theme.colors.textMuted,
    fontWeight: '800'
  },
  visual: {
    minHeight: 280,
    borderRadius: theme.radius.lg,
    borderWidth: 1,
    borderColor: theme.colors.border,
    backgroundColor: theme.colors.surfaceMuted,
    alignItems: 'center',
    justifyContent: 'center'
  },
  visualText: {
    color: theme.colors.accent,
    fontWeight: '900',
    letterSpacing: 3
  },
  copy: {
    gap: 12
  },
  eyebrow: {
    color: theme.colors.accent,
    fontSize: 12,
    fontWeight: '900',
    letterSpacing: 2
  },
  title: {
    color: theme.colors.text,
    fontSize: 34,
    lineHeight: 38,
    fontWeight: '900'
  },
  text: {
    color: theme.colors.textMuted,
    fontSize: 16,
    lineHeight: 24
  },
  footer: {
    gap: theme.spacing.md
  },
  dots: {
    flexDirection: 'row',
    gap: 8
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 99,
    backgroundColor: theme.colors.border
  },
  dotActive: {
    width: 28,
    backgroundColor: theme.colors.accent
  },
  button: {
    minHeight: 56,
    borderRadius: theme.radius.md,
    backgroundColor: theme.colors.accent,
    alignItems: 'center',
    justifyContent: 'center'
  },
  buttonText: {
    color: theme.colors.accentText,
    fontSize: 16,
    fontWeight: '900'
  }
});
