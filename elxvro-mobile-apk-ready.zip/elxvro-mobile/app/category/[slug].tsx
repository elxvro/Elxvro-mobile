import { useLocalSearchParams } from 'expo-router';
import { useCallback, useEffect, useState } from 'react';
import { AsyncState } from '@/components/AsyncState';
import { PageHeader } from '@/components/PageHeader';
import { Screen } from '@/components/Screen';
import { WallpaperGrid } from '@/components/WallpaperGrid';
import { wallpaperService } from '@/services/wallpaper.service';
import type { Wallpaper } from '@/types/wallpaper';

export default function CategoryDetailScreen() {
  const { slug } = useLocalSearchParams<{ slug: string }>();
  const categorySlug = decodeURIComponent(slug ?? '');
  const [items, setItems] = useState<Wallpaper[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!categorySlug) return;
    setLoading(true);
    setError(null);
    try {
      const result = await wallpaperService.byCategory(categorySlug, 1, 24);
      setItems(result.data);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Bilinmeyen API hatası');
    } finally {
      setLoading(false);
    }
  }, [categorySlug]);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <Screen>
      <PageHeader
        eyebrow="CATEGORY"
        title={categorySlug || 'Kategori'}
        subtitle="Bu kategorideki mobil wallpaper'lar ELXVRO API üzerinden yüklenir."
      />
      <AsyncState loading={loading} error={error} onRetry={load} />
      {!loading && !error ? (
        <WallpaperGrid items={items} emptyText="Bu kategoride mobil wallpaper bulunamadı." />
      ) : null}
    </Screen>
  );
}
