# ELXVRO Mobile

Expo + React Native + TypeScript + Expo Router tabanlı ELXVRO mobil uygulaması.

## Gerçek API bağlantısı

Proje varsayılan olarak production API'ye bağlıdır:

```text
https://elxvro.com/api
```

Kullanılan endpointler:

```text
GET /wallpapers.php?device=mobile&page=1&limit=24&sort=new
GET /categories.php
GET /wallpaper.php?code=ELX-...
GET /status.php
```

`thumb` ve `preview` gibi `/media.php?...` biçimindeki göreli görsel yolları otomatik olarak `https://elxvro.com` alan adına çevrilir.

## Kurulum

Node.js 22 kullanın.

```bash
npm install
npm start
```

Android için Expo Go ile QR kodu okutabilir veya:

```bash
npm run android
```

kullanabilirsiniz.

## API adresini değiştirme

Gerekirse `.env.example` dosyasını `.env` olarak kopyalayın:

```env
EXPO_PUBLIC_API_BASE_URL=https://elxvro.com/api
```

`.env` Git'e dahil edilmez.

## Akış

```text
Onboarding
   ↓
Ana Sayfa ──→ Wallpaper Detay ──→ Favoriye Ekle
   │
   ├── Keşfet ──→ Wallpaper Detay
   ├── Kategoriler ──→ Kategori ──→ Wallpaper Detay
   ├── Favoriler ──→ Wallpaper Detay
   └── Profil
```

## Not

Onboarding ve favoriler bu başlangıç sürümünde uygulama belleğinde tutulur. Kalıcı favoriler/kullanıcı hesabı için sonraki aşamada local storage veya ELXVRO kullanıcı API'si bağlanmalıdır.

## Android APK build (GitHub Actions + EAS)

APK profile is defined in `eas.json`. The workflow is in `.github/workflows/build-apk.yml`.

One-time setup:

```bash
npx eas-cli@latest login
npx eas-cli@latest init
npx eas-cli@latest build --platform android --profile apk
```

Accept EAS-managed Android signing credentials during the first interactive build. Commit the `app.json` change created by `eas init` (it adds the EAS project id).

Then create an Expo access token and save it in the GitHub repository as an Actions secret named `EXPO_TOKEN`.

After that, open GitHub → Actions → **Build ELXVRO Android APK** → **Run workflow**. When the run finishes, `ELXVRO.apk` is available from the workflow artifacts.
