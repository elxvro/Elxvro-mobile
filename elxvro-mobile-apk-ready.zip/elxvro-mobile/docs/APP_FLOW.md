# ELXVRO Mobile Application Flow

## Production API

Base URL: `https://elxvro.com/api`

- Home: `wallpapers.php?device=mobile&sort=new`
- Explore: `wallpapers.php?device=mobile&sort=<new|popular|random>`
- Categories: `categories.php`
- Category detail: `wallpapers.php?device=mobile&category=<slug>`
- Wallpaper detail: `wallpaper.php?code=<code>&device=mobile`

## Navigation

```text
Launch
  ↓
Onboarding
  ↓
Tabs
  ├── Home ────────┐
  ├── Explore ─────┼──→ Wallpaper Detail ──→ Favorite toggle
  ├── Categories ──→ Category Detail ──────→ Wallpaper Detail
  ├── Favorites ───────────────────────────→ Wallpaper Detail
  └── Profile
```
