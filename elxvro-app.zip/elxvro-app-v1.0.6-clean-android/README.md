# ELXVRO App v1.0.6

This ZIP intentionally contains no `android/` directory.
The GitHub Actions workflow must delete any extracted Android folder and run `flutter create --platforms=android ...` before building.

API: https://www.elxvro.com/api/v1/
Wallpaper feed: wallpapers.php?device=mobile
