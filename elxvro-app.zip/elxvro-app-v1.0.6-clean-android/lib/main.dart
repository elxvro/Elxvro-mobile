import 'package:flutter/material.dart';

import 'config/app_config.dart';
import 'screens/shell_screen.dart';
import 'theme/app_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ElxvroApp());
}

class ElxvroApp extends StatelessWidget {
  const ElxvroApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConfig.appName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark(),
      home: const ShellScreen(),
    );
  }
}
