# ELXVRO Mobile v1.1.8 — Wallpaper Resolve Fix

- Kategori listesinden gelen tek URL'ye bagimlilik kaldirildi.
- Detay ekraninda `wallpaper.php?id/slug` ile tam kayit cozulur.
- `download_url`, `original_url`, `image_url`, `file_url` ve thumbnail adaylari sirayla denenir.
- Wallpaper Fast, kategori tamamlama, native Google giris ve performans cache sistemi korunur.
- Native indirmede Referer/Accept basliklari ve daha toleransli gorsel boyutu kontrolu kullanilir.
