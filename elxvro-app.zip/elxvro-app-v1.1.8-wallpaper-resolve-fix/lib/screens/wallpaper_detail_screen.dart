import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';

import '../models/wallpaper.dart';
import '../services/api_service.dart';
import '../services/wallpaper_service.dart';
import '../theme/app_theme.dart';
import '../widgets/fast_network_image.dart';

class WallpaperDetailScreen extends StatefulWidget {
  const WallpaperDetailScreen({
    super.key,
    required this.wallpaper,
  });

  final Wallpaper wallpaper;

  @override
  State<WallpaperDetailScreen> createState() => _WallpaperDetailScreenState();
}

class _WallpaperDetailScreenState extends State<WallpaperDetailScreen> {
  final ApiService _api = const ApiService();
  final WallpaperService _wallpaperService = const WallpaperService();
  bool _settingWallpaper = false;
  bool _prepareFinished = false;
  String? _preparedPath;
  String? _workingUrl;
  late Wallpaper _resolvedWallpaper;
  late final Future<String?> _prepareFuture;

  @override
  void initState() {
    super.initState();
    _resolvedWallpaper = widget.wallpaper;
    _prepareFuture = _prepareWallpaper();
    unawaited(_prepareFuture);
  }

  Future<String?> _prepareWallpaper() async {
    try {
      _resolvedWallpaper = await _api.fetchWallpaperDetail(widget.wallpaper);

      for (final String url in _resolvedWallpaper.wallpaperUrls) {
        final String? path = await _wallpaperService.prepareFromUrl(url);
        if (path == null || path.isEmpty) continue;
        final File file = File(path);
        if (!await file.exists() || await file.length() <= 1024) continue;

        _workingUrl = url;
        if (mounted) {
          setState(() {
            _preparedPath = path;
            _prepareFinished = true;
          });
        }
        return path;
      }
      return null;
    } finally {
      if (mounted && !_prepareFinished) {
        setState(() => _prepareFinished = true);
      }
    }
  }

  Future<void> _setUsingCandidates(WallpaperTarget target) async {
    Object? lastError;
    final List<String> urls = <String>[];
    void add(String? value) {
      final String clean = value?.trim() ?? '';
      if (clean.isNotEmpty && !urls.contains(clean)) urls.add(clean);
    }

    add(_workingUrl);
    for (final String url in _resolvedWallpaper.wallpaperUrls) {
      add(url);
    }
    for (final String url in widget.wallpaper.wallpaperUrls) {
      add(url);
    }

    for (final String url in urls) {
      try {
        await _wallpaperService.setFromUrl(imageUrl: url, target: target);
        _workingUrl = url;
        return;
      } catch (error) {
        lastError = error;
      }
    }

    if (lastError != null) throw lastError;
    throw Exception('Duvar kağıdı için kullanılabilir görsel adresi bulunamadı.');
  }

  Future<void> _chooseAndSetWallpaper() async {
    final WallpaperTarget? target = await showModalBottomSheet<WallpaperTarget>(
      context: context,
      backgroundColor: AppTheme.surface,
      showDragHandle: true,
      builder: (BuildContext sheetContext) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                const Padding(
                  padding: EdgeInsets.fromLTRB(8, 4, 8, 14),
                  child: Text(
                    'Nereye uygulansın?',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                  ),
                ),
                _TargetTile(
                  icon: Icons.home_rounded,
                  title: 'Ana ekran',
                  subtitle: 'Sadece telefonun ana ekranı',
                  onTap: () => Navigator.pop(sheetContext, WallpaperTarget.home),
                ),
                const SizedBox(height: 8),
                _TargetTile(
                  icon: Icons.lock_rounded,
                  title: 'Kilit ekranı',
                  subtitle: 'Sadece kilit ekranı',
                  onTap: () => Navigator.pop(sheetContext, WallpaperTarget.lock),
                ),
                const SizedBox(height: 8),
                _TargetTile(
                  icon: Icons.phone_android_rounded,
                  title: 'İkisi birden',
                  subtitle: 'Ana ekran ve kilit ekranı',
                  onTap: () => Navigator.pop(sheetContext, WallpaperTarget.both),
                ),
              ],
            ),
          ),
        );
      },
    );

    if (target == null || !mounted) return;
    setState(() => _settingWallpaper = true);

    try {
      final String? preparedPath = _preparedPath ?? await _prepareFuture;
      if (preparedPath != null &&
          preparedPath.isNotEmpty &&
          await File(preparedPath).exists()) {
        await _wallpaperService.setPrepared(
          preparedPath: preparedPath,
          target: target,
        );
      } else {
        await _setUsingCandidates(target);
      }

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Duvar kağıdı başarıyla uygulandı.'),
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (error) {
      if (!mounted) return;
      final String message = error.toString().replaceFirst('Exception: ', '');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          behavior: SnackBarBehavior.floating,
        ),
      );
    } finally {
      if (mounted) setState(() => _settingWallpaper = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final String? localPath = _preparedPath;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: const Color(0x66000000),
        leading: IconButton.filledTonal(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_rounded),
        ),
        title: Text(
          _resolvedWallpaper.category,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          const ColoredBox(color: Colors.black),
          InteractiveViewer(
            minScale: 1,
            maxScale: 4,
            child: localPath != null
                ? Image.file(
                    File(localPath),
                    fit: BoxFit.cover,
                    gaplessPlayback: true,
                    filterQuality: FilterQuality.medium,
                  )
                : FastNetworkImage(
                    url: _resolvedWallpaper.thumbnailUrl,
                    fit: BoxFit.cover,
                    diskCacheWidth: 1080,
                  ),
          ),
          if (localPath == null)
            Positioned(
              left: 0,
              right: 0,
              bottom: 104,
              child: Center(
                child: DecoratedBox(
                  decoration: const BoxDecoration(
                    color: Color(0x99000000),
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                    child: Text(
                      _prepareFinished
                          ? 'Tam görsel uygulama sırasında hazırlanacak'
                          : 'Duvar kağıdı hazırlanıyor…',
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                    ),
                  ),
                ),
              ),
            ),
          Positioned(
            left: 16,
            right: 16,
            bottom: 24,
            child: SafeArea(
              top: false,
              child: FilledButton.icon(
                onPressed: _settingWallpaper ? null : _chooseAndSetWallpaper,
                icon: _settingWallpaper
                    ? const SizedBox.square(
                        dimension: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.wallpaper_rounded),
                label: Text(
                  _settingWallpaper ? 'Uygulanıyor...' : 'Duvar Kağıdı Yap',
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TargetTile extends StatelessWidget {
  const _TargetTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppTheme.surfaceAlt,
      borderRadius: BorderRadius.circular(16),
      child: ListTile(
        onTap: onTap,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        leading: Icon(icon, color: AppTheme.accent),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(subtitle, style: const TextStyle(color: AppTheme.muted)),
        trailing: const Icon(Icons.chevron_right_rounded),
      ),
    );
  }
}
