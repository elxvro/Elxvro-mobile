# ELXVRO Mobile v1.0.5

Bu surum Android release APK ag baglantisi icin duzeltildi.

- Sabit API: https://www.elxvro.com/api/v1/
- Mobil liste: wallpapers.php?device=mobile
- Acilista categories.php kontrolu kaldirildi.
- Android INTERNET izni eklendi.
- Uygulama yalnizca mobil gorsel istemcisidir.

GitHub'da ZIP olarak build ediyorsan repository'deki `.github/workflows/build-apk.yml`
dosyasini bu paketteki `GITHUB_ZIP_BUILD_WORKFLOW.yml` icerigiyle degistir.
Uygulama ZIP'ini repository'de `elxvro-app.zip` adiyla tut.
