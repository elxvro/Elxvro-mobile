# ELXVRO Mobile v1.1.0 Final

Android final paketidir.

## Özellikler

- Yalnızca `device=mobile` duvar kağıtlarını çeker.
- Görsel detay ekranı ve Ana ekran / Kilit ekranı / İkisi birden duvar kağıdı ayarlama.
- Görseli kırpmadan ekran ölçüsüne sığdıran Android WallpaperManager entegrasyonu.
- API tabanlı mobil kategori paneli; yalnızca mobil içeriği olan kategoriler listelenir.
- Google ile giriş mevcut `https://www.elxvro.com/login.php` akışını güvenli sistem tarayıcısında açar.
- Destek paneli mevcut `https://www.elxvro.com/contact.php` hesabına bağlı destek sistemini açar.
- Google giriş ve destek aynı varsayılan tarayıcı oturumunu kullandığından mevcut ELXVRO web oturumu korunur.

## GitHub APK

1. Bu ZIP'i GitHub repository ana dizinine `elxvro-app.zip` adıyla yükleyin.
2. `GITHUB_ZIP_BUILD_WORKFLOW.yml` içeriğini `.github/workflows/build-apk.yml` olarak kullanın.
3. Actions → `ELXVRO Final APK Build` → Run workflow.
4. Artifact: `ELXVRO-FINAL-v1.1.0`.

Bu paket yeni bir Google OAuth istemcisi gerektirmez; mevcut web Google giriş sistemi kullanılır.
