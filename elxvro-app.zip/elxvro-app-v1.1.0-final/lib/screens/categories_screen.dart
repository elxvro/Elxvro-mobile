import 'package:flutter/material.dart';

import '../models/category.dart';
import '../models/wallpaper.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import 'category_wallpapers_screen.dart';

class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key});

  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  final ApiService _api = const ApiService();

  bool _loading = true;
  String? _error;
  List<WallpaperCategory> _categories = const <WallpaperCategory>[];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final List<WallpaperCategory> apiCategories = await _api.fetchCategories();
      final List<Wallpaper> mobile = await _api.fetchMobileWallpapers();

      final Map<String, int> mobileCounts = <String, int>{};
      for (final Wallpaper item in mobile) {
        final String key = _normalize(item.category);
        if (key.isEmpty || key == 'mobil') continue;
        mobileCounts[key] = (mobileCounts[key] ?? 0) + 1;
      }

      final List<WallpaperCategory> visible = <WallpaperCategory>[];
      final Set<String> used = <String>{};

      for (final WallpaperCategory category in apiCategories) {
        final String nameKey = _normalize(category.name);
        final String slugKey = _normalize(category.slug);
        final int derivedCount = mobileCounts[nameKey] ?? mobileCounts[slugKey] ?? 0;
        final int count = category.mobileCount ?? derivedCount;

        if (count <= 0 && derivedCount <= 0) continue;
        if (!used.add(nameKey)) continue;

        visible.add(
          WallpaperCategory(
            id: category.id,
            name: category.name,
            slug: category.slug,
            icon: category.icon,
            coverUrl: category.coverUrl,
            mobileCount: count > 0 ? count : derivedCount,
          ),
        );
      }

      if (visible.isEmpty) {
        for (final MapEntry<String, int> entry in mobileCounts.entries) {
          visible.add(
            WallpaperCategory(
              id: entry.key,
              name: _displayName(entry.key),
              slug: entry.key,
              mobileCount: entry.value,
            ),
          );
        }
      }

      visible.sort((WallpaperCategory a, WallpaperCategory b) {
        final int byCount = (b.mobileCount ?? 0).compareTo(a.mobileCount ?? 0);
        return byCount != 0 ? byCount : a.name.compareTo(b.name);
      });

      if (!mounted) return;
      setState(() => _categories = visible);
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString().replaceFirst('Exception: ', '');
      });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _normalize(String value) {
    String text = value.toLowerCase().trim();
    const Map<String, String> replacements = <String, String>{
      'ç': 'c',
      'ğ': 'g',
      'ı': 'i',
      'ö': 'o',
      'ş': 's',
      'ü': 'u',
    };
    replacements.forEach((String from, String to) {
      text = text.replaceAll(from, to);
    });
    return text.replaceAll(RegExp(r'[^a-z0-9]+'), '-').replaceAll(RegExp(r'^-+|-+$'), '');
  }

  String _displayName(String slug) {
    if (slug.isEmpty) return 'Kategori';
    return slug
        .split('-')
        .where((String part) => part.isNotEmpty)
        .map((String part) => '${part[0].toUpperCase()}${part.substring(1)}')
        .join(' ');
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 110),
        children: <Widget>[
          const Text(
            'KATEGORİLER',
            style: TextStyle(
              color: AppTheme.accent,
              fontSize: 12,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.7,
            ),
          ),
          const SizedBox(height: 5),
          const Text(
            'Tarzını seç.',
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 6),
          const Text(
            'Yalnızca mobil duvar kağıdı bulunan kategoriler gösterilir.',
            style: TextStyle(color: AppTheme.muted, height: 1.4),
          ),
          const SizedBox(height: 20),
          if (_loading)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 80),
              child: Center(child: CircularProgressIndicator()),
            )
          else if (_error != null)
            _CategoryError(message: _error!, onRetry: _load)
          else if (_categories.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 70),
              child: Center(
                child: Text(
                  'Mobil içerikli kategori bulunamadı.',
                  style: TextStyle(color: AppTheme.muted),
                ),
              ),
            )
          else
            LayoutBuilder(
              builder: (BuildContext context, BoxConstraints constraints) {
                final int columns = constraints.maxWidth >= 700 ? 3 : 2;
                return GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: _categories.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: columns,
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: 1.05,
                  ),
                  itemBuilder: (BuildContext context, int index) {
                    final WallpaperCategory category = _categories[index];
                    return _CategoryCard(category: category);
                  },
                );
              },
            ),
        ],
      ),
    );
  }
}

class _CategoryCard extends StatelessWidget {
  const _CategoryCard({required this.category});

  final WallpaperCategory category;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppTheme.surfaceAlt,
      borderRadius: BorderRadius.circular(20),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (_) => CategoryWallpapersScreen(category: category),
            ),
          );
        },
        child: Stack(
          fit: StackFit.expand,
          children: <Widget>[
            if (category.coverUrl != null)
              Image.network(
                category.coverUrl!,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const SizedBox.shrink(),
              ),
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: <Color>[Color(0x22000000), Color(0xEE000000)],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(15),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.end,
                children: <Widget>[
                  Text(
                    category.icon?.trim().isNotEmpty == true ? category.icon! : '✦',
                    style: const TextStyle(fontSize: 22),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    category.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    '${category.mobileCount ?? 0} mobil görsel',
                    style: const TextStyle(color: AppTheme.muted, fontSize: 12),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CategoryError extends StatelessWidget {
  const _CategoryError({required this.message, required this.onRetry});

  final String message;
  final Future<void> Function() onRetry;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 60),
      child: Column(
        children: <Widget>[
          const Icon(Icons.cloud_off_rounded, size: 42, color: AppTheme.muted),
          const SizedBox(height: 12),
          Text(message, textAlign: TextAlign.center),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: () => onRetry(),
            icon: const Icon(Icons.refresh_rounded),
            label: const Text('Tekrar Dene'),
          ),
        ],
      ),
    );
  }
}
