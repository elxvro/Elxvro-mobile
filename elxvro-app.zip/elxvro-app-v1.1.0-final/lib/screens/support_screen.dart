import 'package:flutter/material.dart';

import '../config/app_config.dart';
import '../services/browser_service.dart';
import '../theme/app_theme.dart';

class SupportScreen extends StatelessWidget {
  const SupportScreen({super.key});

  static const BrowserService _browser = BrowserService();

  Future<void> _open(BuildContext context, String url) async {
    try {
      await _browser.open(url);
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString().replaceFirst('Exception: ', ''))),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 110),
      children: <Widget>[
        const Text(
          'DESTEK',
          style: TextStyle(
            color: AppTheme.accent,
            fontSize: 12,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.7,
          ),
        ),
        const SizedBox(height: 5),
        const Text(
          'Destek Merkezi',
          style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 7),
        const Text(
          'Talep oluştur, yönetici yanıtlarını gör ve aynı konuşmadan devam et.',
          style: TextStyle(color: AppTheme.muted, height: 1.45),
        ),
        const SizedBox(height: 22),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                const Row(
                  children: <Widget>[
                    CircleAvatar(
                      backgroundColor: AppTheme.surfaceAlt,
                      child: Icon(Icons.support_agent_rounded, color: AppTheme.accent),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Site içi destek hesabına bağlıdır',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                const Text(
                  'Google hesabınla giriş yaptıktan sonra yeni destek talebi oluşturabilir, önceki taleplerini görebilir ve yanıtlayabilirsin.',
                  style: TextStyle(color: AppTheme.muted, height: 1.45),
                ),
                const SizedBox(height: 18),
                FilledButton.icon(
                  onPressed: () => _open(context, AppConfig.supportUrl),
                  icon: const Icon(Icons.forum_rounded),
                  label: const Text('Destek Panelini Aç'),
                ),
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed: () => _open(context, AppConfig.loginUrl),
                  icon: const Icon(Icons.login_rounded),
                  label: const Text('Önce Google ile Giriş Yap'),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        const Card(
          child: Padding(
            padding: EdgeInsets.all(18),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Icon(Icons.verified_user_outlined, color: AppTheme.accent),
                SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Giriş ve destek sayfaları elxvro.com üzerinde açılır. Uygulama Google şifresini görmez veya saklamaz.',
                    style: TextStyle(color: AppTheme.muted, height: 1.45),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
