import 'package:flutter/material.dart';

import '../config/app_config.dart';
import '../services/browser_service.dart';
import '../theme/app_theme.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  static const BrowserService _browser = BrowserService();

  Future<void> _open(BuildContext context, String url) async {
    try {
      await _browser.open(url);
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString().replaceFirst('Exception: ', ''))),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 110),
      children: <Widget>[
        const CircleAvatar(
          radius: 38,
          backgroundColor: AppTheme.surfaceAlt,
          child: Text(
            'G',
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900),
          ),
        ),
        const SizedBox(height: 14),
        const Center(
          child: Text(
            'ELXVRO Hesabı',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
          ),
        ),
        const SizedBox(height: 6),
        const Center(
          child: Text(
            'Web hesabınla aynı Google girişini kullan.',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppTheme.muted),
          ),
        ),
        const SizedBox(height: 24),
        FilledButton.icon(
          onPressed: () => _open(context, AppConfig.loginUrl),
          icon: const Icon(Icons.login_rounded),
          label: const Text('Google ile Giriş Yap'),
          style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54)),
        ),
        const SizedBox(height: 10),
        const Text(
          'Giriş güvenli varsayılan tarayıcıda açılır. Google şifren uygulamaya verilmez; mevcut ELXVRO web oturumun kullanılır.',
          style: TextStyle(color: AppTheme.muted, height: 1.45, fontSize: 12.5),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 22),
        Card(
          child: Column(
            children: <Widget>[
              ListTile(
                leading: const Icon(Icons.support_agent_rounded),
                title: const Text('Destek Merkezi'),
                subtitle: const Text('Hesabına bağlı destek konuşmalarını aç'),
                trailing: const Icon(Icons.open_in_new_rounded),
                onTap: () => _open(context, AppConfig.supportUrl),
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.privacy_tip_outlined),
                title: const Text('Gizlilik Politikası'),
                trailing: const Icon(Icons.open_in_new_rounded),
                onTap: () => _open(context, AppConfig.privacyUrl),
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.description_outlined),
                title: const Text('Kullanım Koşulları'),
                trailing: const Icon(Icons.open_in_new_rounded),
                onTap: () => _open(context, AppConfig.termsUrl),
              ),
              const Divider(height: 1),
              const ListTile(
                leading: Icon(Icons.info_outline_rounded),
                title: Text('Uygulama sürümü'),
                trailing: Text(
                  AppConfig.version,
                  style: TextStyle(color: AppTheme.muted),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
