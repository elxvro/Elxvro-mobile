class AppConfig {
  const AppConfig._();

  static const String appName = 'ELXVRO';
  static const String version = '1.1.0 Final';

  static const String siteBaseUrl = 'https://www.elxvro.com/';
  static const String apiBaseUrl = 'https://www.elxvro.com/api/v1';

  static const String loginUrl = 'https://www.elxvro.com/login.php';
  static const String supportUrl = 'https://www.elxvro.com/contact.php';
  static const String privacyUrl = 'https://www.elxvro.com/privacy.php';
  static const String termsUrl = 'https://www.elxvro.com/terms.php';
  static const String kvkkUrl = 'https://www.elxvro.com/kvkk.php';

  static const String categoriesEndpoint = 'categories.php';
  static const String wallpapersEndpoint = 'wallpapers.php';

  static Uri get categoriesUri => Uri.parse('$apiBaseUrl/$categoriesEndpoint');

  static Uri mobileWallpapersUri({String? category}) {
    final Map<String, String> params = <String, String>{'device': 'mobile'};
    final String normalized = category?.trim() ?? '';
    if (normalized.isNotEmpty) params['category'] = normalized;

    return Uri.parse('$apiBaseUrl/$wallpapersEndpoint').replace(
      queryParameters: params,
    );
  }
}
