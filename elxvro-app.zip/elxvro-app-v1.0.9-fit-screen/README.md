# ELXVRO App v1.0.9 — Fit Screen

Bu sürümde Android duvar kağıdı uygulama yöntemi güncellendi.

- Görsel önce telefonun gerçek ekran çözünürlüğüne hazırlanır.
- `BoxFit.contain` benzeri fit-center kullanılır: görsel kırpılmaz, esnetilmez.
- Android `WallpaperManager.setBitmap` ve tam ekran `visibleCropHint` kullanılır.
- Ana ekran / kilit ekranı / ikisi birden desteği korunur.
- Görselin en-boy oranı telefondan farklıysa tamamını korumak için boş kalan alan siyah olabilir.

GitHub'a bu ZIP'i `elxvro-app.zip` adıyla yükleyin. `GITHUB_ZIP_BUILD_WORKFLOW.yml` içeriğini `.github/workflows/build-apk.yml` olarak kullanın.
