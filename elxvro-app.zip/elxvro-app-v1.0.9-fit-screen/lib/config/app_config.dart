class AppConfig {
  const AppConfig._();

  static const String appName = 'ELXVRO';
  static const String version = '1.0.8';

  static const String siteBaseUrl = 'https://www.elxvro.com/';
  static const String apiBaseUrl = 'https://www.elxvro.com/api/v1';

  static const String categoriesEndpoint = 'categories.php';
  static const String wallpapersEndpoint = 'wallpapers.php';

  static Uri get categoriesUri => Uri.parse('$apiBaseUrl/$categoriesEndpoint');

  // Mobil uygulama yalnızca mobil duvar kağıtlarını ister.
  static Uri get mobileWallpapersUri => Uri.parse(
        '$apiBaseUrl/$wallpapersEndpoint',
      ).replace(queryParameters: const <String, String>{'device': 'mobile'});
}
