class Wallpaper {
  const Wallpaper({
    required this.id,
    required this.title,
    required this.imageUrl,
    required this.thumbnailUrl,
    required this.category,
    this.categoryKeys = const <String>[],
  });

  final String id;
  final String title;
  final String imageUrl;
  final String thumbnailUrl;
  final String category;

  /// API kategori bilgisini ad/slug/id veya coklu kategori seklinde
  /// dondurebilir. Yerel fallback filtrelemede tum anahtarlar kullanilir.
  final List<String> categoryKeys;
}
