# ELXVRO Mobile v1.1.7 — Category Complete Fix

- Kategori detayinda tek canonical `category=<slug>` API istegi kullanilir.
- v1.1.5'te 403 tetikleyebilen coklu kategori denemeleri yoktur.
- Ana mobil liste sinirli olsa bile kategori endpoint'i once kullanilir.
- Kategori endpoint'i bos/hata verirse genel mobil cache'e sessiz fallback yapilir.
- `category_id`, `category_slug`, `category_name` ve `categories:[...]` gibi farkli kategori formatlari yerel filtrede birlikte desteklenir.
- v1.1.4 Wallpaper Fast, native Google login ve mevcut performans optimizasyonlari korunur.
