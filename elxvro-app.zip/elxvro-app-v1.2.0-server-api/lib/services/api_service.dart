import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../config/app_config.dart';
import '../models/category.dart';
import '../models/wallpaper.dart';

class ApiService {
  const ApiService();

  static final http.Client _client = http.Client();
  static final Map<String, String> _memoryBodies = <String, String>{};
  static final Map<String, int> _memoryTimes = <String, int>{};

  Future<List<WallpaperCategory>> fetchCategories({bool forceRefresh = false}) async {
    final String body = await _fetchBody(
      AppConfig.categoriesUri,
      cacheTtl: const Duration(minutes: 30),
      timeout: const Duration(seconds: 20),
      forceRefresh: forceRefresh,
      errorLabel: 'Kategoriler',
    );

    final dynamic decoded = await _decode(body, 'Kategori API geçersiz JSON döndürdü.');
    final List<dynamic> rows = _extractList(
      decoded,
      preferredKeys: const <String>['categories', 'data', 'items', 'results'],
    );

    final List<WallpaperCategory> result = <WallpaperCategory>[];
    for (final dynamic row in rows) {
      if (row is! Map) continue;
      final Map<String, dynamic> item = row.map(
        (dynamic key, dynamic value) => MapEntry(key.toString(), value),
      );

      final String? name = _firstString(
        item,
        const <String>['name', 'title', 'category_name', 'category'],
      );
      if (name == null || name.isEmpty) continue;

      final String slug = _firstString(
            item,
            const <String>['slug', 'code', 'key', 'category_slug'],
          ) ??
          _slugify(name);

      final int? mobileCount = _firstInt(
            item,
            const <String>[
              'mobile_count',
              'mobileCount',
              'mobile_total',
              'mobileTotal',
              'mobile',
            ],
          ) ??
          _nestedCount(item, 'mobile');

      final String? rawCover = _firstString(
        item,
        const <String>[
          'cover_url',
          'coverUrl',
          'cover',
          'thumbnail_url',
          'thumbnail',
          'image_url',
          'imageUrl',
          'image',
        ],
      );

      result.add(
        WallpaperCategory(
          id: _firstString(item, const <String>['id', 'category_id']) ?? slug,
          name: name,
          slug: slug,
          icon: _firstString(item, const <String>['icon', 'emoji']),
          coverUrl: rawCover == null ? null : _safeMediaUrl(rawCover),
          mobileCount: mobileCount,
        ),
      );
    }

    return result;
  }

  Future<List<Wallpaper>> fetchMobileWallpapers({
    String? category,
    bool forceRefresh = false,
  }) async {
    final List<Wallpaper> result = <Wallpaper>[];
    final Set<String> seen = <String>{};
    final Set<String> pageFingerprints = <String>{};

    for (int page = 1; page <= AppConfig.wallpapersMaxPages; page++) {
      final Uri uri = AppConfig.mobileWallpapersUri(
        category: category,
        page: page,
        limit: AppConfig.wallpapersPageSize,
      );
      final String body = await _fetchBody(
        uri,
        cacheTtl: const Duration(minutes: 30),
        timeout: const Duration(seconds: 25),
        forceRefresh: forceRefresh,
        errorLabel: 'Görseller',
      );

      final dynamic decoded = await _decode(
        body,
        'Görsel API geçersiz JSON döndürdü.',
      );
      final List<dynamic> rows = _extractList(
        decoded,
        preferredKeys: const <String>[
          'wallpapers',
          'data',
          'items',
          'results',
          'images',
        ],
      );

      if (rows.isEmpty) break;

      final String pageFingerprint = base64Url.encode(
        utf8.encode(jsonEncode(rows)),
      );
      if (!pageFingerprints.add(pageFingerprint)) break;

      for (final dynamic row in rows) {
        if (row is! Map) continue;
        final Map<String, dynamic> item = row.map(
          (dynamic key, dynamic value) => MapEntry(key.toString(), value),
        );

        if (!_isMobileItem(item)) continue;

        final Wallpaper? wallpaper = _wallpaperFromItem(
          item,
          fallbackId: '${page}_${result.length}',
        );
        if (wallpaper == null) continue;

        final String identity = wallpaper.id.trim().isNotEmpty
            ? 'id:${wallpaper.id.trim()}'
            : 'url:${wallpaper.imageUrl}';
        if (!seen.add(identity)) continue;

        result.add(wallpaper);
      }

      // Media Pack mobil olmayan legacy kayitlari filtreleyebilir.
      // Bir sayfada hic ELX-M-* olmasa bile sonraki sayfaya devam edilir.
      // Bos sayfa veya ayni sayfanin tekrari donguyu bitirir.
    }

    return result;
  }

  Future<Wallpaper> fetchWallpaperDetail(Wallpaper fallback) async {
    final String rawId = fallback.id.trim();
    final bool numericId = RegExp(r'^\d+$').hasMatch(rawId);
    final Uri uri = numericId
        ? AppConfig.wallpaperUri(id: rawId)
        : AppConfig.wallpaperUri(slug: rawId);

    try {
      final String body = await _fetchBody(
        uri,
        cacheTtl: const Duration(hours: 1),
        timeout: const Duration(seconds: 20),
        forceRefresh: false,
        errorLabel: 'Görsel detayı',
      );
      final dynamic decoded = await _decode(
        body,
        'Görsel detay API geçersiz JSON döndürdü.',
      );
      final Map<String, dynamic>? item = _extractObject(decoded);
      if (item == null) return fallback;

      final Wallpaper? remote = _wallpaperFromItem(
        item,
        fallbackId: fallback.id,
        fallback: fallback,
      );
      if (remote == null) return fallback;

      final List<String> mergedUrls = <String>[];
      void addUrl(String value) {
        final String clean = value.trim();
        if (clean.isNotEmpty && !mergedUrls.contains(clean)) mergedUrls.add(clean);
      }

      for (final String url in remote.wallpaperUrls) {
        addUrl(url);
      }
      for (final String url in fallback.wallpaperUrls) {
        addUrl(url);
      }

      return remote.copyWith(candidateUrls: mergedUrls);
    } catch (_) {
      // Tekil endpoint herhangi bir nedenle kullanılamazsa liste kaydıyla devam.
      return fallback;
    }
  }

  Map<String, dynamic>? _extractObject(dynamic decoded) {
    if (decoded is! Map) return null;
    final Map<String, dynamic> map = decoded.map(
      (dynamic key, dynamic value) => MapEntry(key.toString(), value),
    );

    const List<String> objectKeys = <String>[
      'wallpaper',
      'data',
      'item',
      'result',
    ];
    for (final String key in objectKeys) {
      final dynamic value = map[key];
      if (value is Map) {
        return value.map(
          (dynamic nestedKey, dynamic nestedValue) =>
              MapEntry(nestedKey.toString(), nestedValue),
        );
      }
      if (value is List && value.isNotEmpty && value.first is Map) {
        final Map<dynamic, dynamic> first = value.first as Map<dynamic, dynamic>;
        return first.map(
          (dynamic nestedKey, dynamic nestedValue) =>
              MapEntry(nestedKey.toString(), nestedValue),
        );
      }
    }

    if (_imageCandidates(map).isNotEmpty) return map;
    return null;
  }

  Wallpaper? _wallpaperFromItem(
    Map<String, dynamic> item, {
    required String fallbackId,
    Wallpaper? fallback,
  }) {
    final List<String> candidates = _imageCandidates(item);
    for (final String url in fallback?.wallpaperUrls ?? const <String>[]) {
      final String? safe = _safeMediaUrl(url);
      if (safe != null && !candidates.contains(safe)) candidates.add(safe);
    }
    if (candidates.isEmpty) return fallback;

    final String? thumbnailRaw = _firstString(item, const <String>[
      'thumbnail_url',
      'thumbnailUrl',
      'thumbnail',
      'thumb_url',
      'thumbUrl',
      'thumb',
      'preview_url',
      'previewUrl',
      'preview',
    ]);
    final String? safeThumbnail = thumbnailRaw == null ? null : _safeMediaUrl(thumbnailRaw);
    final String thumbnailUrl = safeThumbnail ??
        _safeMediaUrl(fallback?.thumbnailUrl ?? '') ??
        candidates.first;

    // Liste kartında image_url genellikle en hızlı/doğrudan dosyadır. Detay
    // hazırlamada ise candidateUrls üzerinden download/original dahil tümü denenir.
    final String? preferredRaw = _firstString(item, const <String>[
      'image_url',
      'imageUrl',
      'full_url',
      'fullUrl',
      'original_url',
      'originalUrl',
      'file_url',
      'fileUrl',
      'url',
      'image',
      'file',
      'path',
      'src',
    ]);
    final String? safePreferred = preferredRaw == null ? null : _safeMediaUrl(preferredRaw);
    final String imageUrl = safePreferred ??
        _safeMediaUrl(fallback?.imageUrl ?? '') ??
        candidates.first;

    return Wallpaper(
      id: _firstString(item, const <String>['id', 'wallpaper_id', 'code', 'slug']) ??
          fallback?.id ??
          fallbackId,
      title: _firstString(item, const <String>['title', 'name']) ??
          fallback?.title ??
          'ELXVRO Mobil',
      imageUrl: imageUrl,
      thumbnailUrl: thumbnailUrl,
      category: _categoryName(item) ?? fallback?.category ?? 'Mobil',
      categoryKeys: _categoryKeys(item).isEmpty
          ? (fallback?.categoryKeys ?? const <String>[])
          : _categoryKeys(item),
      candidateUrls: List<String>.unmodifiable(candidates),
    );
  }

  List<String> _imageCandidates(Map<String, dynamic> item) {
    final List<String> values = <String>[];
    void addRaw(dynamic raw) {
      if (raw == null || raw is Map || raw is List) return;
      final String? safe = _safeMediaUrl(raw.toString());
      if (safe == null || values.contains(safe)) return;
      values.add(safe);
    }

    for (final String key in const <String>[
      'full_url',
      'fullUrl',
      'image_url',
      'imageUrl',
      'download_url',
      'downloadUrl',
      'thumbnail_url',
      'thumbnailUrl',
      'thumbnail',
      'thumb_url',
      'thumbUrl',
      'thumb',
      'preview_url',
      'previewUrl',
      'preview',
    ]) {
      addRaw(item[key]);
    }
    return values;
  }

  Future<dynamic> _decode(String body, String errorMessage) async {
    try {
      if (body.length >= 120000) {
        return await compute<String, dynamic>(_decodeJson, body);
      }
      return jsonDecode(body);
    } catch (_) {
      throw Exception(errorMessage);
    }
  }

  Future<String> _fetchBody(
    Uri uri, {
    required Duration cacheTtl,
    required Duration timeout,
    required bool forceRefresh,
    required String errorLabel,
  }) async {
    final String key = base64Url.encode(utf8.encode(uri.toString())).replaceAll('=', '');
    final int now = DateTime.now().millisecondsSinceEpoch;
    final int ttlMs = cacheTtl.inMilliseconds;

    String? cachedBody = _memoryBodies[key];
    int? cachedAt = _memoryTimes[key];

    final Directory cacheDir = Directory('${Directory.systemTemp.path}/elxvro_api');
    final File cacheFile = File('${cacheDir.path}/$key.json');

    if (cachedBody == null || cachedAt == null) {
      try {
        if (await cacheFile.exists()) {
          cachedBody = await cacheFile.readAsString();
          cachedAt = (await cacheFile.lastModified()).millisecondsSinceEpoch;
          if (cachedBody.isNotEmpty) {
            _memoryBodies[key] = cachedBody;
            _memoryTimes[key] = cachedAt;
          }
        }
      } catch (_) {
        // Disk cache okunamazsa ağ isteği normal şekilde devam eder.
      }
    }

    final bool fresh = cachedBody != null &&
        cachedAt != null &&
        now - cachedAt >= 0 &&
        now - cachedAt <= ttlMs;

    if (!forceRefresh && fresh) return cachedBody;

    try {
      final http.Response response = await _client.get(
        uri,
        headers: const <String, String>{
          'Accept': 'application/json',
          'User-Agent': 'ELXVRO-Android/1.2.0',
        },
      ).timeout(timeout);

      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception('$errorLabel alınamadı (HTTP ${response.statusCode}).');
      }

      final String newBody = response.body;
      _memoryBodies[key] = newBody;
      _memoryTimes[key] = now;

      try {
        if (!await cacheDir.exists()) await cacheDir.create(recursive: true);
        final File temp = File('${cacheFile.path}.tmp');
        await temp.writeAsString(newBody, flush: false);
        if (await cacheFile.exists()) await cacheFile.delete();
        await temp.rename(cacheFile.path);
      } catch (_) {
        // Disk cache yazımı başarısız olsa bile API sonucu kullanılabilir.
      }

      return newBody;
    } catch (error) {
      if (cachedBody != null && cachedBody.isNotEmpty) return cachedBody;
      rethrow;
    }
  }

  List<dynamic> _extractList(
    dynamic decoded, {
    required List<String> preferredKeys,
  }) {
    if (decoded is List) return decoded;
    if (decoded is! Map) return const <dynamic>[];

    final Map<String, dynamic> map = decoded.map(
      (dynamic key, dynamic value) => MapEntry(key.toString(), value),
    );

    for (final String key in preferredKeys) {
      final dynamic value = map[key];
      if (value is List) return value;
      if (value is Map) {
        final Map<String, dynamic> nested = value.map(
          (dynamic key, dynamic value) => MapEntry(key.toString(), value),
        );
        for (final String nestedKey in preferredKeys) {
          final dynamic nestedValue = nested[nestedKey];
          if (nestedValue is List) return nestedValue;
        }
      }
    }

    return const <dynamic>[];
  }

  bool _isMobileItem(Map<String, dynamic> item) {
    final List<String> deviceValues = <String>[];

    for (final String key in const <String>[
      'device',
      'device_type',
      'deviceType',
      'platform',
      'target',
      'screen_type',
      'screenType',
      'orientation',
      'type',
    ]) {
      final dynamic value = item[key];
      if (value != null) {
        deviceValues.add(value.toString().trim().toLowerCase());
      }
    }

    if (deviceValues.any(
      (String value) => value.contains('pc') ||
          value.contains('desktop') ||
          value.contains('computer') ||
          value.contains('landscape'),
    )) {
      return false;
    }

    if (deviceValues.any(
      (String value) => value.contains('mobile') ||
          value.contains('phone') ||
          value.contains('telefon') ||
          value.contains('portrait') ||
          value.contains('vertical'),
    )) {
      return true;
    }

    final double? width = _number(item['width'] ?? item['image_width']);
    final double? height = _number(item['height'] ?? item['image_height']);
    if (width != null && height != null && width > 0 && height > 0) {
      return height >= width;
    }

    return true;
  }

  List<String> _categoryKeys(Map<String, dynamic> item) {
    final List<String> values = <String>[];

    void addValue(dynamic value) {
      if (value == null) return;
      if (value is Map) {
        final Map<String, dynamic> nested = value.map(
          (dynamic key, dynamic nestedValue) =>
              MapEntry(key.toString(), nestedValue),
        );
        for (final String key in const <String>[
          'id',
          'category_id',
          'name',
          'title',
          'slug',
          'category_slug',
          'category_name',
        ]) {
          addValue(nested[key]);
        }
        return;
      }
      if (value is List) {
        for (final dynamic entry in value) {
          addValue(entry);
        }
        return;
      }

      final String text = value.toString().trim();
      if (text.isEmpty || text.toLowerCase() == 'null') return;

      // Bazi API'ler coklu degeri virgul/pipe ile tek string olarak dondurur.
      final List<String> parts = text.split(RegExp(r'[,|;]+'));
      for (final String part in parts) {
        final String clean = part.trim();
        if (clean.isNotEmpty && !values.contains(clean)) values.add(clean);
      }
    }

    for (final String key in const <String>[
      'category',
      'categories',
      'category_id',
      'category_ids',
      'category_name',
      'category_names',
      'category_title',
      'category_slug',
      'category_slugs',
    ]) {
      addValue(item[key]);
    }

    final String? primary = _categoryName(item);
    if (primary != null && !values.contains(primary)) values.add(primary);
    return List<String>.unmodifiable(values);
  }

  String? _categoryName(Map<String, dynamic> item) {
    final String? direct = _firstString(
      item,
      const <String>['category_name', 'category_title', 'category_slug'],
    );
    if (direct != null) return direct;

    final dynamic category = item['category'];
    if (category is Map) {
      final Map<String, dynamic> nested = category.map(
        (dynamic key, dynamic value) => MapEntry(key.toString(), value),
      );
      return _firstString(nested, const <String>['name', 'title', 'slug']);
    }
    if (category != null && category is! List) {
      final String text = category.toString().trim();
      if (text.isNotEmpty && text.toLowerCase() != 'null') return text;
    }
    return null;
  }

  String? _firstString(Map<String, dynamic> item, List<String> keys) {
    for (final String key in keys) {
      final dynamic value = item[key];
      if (value == null || value is Map || value is List) continue;
      final String text = value.toString().trim();
      if (text.isNotEmpty && text.toLowerCase() != 'null') return text;
    }
    return null;
  }

  int? _firstInt(Map<String, dynamic> item, List<String> keys) {
    for (final String key in keys) {
      final dynamic value = item[key];
      if (value is int) return value;
      if (value is num) return value.toInt();
      if (value != null) {
        final int? parsed = int.tryParse(value.toString());
        if (parsed != null) return parsed;
      }
    }
    return null;
  }

  int? _nestedCount(Map<String, dynamic> item, String key) {
    for (final String parent in const <String>['counts', 'count', 'stats']) {
      final dynamic value = item[parent];
      if (value is! Map) continue;
      final dynamic nested = value[key];
      if (nested is int) return nested;
      if (nested is num) return nested.toInt();
      if (nested != null) return int.tryParse(nested.toString());
    }
    return null;
  }

  double? _number(dynamic value) {
    if (value is num) return value.toDouble();
    if (value == null) return null;
    return double.tryParse(value.toString());
  }

  String? _safeMediaUrl(String raw) {
    final String text = raw.trim();
    if (text.isEmpty || text.toLowerCase() == 'null') return null;

    final String absolute = _absoluteUrl(text);
    final Uri? uri = Uri.tryParse(absolute);
    if (uri == null || uri.scheme != 'https') return null;

    final String host = uri.host.toLowerCase();
    if (host != 'www.elxvro.com' && host != 'elxvro.com') return null;

    final String path = uri.path;
    final bool mediaPath = path.startsWith('/app-api/media/full/') ||
        path.startsWith('/app-api/media/thumbs/');
    if (!mediaPath || uri.pathSegments.isEmpty) return null;

    final String fileName = uri.pathSegments.last;
    if (!RegExp(r'^ELX-M-.*\.webp$', caseSensitive: false).hasMatch(fileName)) {
      return null;
    }
    return uri.toString();
  }

  String _absoluteUrl(String raw) {
    final Uri? parsed = Uri.tryParse(raw);
    if (parsed != null && parsed.hasScheme) return parsed.toString();
    return Uri.parse(AppConfig.siteBaseUrl).resolve(raw).toString();
  }

  String _slugify(String value) {
    String text = value.toLowerCase().trim();
    const Map<String, String> replacements = <String, String>{
      'ç': 'c',
      'ğ': 'g',
      'ı': 'i',
      'ö': 'o',
      'ş': 's',
      'ü': 'u',
    };
    replacements.forEach((String from, String to) {
      text = text.replaceAll(from, to);
    });
    text = text.replaceAll(RegExp(r'[^a-z0-9]+'), '-');
    return text.replaceAll(RegExp(r'^-+|-+$'), '');
  }
}

dynamic _decodeJson(String source) => jsonDecode(source);
