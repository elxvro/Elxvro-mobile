# ELXVRO App v1.0.3 — Mobile Only

Bu surum ELXVRO mobil APK icindir ve PC/desktop gorsellerini uygulamada gostermemek uzere hazirlanmistir.

## Sabit API

- Base: `https://www.elxvro.com/api/v1`
- Mobil gorseller: `wallpapers.php?device=mobile`

Uygulama sunucudan mobil filtre ister. API cevabinda cihaz/orientation bilgisi bulunursa `pc`, `desktop` ve `landscape` kayitlari uygulama tarafinda da elenir.

## GitHub APK

Bu klasoru ZIP olarak `elxvro-app.zip` adiyla repository ana dizinine yukleyip daha once verilen ZIP-build workflow'unu calistirabilirsiniz. Workflow ZIP'i acar, `pubspec.yaml` dosyasini bulur, Android dosyalarini uretir ve release APK'yi artifact olarak yukler.
