import 'package:flutter/material.dart';

import '../models/announcement.dart';
import '../theme/app_theme.dart';
import '../widgets/elxvro_logo.dart';

class AnnouncementsScreen extends StatelessWidget {
  const AnnouncementsScreen({super.key});

  static const List<Announcement> _items = <Announcement>[
    Announcement(
      title: 'ELXVRO v1.3.4 UI Polish',
      body: 'Ana sayfa, kategori kartları, Keşfet, Duyurular ve Profil ekranları yeni ELXVRO marka diliyle yeniden düzenlendi.',
      date: '14 Eylül 2026',
    ),
    Announcement(
      title: 'Yeni ELXVRO marka kimliği',
      body: 'E/X monogram logo, uygulama ikonu ve splash ekranı artık ELXVRO’nun sabit görsel kimliği olarak kullanılıyor.',
      date: '14 Eylül 2026',
    ),
    Announcement(
      title: 'App API + Mobile Media Pack',
      body: 'Android uygulaması ELX-M mobil medya paketini kullanıyor. Ana sayfa, kategoriler ve duvar kağıdı akışı aynı sunucu katmanında çalışıyor.',
      date: 'ELXVRO Mobile',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 118),
      children: <Widget>[
        const _AnnouncementHero(),
        const SizedBox(height: 22),
        const Row(
          children: <Widget>[
            Text('Son duyurular', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            Spacer(),
            Text(
              'SÜRÜM NOTLARI',
              style: TextStyle(
                color: AppTheme.accent,
                fontSize: 9.5,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.15,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        for (int index = 0; index < _items.length; index++) ...<Widget>[
          _AnnouncementCard(item: _items[index], latest: index == 0),
          if (index != _items.length - 1) const SizedBox(height: 12),
        ],
      ],
    );
  }
}

class _AnnouncementHero extends StatelessWidget {
  const _AnnouncementHero();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(21),
      decoration: BoxDecoration(
        gradient: AppTheme.heroGradient,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: const Color(0x4436425A)),
        boxShadow: const <BoxShadow>[
          BoxShadow(color: Color(0x33000000), blurRadius: 28, offset: Offset(0, 14)),
        ],
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              ElxvroLogo(compact: true, showWordmark: false),
              Spacer(),
              _LiveBadge(),
            ],
          ),
          SizedBox(height: 22),
          Text(
            'ELXVRO’dan\nhaberin olsun.',
            style: TextStyle(
              fontSize: 29,
              height: 1.08,
              fontWeight: FontWeight.w900,
              letterSpacing: -0.5,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Yeni sürümler, arayüz değişiklikleri ve önemli uygulama duyuruları tek yerde.',
            style: TextStyle(color: AppTheme.muted, height: 1.45, fontSize: 12.5),
          ),
        ],
      ),
    );
  }
}

class _LiveBadge extends StatelessWidget {
  const _LiveBadge();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: const Color(0x146FE6B5),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0x356FE6B5)),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(Icons.circle, size: 7, color: AppTheme.success),
          SizedBox(width: 6),
          Text(
            'GÜNCEL',
            style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w900, letterSpacing: 1),
          ),
        ],
      ),
    );
  }
}

class _AnnouncementCard extends StatelessWidget {
  const _AnnouncementCard({required this.item, required this.latest});

  final Announcement item;
  final bool latest;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: latest ? const Color(0x446E6BFF) : AppTheme.border,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                gradient: latest ? AppTheme.brandGradient : null,
                color: latest ? null : AppTheme.surfaceAlt,
                borderRadius: BorderRadius.circular(15),
                border: latest ? null : Border.all(color: AppTheme.border),
              ),
              child: Icon(
                latest ? Icons.auto_awesome_rounded : Icons.notifications_none_rounded,
                color: latest ? Colors.white : AppTheme.muted,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      if (latest)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                          decoration: BoxDecoration(
                            color: const Color(0x1F66E7FF),
                            borderRadius: BorderRadius.circular(999),
                            border: Border.all(color: const Color(0x2F66E7FF)),
                          ),
                          child: const Text(
                            'YENİ',
                            style: TextStyle(
                              color: AppTheme.accent,
                              fontSize: 8.5,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.1,
                            ),
                          ),
                        ),
                      const Spacer(),
                      Text(
                        item.date,
                        style: const TextStyle(
                          fontSize: 9.5,
                          color: AppTheme.muted,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 9),
                  Text(
                    item.title,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 7),
                  Text(
                    item.body,
                    style: const TextStyle(color: AppTheme.muted, height: 1.45, fontSize: 12),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
