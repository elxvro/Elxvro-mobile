import 'dart:convert';

import 'package:http/http.dart' as http;

import '../config/app_config.dart';
import '../models/category.dart';
import '../models/wallpaper.dart';

class ApiService {
  const ApiService();

  Future<List<WallpaperCategory>> fetchCategories() async {
    final http.Response response = await http.get(
      AppConfig.categoriesUri,
      headers: const <String, String>{'Accept': 'application/json'},
    ).timeout(const Duration(seconds: 20));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Kategoriler alınamadı (HTTP ${response.statusCode}).');
    }

    final dynamic decoded;
    try {
      decoded = jsonDecode(response.body);
    } on FormatException {
      throw Exception('Kategori API geçersiz JSON döndürdü.');
    }

    final List<dynamic> rows = _extractList(
      decoded,
      preferredKeys: const <String>['categories', 'data', 'items', 'results'],
    );

    final List<WallpaperCategory> result = <WallpaperCategory>[];
    for (final dynamic row in rows) {
      if (row is! Map) continue;
      final Map<String, dynamic> item = row.map(
        (dynamic key, dynamic value) => MapEntry(key.toString(), value),
      );

      final String? name = _firstString(
        item,
        const <String>['name', 'title', 'category_name', 'category'],
      );
      if (name == null || name.isEmpty) continue;

      final String slug = _firstString(
            item,
            const <String>['slug', 'code', 'key', 'category_slug'],
          ) ??
          _slugify(name);

      final int? mobileCount = _firstInt(
        item,
        const <String>[
          'mobile_count',
          'mobileCount',
          'mobile_total',
          'mobileTotal',
          'mobile',
        ],
      ) ?? _nestedCount(item, 'mobile');

      final String? rawCover = _firstString(
        item,
        const <String>[
          'cover_url',
          'coverUrl',
          'cover',
          'image_url',
          'imageUrl',
          'image',
          'thumbnail_url',
          'thumbnail',
        ],
      );

      result.add(
        WallpaperCategory(
          id: _firstString(item, const <String>['id', 'category_id']) ?? slug,
          name: name,
          slug: slug,
          icon: _firstString(item, const <String>['icon', 'emoji']),
          coverUrl: rawCover == null ? null : _absoluteUrl(rawCover),
          mobileCount: mobileCount,
        ),
      );
    }

    return result;
  }

  Future<List<Wallpaper>> fetchMobileWallpapers({String? category}) async {
    final http.Response response = await http.get(
      AppConfig.mobileWallpapersUri(category: category),
      headers: const <String, String>{'Accept': 'application/json'},
    ).timeout(const Duration(seconds: 25));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Görseller alınamadı (HTTP ${response.statusCode}).');
    }

    final dynamic decoded;
    try {
      decoded = jsonDecode(response.body);
    } on FormatException {
      throw Exception('Görsel API geçersiz JSON döndürdü.');
    }

    final List<dynamic> rows = _extractList(
      decoded,
      preferredKeys: const <String>[
        'wallpapers',
        'data',
        'items',
        'results',
        'images',
      ],
    );
    final List<Wallpaper> result = <Wallpaper>[];

    for (final dynamic row in rows) {
      if (row is! Map) continue;
      final Map<String, dynamic> item = row.map(
        (dynamic key, dynamic value) => MapEntry(key.toString(), value),
      );

      if (!_isMobileItem(item)) continue;

      final String? image = _firstString(item, const <String>[
        'image_url',
        'imageUrl',
        'url',
        'image',
        'file_url',
        'file',
        'path',
        'src',
        'thumbnail_url',
        'thumbnail',
        'thumb',
      ]);

      if (image == null || image.isEmpty) continue;

      result.add(
        Wallpaper(
          id: _firstString(item, const <String>['id', 'wallpaper_id', 'code']) ??
              result.length.toString(),
          title: _firstString(item, const <String>['title', 'name']) ??
              'ELXVRO Mobil',
          imageUrl: _absoluteUrl(image),
          category: _categoryName(item) ?? 'Mobil',
        ),
      );
    }

    return result;
  }

  List<dynamic> _extractList(
    dynamic decoded, {
    required List<String> preferredKeys,
  }) {
    if (decoded is List) return decoded;
    if (decoded is! Map) return const <dynamic>[];

    final Map<String, dynamic> map = decoded.map(
      (dynamic key, dynamic value) => MapEntry(key.toString(), value),
    );

    for (final String key in preferredKeys) {
      final dynamic value = map[key];
      if (value is List) return value;
      if (value is Map) {
        final Map<String, dynamic> nested = value.map(
          (dynamic key, dynamic value) => MapEntry(key.toString(), value),
        );
        for (final String nestedKey in preferredKeys) {
          final dynamic nestedValue = nested[nestedKey];
          if (nestedValue is List) return nestedValue;
        }
      }
    }

    return const <dynamic>[];
  }

  bool _isMobileItem(Map<String, dynamic> item) {
    final List<String> deviceValues = <String>[];

    for (final String key in const <String>[
      'device',
      'device_type',
      'deviceType',
      'platform',
      'target',
      'screen_type',
      'screenType',
      'orientation',
      'type',
    ]) {
      final dynamic value = item[key];
      if (value != null) {
        deviceValues.add(value.toString().trim().toLowerCase());
      }
    }

    if (deviceValues.any(
      (String value) => value.contains('pc') ||
          value.contains('desktop') ||
          value.contains('computer') ||
          value.contains('landscape'),
    )) {
      return false;
    }

    if (deviceValues.any(
      (String value) => value.contains('mobile') ||
          value.contains('phone') ||
          value.contains('telefon') ||
          value.contains('portrait') ||
          value.contains('vertical'),
    )) {
      return true;
    }

    final double? width = _number(item['width'] ?? item['image_width']);
    final double? height = _number(item['height'] ?? item['image_height']);
    if (width != null && height != null && width > 0 && height > 0) {
      return height >= width;
    }

    return true;
  }


  String? _categoryName(Map<String, dynamic> item) {
    final String? direct = _firstString(
      item,
      const <String>['category_name', 'category_title', 'category_slug'],
    );
    if (direct != null) return direct;

    final dynamic category = item['category'];
    if (category is Map) {
      final Map<String, dynamic> nested = category.map(
        (dynamic key, dynamic value) => MapEntry(key.toString(), value),
      );
      return _firstString(nested, const <String>['name', 'title', 'slug']);
    }
    if (category != null && category is! List) {
      final String text = category.toString().trim();
      if (text.isNotEmpty && text.toLowerCase() != 'null') return text;
    }
    return null;
  }

  String? _firstString(Map<String, dynamic> item, List<String> keys) {
    for (final String key in keys) {
      final dynamic value = item[key];
      if (value == null || value is Map || value is List) continue;
      final String text = value.toString().trim();
      if (text.isNotEmpty && text.toLowerCase() != 'null') return text;
    }
    return null;
  }

  int? _firstInt(Map<String, dynamic> item, List<String> keys) {
    for (final String key in keys) {
      final dynamic value = item[key];
      if (value is int) return value;
      if (value is num) return value.toInt();
      if (value != null) {
        final int? parsed = int.tryParse(value.toString());
        if (parsed != null) return parsed;
      }
    }
    return null;
  }

  int? _nestedCount(Map<String, dynamic> item, String key) {
    for (final String parent in const <String>['counts', 'count', 'stats']) {
      final dynamic value = item[parent];
      if (value is! Map) continue;
      final dynamic nested = value[key];
      if (nested is int) return nested;
      if (nested is num) return nested.toInt();
      if (nested != null) return int.tryParse(nested.toString());
    }
    return null;
  }

  double? _number(dynamic value) {
    if (value is num) return value.toDouble();
    if (value == null) return null;
    return double.tryParse(value.toString());
  }

  String _absoluteUrl(String raw) {
    final Uri? parsed = Uri.tryParse(raw);
    if (parsed != null && parsed.hasScheme) return parsed.toString();
    return Uri.parse(AppConfig.siteBaseUrl).resolve(raw).toString();
  }

  String _slugify(String value) {
    String text = value.toLowerCase().trim();
    const Map<String, String> replacements = <String, String>{
      'ç': 'c',
      'ğ': 'g',
      'ı': 'i',
      'ö': 'o',
      'ş': 's',
      'ü': 'u',
    };
    replacements.forEach((String from, String to) {
      text = text.replaceAll(from, to);
    });
    text = text.replaceAll(RegExp(r'[^a-z0-9]+'), '-');
    return text.replaceAll(RegExp(r'^-+|-+$'), '');
  }
}
