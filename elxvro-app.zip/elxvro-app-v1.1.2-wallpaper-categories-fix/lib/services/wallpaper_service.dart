import 'dart:io';

import 'package:flutter/services.dart';

enum WallpaperTarget { home, lock, both }

class WallpaperService {
  const WallpaperService();

  static const MethodChannel _channel = MethodChannel('com.elxvro/wallpaper');

  Future<void> prepareFromUrl(String imageUrl) async {
    if (!Platform.isAndroid) return;
    try {
      await _channel.invokeMethod<bool>('prepareWallpaper', <String, String>{'url': imageUrl});
    } catch (_) {
      // Ön yükleme zorunlu değil; setFromUrl gerektiğinde tekrar deneyebilir.
    }
  }

  Future<void> setFromUrl({
    required String imageUrl,
    required WallpaperTarget target,
  }) async {
    if (!Platform.isAndroid) {
      throw Exception('Duvar kağıdı ayarlama şu anda yalnızca Android APK’da destekleniyor.');
    }

    try {
      await _channel.invokeMethod<bool>(
        'setWallpaper',
        <String, String>{'url': imageUrl, 'target': target.name},
      );
    } on PlatformException catch (error) {
      final String message = error.message?.trim().isNotEmpty == true
          ? error.message!.trim()
          : 'Duvar kağıdı ayarlanamadı.';
      throw Exception(message);
    } on MissingPluginException {
      throw Exception('Android duvar kağıdı modülü APK içine eklenmemiş.');
    }
  }
}
