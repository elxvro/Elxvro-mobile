import 'dart:async';

import 'package:flutter/material.dart';

import '../models/wallpaper.dart';
import '../services/wallpaper_service.dart';
import '../theme/app_theme.dart';

class WallpaperDetailScreen extends StatefulWidget {
  const WallpaperDetailScreen({
    super.key,
    required this.wallpaper,
  });

  final Wallpaper wallpaper;

  @override
  State<WallpaperDetailScreen> createState() => _WallpaperDetailScreenState();
}

class _WallpaperDetailScreenState extends State<WallpaperDetailScreen> {
  final WallpaperService _wallpaperService = const WallpaperService();
  bool _settingWallpaper = false;

  @override
  void initState() {
    super.initState();
    unawaited(_wallpaperService.prepareFromUrl(widget.wallpaper.imageUrl));
  }

  Future<void> _chooseAndSetWallpaper() async {
    final WallpaperTarget? target = await showModalBottomSheet<WallpaperTarget>(
      context: context,
      backgroundColor: AppTheme.surface,
      showDragHandle: true,
      builder: (BuildContext sheetContext) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                const Padding(
                  padding: EdgeInsets.fromLTRB(8, 4, 8, 14),
                  child: Text(
                    'Nereye uygulansın?',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                  ),
                ),
                _TargetTile(
                  icon: Icons.home_rounded,
                  title: 'Ana ekran',
                  subtitle: 'Sadece telefonun ana ekranı',
                  onTap: () => Navigator.pop(sheetContext, WallpaperTarget.home),
                ),
                const SizedBox(height: 8),
                _TargetTile(
                  icon: Icons.lock_rounded,
                  title: 'Kilit ekranı',
                  subtitle: 'Sadece kilit ekranı',
                  onTap: () => Navigator.pop(sheetContext, WallpaperTarget.lock),
                ),
                const SizedBox(height: 8),
                _TargetTile(
                  icon: Icons.phone_android_rounded,
                  title: 'İkisi birden',
                  subtitle: 'Ana ekran ve kilit ekranı',
                  onTap: () => Navigator.pop(sheetContext, WallpaperTarget.both),
                ),
              ],
            ),
          ),
        );
      },
    );

    if (target == null || !mounted) return;

    setState(() => _settingWallpaper = true);

    try {
      await _wallpaperService.setFromUrl(
        imageUrl: widget.wallpaper.imageUrl,
        target: target,
      );

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Duvar kağıdı başarıyla uygulandı.'),
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (error) {
      if (!mounted) return;
      final String message = error.toString().replaceFirst('Exception: ', '');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          behavior: SnackBarBehavior.floating,
        ),
      );
    } finally {
      if (mounted) setState(() => _settingWallpaper = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: const Color(0x66000000),
        leading: IconButton.filledTonal(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_rounded),
        ),
        title: Text(
          widget.wallpaper.category,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          Container(color: Colors.black),
          InteractiveViewer(
            minScale: 1,
            maxScale: 4,
            child: Image.network(
              widget.wallpaper.imageUrl,
              fit: BoxFit.contain,
              filterQuality: FilterQuality.high,
              errorBuilder: (BuildContext context, Object error, StackTrace? stackTrace) {
                return const Center(
                  child: Icon(Icons.broken_image_outlined, size: 48, color: AppTheme.muted),
                );
              },
              loadingBuilder: (
                BuildContext context,
                Widget child,
                ImageChunkEvent? progress,
              ) {
                if (progress == null) return child;
                return const Center(child: CircularProgressIndicator());
              },
            ),
          ),
          Positioned(
            left: 16,
            right: 16,
            bottom: 24,
            child: SafeArea(
              top: false,
              child: FilledButton.icon(
                onPressed: _settingWallpaper ? null : _chooseAndSetWallpaper,
                icon: _settingWallpaper
                    ? const SizedBox.square(
                        dimension: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.wallpaper_rounded),
                label: Text(
                  _settingWallpaper ? 'Uygulanıyor...' : 'Duvar Kağıdı Yap',
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TargetTile extends StatelessWidget {
  const _TargetTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppTheme.surfaceAlt,
      borderRadius: BorderRadius.circular(16),
      child: ListTile(
        onTap: onTap,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        leading: Icon(icon, color: AppTheme.accent),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(subtitle, style: const TextStyle(color: AppTheme.muted)),
        trailing: const Icon(Icons.chevron_right_rounded),
      ),
    );
  }
}
