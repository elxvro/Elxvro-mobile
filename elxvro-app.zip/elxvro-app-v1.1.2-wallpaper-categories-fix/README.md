# ELXVRO Mobile v1.1.2

Bu sürüm v1.1.0 üzerine iki ana iyileştirme ekler:

- Native Google hesap seçici (`google_sign_in` 7.2.x). Tarayıcı login sayfası açılmaz.
- Wallpaper ayrıntısı açılır açılmaz native cache ön yüklemesi. Kullanıcı "Duvar Kağıdı Yap" dediğinde aynı yüksek çözünürlüklü görselin tekrar indirilmesi azaltılır.

## OAuth

Android OAuth Client ID:
`227765065065-r5o01nbld8jubjio4b5pflnvsk27d7me.apps.googleusercontent.com`

Web/Server Client ID:
`227765065065-3r92i04nkfc3nbnfs3hu28uf5jpvl7c4.apps.googleusercontent.com`

Paket adı: `com.elxvro.elxvro`

Google Cloud'a tanımlanan release SHA-1:
`0E:2B:66:85:9E:1B:D1:C4:7A:F4:1D:C6:93:FB:A4:A0:9F:99:51:53`

> Native Google girişinin çalışması için APK bu SHA-1'i üreten `elxvro-release.jks` ile imzalanmalıdır.

## GitHub

ZIP'i repository köküne `elxvro-app.zip` olarak yükle ve `GITHUB_ZIP_BUILD_WORKFLOW.yml` içeriğini `.github/workflows/build-apk.yml` olarak kullan.

Kalıcı signing için GitHub Actions secret'ları:

- `ELXVRO_KEYSTORE_PASSWORD`
- `ELXVRO_KEYSTORE_BASE64` (önerilir)

`ELXVRO_KEYSTORE_BASE64` yoksa workflow, aynı repodaki `generate-keystore.yml` workflow'unun en son `ELXVRO-RELEASE-KEY` artifact'ını indirmeyi dener. Artifact süresi dolmadan önce base64 secret eklemek gerekir.

## Destek paneli notu

Native Google oturumu uygulama içinde çalışır. Mevcut `contact.php` destek paneli ise web PHP session'ına bağlıdır. Web kaynak kodundaki kullanıcı/session şeması olmadan güvenli bir mobil-session köprüsü tahmin edilmemiştir; destek düğmesi mevcut paneli açar.


## v1.1.2 düzeltmeleri
- Duvar kağıdı Android ekranını tamamen doldurur (center-crop). Siyah/boş kenar bırakmaz.
- Kategoriler artık mobil wallpaper listesinin ilk sonucuna göre gizlenmez; categories.php içindeki tüm kategoriler gösterilir.
- Kategori API sırası korunur.
