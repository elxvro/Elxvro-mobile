import 'package:flutter/material.dart';

import '../models/wallpaper.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import '../widgets/fast_network_image.dart';
import 'wallpaper_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ApiService _api = const ApiService();
  final TextEditingController _searchController = TextEditingController();

  List<Wallpaper> _all = const <Wallpaper>[];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
    _searchController.addListener(_onSearchChanged);
  }

  void _onSearchChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _searchController
      ..removeListener(_onSearchChanged)
      ..dispose();
    super.dispose();
  }

  Future<void> _load({bool forceRefresh = false}) async {
    if (_all.isEmpty || forceRefresh) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }

    try {
      final List<Wallpaper> wallpapers = await _api.fetchMobileWallpapers(
        forceRefresh: forceRefresh,
      );
      if (!mounted) return;
      setState(() {
        _all = wallpapers;
        _error = null;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString().replaceFirst('Exception: ', '');
      });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  List<Wallpaper> _visibleItems() {
    final String query = _searchController.text.trim().toLowerCase();
    if (query.isEmpty) return _all;
    return _all.where((Wallpaper item) {
      return item.title.toLowerCase().contains(query) ||
          item.category.toLowerCase().contains(query);
    }).toList(growable: false);
  }

  @override
  Widget build(BuildContext context) {
    final List<Wallpaper> visible = _visibleItems();

    return RefreshIndicator(
      onRefresh: () => _load(forceRefresh: true),
      child: CustomScrollView(
        scrollCacheExtent: 520,
        physics: const AlwaysScrollableScrollPhysics(),
        slivers: <Widget>[
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
            sliver: SliverList.list(
              children: <Widget>[
                const Text(
                  'MOBİL',
                  style: TextStyle(
                    color: AppTheme.accent,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.8,
                  ),
                ),
                const SizedBox(height: 5),
                const Text(
                  'Mobil Duvar Kağıtları',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 6),
                const Text(
                  'Bu uygulama yalnızca dikey ekranlar için mobil görselleri gösterir.',
                  style: TextStyle(color: AppTheme.muted, height: 1.4),
                ),
                const SizedBox(height: 18),
                TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'Mobil görsellerde ara...',
                    prefixIcon: const Icon(Icons.search_rounded),
                    suffixIcon: _searchController.text.isEmpty
                        ? null
                        : IconButton(
                            onPressed: _searchController.clear,
                            icon: const Icon(Icons.close_rounded),
                          ),
                  ),
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),
          if (_loading && _all.isEmpty)
            const SliverFillRemaining(
              hasScrollBody: false,
              child: Center(child: CircularProgressIndicator()),
            )
          else if (_error != null && _all.isEmpty)
            SliverFillRemaining(
              hasScrollBody: false,
              child: _ErrorState(
                message: _error!,
                onRetry: () => _load(forceRefresh: true),
              ),
            )
          else if (visible.isEmpty)
            const SliverFillRemaining(
              hasScrollBody: false,
              child: Center(
                child: Padding(
                  padding: EdgeInsets.all(28),
                  child: Text(
                    'Mobil görsel bulunamadı.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppTheme.muted),
                  ),
                ),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 110),
              sliver: SliverLayoutBuilder(
                builder: (BuildContext context, constraints) {
                  final double width = constraints.crossAxisExtent;
                  final int columns = width >= 900
                      ? 5
                      : width >= 650
                          ? 4
                          : width >= 430
                              ? 3
                              : 2;
                  final double cellWidth = (width - ((columns - 1) * 10)) / columns;
                  final double dpr = MediaQuery.devicePixelRatioOf(context);
                  final int cacheWidth = (cellWidth * dpr).round().clamp(240, 720).toInt();

                  return SliverGrid(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: columns,
                      mainAxisSpacing: 10,
                      crossAxisSpacing: 10,
                      childAspectRatio: 0.58,
                    ),
                    delegate: SliverChildBuilderDelegate(
                      (BuildContext context, int index) {
                        return RepaintBoundary(
                          child: _WallpaperCard(
                            wallpaper: visible[index],
                            cacheWidth: cacheWidth,
                          ),
                        );
                      },
                      childCount: visible.length,
                    ),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }
}

class _WallpaperCard extends StatelessWidget {
  const _WallpaperCard({required this.wallpaper, required this.cacheWidth});

  final Wallpaper wallpaper;
  final int cacheWidth;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(18),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (BuildContext context) =>
                  WallpaperDetailScreen(wallpaper: wallpaper),
            ),
          );
        },
        child: Stack(
          fit: StackFit.expand,
          children: <Widget>[
            const ColoredBox(color: AppTheme.surfaceAlt),
            FastNetworkImage(
              url: wallpaper.thumbnailUrl,
              fit: BoxFit.cover,
              memCacheWidth: cacheWidth,
              diskCacheWidth: cacheWidth.clamp(360, 900).toInt(),
            ),
            const Positioned(
              top: 9,
              left: 9,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: Color(0xB3000000),
                  borderRadius: BorderRadius.all(Radius.circular(9)),
                ),
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                  child: Text(
                    'MOBİL',
                    style: TextStyle(fontSize: 10, fontWeight: FontWeight.w900),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                padding: const EdgeInsets.fromLTRB(10, 24, 10, 10),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: <Color>[Colors.transparent, Color(0xD9000000)],
                  ),
                ),
                child: Text(
                  wallpaper.category,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  const _ErrorState({required this.message, required this.onRetry});

  final String message;
  final Future<void> Function() onRetry;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(28),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          const Icon(Icons.cloud_off_rounded, size: 44, color: AppTheme.muted),
          const SizedBox(height: 14),
          Text(message, textAlign: TextAlign.center),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: () => onRetry(),
            icon: const Icon(Icons.refresh_rounded),
            label: const Text('Tekrar Dene'),
          ),
        ],
      ),
    );
  }
}
