import 'package:flutter/material.dart';

import '../models/category.dart';
import '../models/wallpaper.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import '../widgets/fast_network_image.dart';
import 'wallpaper_detail_screen.dart';

class CategoryWallpapersScreen extends StatefulWidget {
  const CategoryWallpapersScreen({super.key, required this.category});

  final WallpaperCategory category;

  @override
  State<CategoryWallpapersScreen> createState() => _CategoryWallpapersScreenState();
}

class _CategoryWallpapersScreenState extends State<CategoryWallpapersScreen> {
  final ApiService _api = const ApiService();
  bool _loading = true;
  String? _error;
  List<Wallpaper> _items = const <Wallpaper>[];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load({bool forceRefresh = false}) async {
    if (_items.isEmpty || forceRefresh) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }

    try {
      List<Wallpaper> items = await _api.fetchMobileWallpapers(
        category: widget.category.slug,
        forceRefresh: forceRefresh,
      );

      if (items.isEmpty) {
        final List<Wallpaper> all = await _api.fetchMobileWallpapers(
          forceRefresh: forceRefresh,
        );
        final String wantedName = _normalize(widget.category.name);
        final String wantedSlug = _normalize(widget.category.slug);
        items = all.where((Wallpaper item) {
          final String value = _normalize(item.category);
          return value == wantedName || value == wantedSlug;
        }).toList(growable: false);
      }

      if (!mounted) return;
      setState(() {
        _items = items;
        _error = null;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString().replaceFirst('Exception: ', '');
      });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _normalize(String value) {
    String text = value.toLowerCase().trim();
    const Map<String, String> replacements = <String, String>{
      'ç': 'c',
      'ğ': 'g',
      'ı': 'i',
      'ö': 'o',
      'ş': 's',
      'ü': 'u',
    };
    replacements.forEach((String from, String to) {
      text = text.replaceAll(from, to);
    });
    return text.replaceAll(RegExp(r'[^a-z0-9]+'), '-').replaceAll(RegExp(r'^-+|-+$'), '');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.category.name)),
      body: RefreshIndicator(
        onRefresh: () => _load(forceRefresh: true),
        child: _buildBody(),
      ),
    );
  }

  Widget _buildBody() {
    if (_loading && _items.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_error != null && _items.isEmpty) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(28),
        children: <Widget>[
          const SizedBox(height: 100),
          const Icon(Icons.cloud_off_rounded, size: 44, color: AppTheme.muted),
          const SizedBox(height: 14),
          Text(_error!, textAlign: TextAlign.center),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: () => _load(forceRefresh: true),
            icon: const Icon(Icons.refresh_rounded),
            label: const Text('Tekrar Dene'),
          ),
        ],
      );
    }

    if (_items.isEmpty) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(28),
        children: const <Widget>[
          SizedBox(height: 120),
          Icon(Icons.image_not_supported_outlined, size: 44, color: AppTheme.muted),
          SizedBox(height: 14),
          Text(
            'Bu kategoride mobil görsel bulunamadı.',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppTheme.muted),
          ),
        ],
      );
    }

    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        final int columns = constraints.maxWidth >= 900
            ? 5
            : constraints.maxWidth >= 650
                ? 4
                : constraints.maxWidth >= 430
                    ? 3
                    : 2;
        final double cellWidth =
            (constraints.maxWidth - 24 - ((columns - 1) * 10)) / columns;
        final int cacheWidth = (cellWidth * MediaQuery.devicePixelRatioOf(context))
            .round()
            .clamp(240, 720).toInt();

        return GridView.builder(
          scrollCacheExtent: 520,
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 28),
          itemCount: _items.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: columns,
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 0.58,
          ),
          itemBuilder: (BuildContext context, int index) {
            final Wallpaper wallpaper = _items[index];
            return RepaintBoundary(
              child: Material(
                color: AppTheme.surfaceAlt,
                borderRadius: BorderRadius.circular(18),
                clipBehavior: Clip.antiAlias,
                child: InkWell(
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => WallpaperDetailScreen(wallpaper: wallpaper),
                      ),
                    );
                  },
                  child: Stack(
                    fit: StackFit.expand,
                    children: <Widget>[
                      FastNetworkImage(
                        url: wallpaper.thumbnailUrl,
                        fit: BoxFit.cover,
                        memCacheWidth: cacheWidth,
                        diskCacheWidth: cacheWidth.clamp(360, 900).toInt(),
                      ),
                      Positioned(
                        left: 0,
                        right: 0,
                        bottom: 0,
                        child: Container(
                          padding: const EdgeInsets.fromLTRB(10, 26, 10, 10),
                          decoration: const BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: <Color>[Colors.transparent, Color(0xE6000000)],
                            ),
                          ),
                          child: Text(
                            wallpaper.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }
}
