# ELXVRO Mobile v1.1.3 Performance

Bu sürüm v1.1.2 üzerine performans odaklı hazırlanmıştır. Native Google giriş, yeni release SHA-1 imzası, tüm kategorilerin görünmesi ve ekranı tamamen dolduran center-crop duvar kağıdı davranışı korunur.

## Performans iyileştirmeleri

- Galeri kartları API'de varsa `thumbnail_url` / `thumbnail` kullanır; tam çözünürlük liste içinde gereksiz yere decode edilmez.
- Ağ görselleri disk cache'e alınır (`cached_network_image 3.4.1`).
- Grid görselleri telefonun kart boyutuna göre daha düşük bellek çözünürlüğünde decode edilir.
- Görsel fade animasyonları kaldırıldı; hızlı kaydırmada daha az render işi yapılır.
- Wallpaper ve kategori kartları `RepaintBoundary` ile izole edildi.
- Ana liste ve kategori gridlerinde kontrollü `cacheExtent` ile yalnızca yakın içerikler önceden hazırlanır.
- HTTP isteklerinde tek kalıcı `http.Client` kullanılır; bağlantı tekrar kullanımına uygundur.
- API JSON cevapları uygulamanın geçici disk cache'inde tutulur: wallpaper listesi 30 dakika, kategoriler 24 saat cache-first çalışır.
- Pull-to-refresh her zaman cache'i bypass ederek güncel API verisini ister.
- Ağ hatasında daha önce alınmış API cache'i varsa uygulama onu kullanmaya devam eder.
- Büyük JSON cevapları belirli bir boyutun üstünde arka isolate'ta parse edilir.
- Kategori ekranı artık kategori API'si başarılıysa ayrıca tüm mobil wallpaper listesini indirmez.
- Kategori API'si gerçekten boşsa eski güvenli fallback korunur.

## Duvar kağıdı hızlandırması

- Ayrıntı ekranına girildiğinde tam görsel Android native cache'e önceden alınır.
- 4K/8K görsel decode edilirken ekran çözünürlüğüne uygun `inSampleSize` kullanılır; gereksiz tam çözünürlük bellek yükü azaltılır.
- Center-crop sonucu ekran boyutunda JPEG olarak ikinci bir prepared cache'e kaydedilir.
- `Duvar Kağıdı Yap` butonuna basıldığında hazır dosya varsa yeniden indirme, yeniden büyük decode ve yeniden crop yapılmaz.
- Ayrıntı ekranı hazırlanmış yerel dosyayı doğrudan gösterebilir; böylece aynı full-resolution dosyanın Flutter tarafından ikinci kez indirilmesi önlenir.
- Native wallpaper cache toplamı yaklaşık 300 MB ile sınırlandırılır; en eski dosyalar otomatik temizlenir.

## Build

Repo kökünde kaynak ZIP'in adı:

`elxvro-app.zip`

Workflow yolu:

`.github/workflows/build-apk.yml`

Gerekli GitHub Secrets:

- `ELXVRO_KEYSTORE_PASSWORD`
- `ELXVRO_KEYSTORE_BASE64`

Beklenen release SHA-1:

`6B:24:70:EB:30:85:61:A7:30:A0:CA:1B:CA:ED:64:9E:1F:7C:9C:4F`

Build artifact:

`ELXVRO-APK-v1.1.3`

APK:

`ELXVRO-v1.1.3.apk`

Workflow önce `flutter analyze` ve `flutter test` çalıştırır, sonra release APK üretir ve imza SHA-1'ini doğrular.

## v1.1.3 analyze fix
- Flutter 3.47.4 ile deprecated olan `cacheExtent` kullanımları `scrollCacheExtent` olarak güncellendi.
- `api_service.dart` içindeki gereksiz non-null assertion kaldırıldı.
