# ELXVRO Android v1.2.1 — Server API + Mobile Media Pack

Bu sürüm yalnızca `https://www.elxvro.com/app-api/v1` API'sini ve `https://www.elxvro.com/app-api/media` görsellerini kullanır.

- Eski `/api/v1` uygulama tarafından çağrılmaz.
- Eski `/uploads` görsel adresleri kabul edilmez.
- Yalnızca `ELX-M-*.webp` medya dosyaları kabul edilir.
- Wallpaper listeleri 50'şer kayıtla sayfalanır; boş veya tekrarlanan sayfaya kadar devam eder.
- API sayfaları cihazda 30 dakika önbelleğe alınır.
- Görseller Flutter disk cache üzerinden hazırlanır; Android tarafına yerel dosya yolu verilir.
- Native Google giriş ve release SHA-1 korunur.

GitHub kullanımı:
1. Bu klasörü ZIP'leyip repo köküne `elxvro-app.zip` olarak koyun.
2. `GITHUB_ZIP_BUILD_WORKFLOW.yml` dosyasını `.github/workflows/build-apk.yml` olarak kullanın.
3. GitHub Actions ile release APK üretin.
