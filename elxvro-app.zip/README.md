# ELXVRO Android v1.5.0 — Play Release Candidate

ELXVRO mobile wallpaper application.

Core:
- App API + ELX-M Mobile Media Pack
- Google sign-in + unified ELXVRO account sync
- Home / Categories / Announcements / Explore / Profile
- Wallpaper preview and native Android wallpaper setter
- Persistent Favorites and Recently Viewed collection
- Play Store AAB + signed APK workflow
- Android 16 / API 36 target in CI

Important before production:
- `https://www.elxvro.com/account-delete.php` must be live and provide account deletion.
- After Play App Signing is enabled, add the Play App Signing SHA-1 to the Android OAuth client.
