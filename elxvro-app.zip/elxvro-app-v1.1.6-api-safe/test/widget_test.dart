import 'package:elxvro/config/app_config.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('mobile wallpaper endpoint is fixed to mobile device', () {
    final Uri uri = AppConfig.mobileWallpapersUri();
    expect(uri.path, endsWith('/wallpapers.php'));
    expect(uri.queryParameters['device'], 'mobile');
  });

  test('category can be added without losing mobile filter', () {
    final Uri uri = AppConfig.mobileWallpapersUri(category: 'anime');
    expect(uri.queryParameters['device'], 'mobile');
    expect(uri.queryParameters['category'], 'anime');
  });
}
