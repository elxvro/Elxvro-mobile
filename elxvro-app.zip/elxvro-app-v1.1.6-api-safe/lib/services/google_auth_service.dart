import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../config/app_config.dart';

class GoogleAuthService {
  GoogleAuthService._();

  static final GoogleAuthService instance = GoogleAuthService._();

  final GoogleSignIn _signIn = GoogleSignIn.instance;
  final ValueNotifier<GoogleSignInAccount?> account =
      ValueNotifier<GoogleSignInAccount?>(null);
  final ValueNotifier<bool> busy = ValueNotifier<bool>(false);
  final ValueNotifier<String?> lastError = ValueNotifier<String?>(null);

  StreamSubscription<GoogleSignInAuthenticationEvent>? _subscription;
  bool _initialized = false;

  Future<void> initialize() async {
    if (_initialized) return;
    _initialized = true;

    await _signIn.initialize(
      serverClientId: AppConfig.googleWebClientId,
    );

    _subscription = _signIn.authenticationEvents.listen(
      (GoogleSignInAuthenticationEvent event) {
        if (event is GoogleSignInAuthenticationEventSignIn) {
          account.value = event.user;
          lastError.value = null;
        } else if (event is GoogleSignInAuthenticationEventSignOut) {
          account.value = null;
        }
      },
      onError: (Object error) {
        lastError.value = _messageFor(error);
      },
    );

    try {
      await _signIn.attemptLightweightAuthentication();
    } catch (_) {
      // Sessiz geri yükleme başarısızsa kullanıcı butondan giriş yapabilir.
    }
  }

  Future<void> signIn() async {
    if (busy.value) return;
    busy.value = true;
    lastError.value = null;

    try {
      if (!_signIn.supportsAuthenticate()) {
        throw Exception('Bu cihaz native Google girişini desteklemiyor.');
      }
      final GoogleSignInAccount user = await _signIn.authenticate();
      account.value = user;
    } catch (error) {
      lastError.value = _messageFor(error);
      rethrow;
    } finally {
      busy.value = false;
    }
  }

  Future<void> signOut() async {
    if (busy.value) return;
    busy.value = true;
    lastError.value = null;
    try {
      await _signIn.signOut();
      account.value = null;
    } catch (error) {
      lastError.value = _messageFor(error);
      rethrow;
    } finally {
      busy.value = false;
    }
  }

  Future<String?> idToken() async => account.value?.authentication.idToken;

  String _messageFor(Object error) {
    if (error is GoogleSignInException) {
      switch (error.code) {
        case GoogleSignInExceptionCode.canceled:
          return 'Google giriş işlemi iptal edildi. Hesap seçtikten sonra bu hata geliyorsa SHA-1 veya OAuth istemci ayarlarını kontrol et.';
        case GoogleSignInExceptionCode.clientConfigurationError:
          return 'Google OAuth yapılandırması eşleşmiyor. Paket adı, SHA-1 ve Web Client ID kontrol edilmeli.';
        default:
          return error.description ?? 'Google ile giriş yapılamadı.';
      }
    }
    return error.toString().replaceFirst('Exception: ', '');
  }

  Future<void> dispose() async {
    await _subscription?.cancel();
  }
}
