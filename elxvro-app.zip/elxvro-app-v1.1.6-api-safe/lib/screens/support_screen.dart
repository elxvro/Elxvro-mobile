import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../config/app_config.dart';
import '../services/browser_service.dart';
import '../services/google_auth_service.dart';
import '../theme/app_theme.dart';

class SupportScreen extends StatelessWidget {
  const SupportScreen({super.key});

  static const BrowserService _browser = BrowserService();

  Future<void> _open(BuildContext context, String url) async {
    try {
      await _browser.open(url);
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString().replaceFirst('Exception: ', ''))),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<GoogleSignInAccount?>(
      valueListenable: GoogleAuthService.instance.account,
      builder: (BuildContext context, GoogleSignInAccount? user, Widget? child) {
        return ListView(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 110),
          children: <Widget>[
            const Text(
              'DESTEK',
              style: TextStyle(
                color: AppTheme.accent,
                fontSize: 12,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.7,
              ),
            ),
            const SizedBox(height: 5),
            const Text('Destek Merkezi', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
            const SizedBox(height: 7),
            Text(
              user == null
                  ? 'Önce Hesap sekmesinden Google hesabınla giriş yap.'
                  : '${user.displayName ?? user.email}, mevcut ELXVRO destek paneline buradan ulaşabilirsin.',
              style: const TextStyle(color: AppTheme.muted, height: 1.45),
            ),
            const SizedBox(height: 22),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    const Row(
                      children: <Widget>[
                        CircleAvatar(
                          backgroundColor: AppTheme.surfaceAlt,
                          child: Icon(Icons.support_agent_rounded, color: AppTheme.accent),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: Text('ELXVRO Site İçi Destek', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    const Text(
                      'Web destek paneli mevcut site hesabına bağlıdır. Native Google hesabı uygulamada açık olsa da web paneli, sunucu mobil oturum köprüsü eklenene kadar tarayıcı oturumunu ayrıca isteyebilir.',
                      style: TextStyle(color: AppTheme.muted, height: 1.45),
                    ),
                    const SizedBox(height: 18),
                    FilledButton.icon(
                      onPressed: () => _open(context, AppConfig.supportUrl),
                      icon: const Icon(Icons.forum_rounded),
                      label: const Text('Destek Panelini Aç'),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}
