import 'package:flutter/material.dart';

import '../models/category.dart';
import '../models/wallpaper.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import '../widgets/fast_network_image.dart';
import 'category_wallpapers_screen.dart';

class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key});

  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  final ApiService _api = const ApiService();

  bool _loading = true;
  String? _error;
  List<WallpaperCategory> _categories = const <WallpaperCategory>[];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load({bool forceRefresh = false}) async {
    if (_categories.isEmpty || forceRefresh) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }

    try {
      final List<WallpaperCategory> apiCategories = await _api.fetchCategories(
        forceRefresh: forceRefresh,
      );
      final List<WallpaperCategory> visible = <WallpaperCategory>[];
      final Set<String> used = <String>{};

      for (final WallpaperCategory category in apiCategories) {
        final String nameKey = _normalize(category.name);
        final String slugKey = _normalize(category.slug);
        final String uniqueKey = slugKey.isNotEmpty ? slugKey : nameKey;
        if (uniqueKey.isEmpty || !used.add(uniqueKey)) continue;
        visible.add(category);
      }

      // Kategori API'si boşsa yalnızca bu durumda wallpaper listesinden fallback üret.
      if (visible.isEmpty) {
        final List<Wallpaper> mobile = await _api.fetchMobileWallpapers(
          forceRefresh: forceRefresh,
        );
        final Map<String, int> counts = <String, int>{};
        for (final Wallpaper item in mobile) {
          final String key = _normalize(item.category);
          if (key.isEmpty || key == 'mobil') continue;
          counts[key] = (counts[key] ?? 0) + 1;
        }
        for (final MapEntry<String, int> entry in counts.entries) {
          visible.add(
            WallpaperCategory(
              id: entry.key,
              name: _displayName(entry.key),
              slug: entry.key,
              mobileCount: entry.value,
            ),
          );
        }
      }

      if (!mounted) return;
      setState(() {
        _categories = visible;
        _error = null;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString().replaceFirst('Exception: ', '');
      });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _normalize(String value) {
    String text = value.toLowerCase().trim();
    const Map<String, String> replacements = <String, String>{
      'ç': 'c',
      'ğ': 'g',
      'ı': 'i',
      'ö': 'o',
      'ş': 's',
      'ü': 'u',
    };
    replacements.forEach((String from, String to) {
      text = text.replaceAll(from, to);
    });
    return text.replaceAll(RegExp(r'[^a-z0-9]+'), '-').replaceAll(RegExp(r'^-+|-+$'), '');
  }

  String _displayName(String slug) {
    if (slug.isEmpty) return 'Kategori';
    return slug
        .split('-')
        .where((String part) => part.isNotEmpty)
        .map((String part) => '${part[0].toUpperCase()}${part.substring(1)}')
        .join(' ');
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () => _load(forceRefresh: true),
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 110),
        children: <Widget>[
          const Text(
            'KATEGORİLER',
            style: TextStyle(
              color: AppTheme.accent,
              fontSize: 12,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.7,
            ),
          ),
          const SizedBox(height: 5),
          const Text(
            'Tarzını seç.',
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 6),
          const Text(
            'Tüm kategoriler gösterilir. Kategoriye girince mobil içerikler açılır.',
            style: TextStyle(color: AppTheme.muted, height: 1.4),
          ),
          const SizedBox(height: 20),
          if (_loading && _categories.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 80),
              child: Center(child: CircularProgressIndicator()),
            )
          else if (_error != null && _categories.isEmpty)
            _CategoryError(
              message: _error!,
              onRetry: () => _load(forceRefresh: true),
            )
          else if (_categories.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 70),
              child: Center(
                child: Text(
                  'Kategori bulunamadı.',
                  style: TextStyle(color: AppTheme.muted),
                ),
              ),
            )
          else
            LayoutBuilder(
              builder: (BuildContext context, BoxConstraints constraints) {
                final int columns = constraints.maxWidth >= 700 ? 3 : 2;
                final double cellWidth =
                    (constraints.maxWidth - ((columns - 1) * 12)) / columns;
                final int cacheWidth = (cellWidth * MediaQuery.devicePixelRatioOf(context))
                    .round()
                    .clamp(240, 720).toInt();
                return GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: _categories.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: columns,
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: 1.05,
                  ),
                  itemBuilder: (BuildContext context, int index) {
                    final WallpaperCategory category = _categories[index];
                    return RepaintBoundary(
                      child: _CategoryCard(
                        category: category,
                        cacheWidth: cacheWidth,
                      ),
                    );
                  },
                );
              },
            ),
        ],
      ),
    );
  }
}

class _CategoryCard extends StatelessWidget {
  const _CategoryCard({required this.category, required this.cacheWidth});

  final WallpaperCategory category;
  final int cacheWidth;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppTheme.surfaceAlt,
      borderRadius: BorderRadius.circular(20),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (_) => CategoryWallpapersScreen(category: category),
            ),
          );
        },
        child: Stack(
          fit: StackFit.expand,
          children: <Widget>[
            if (category.coverUrl != null)
              FastNetworkImage(
                url: category.coverUrl!,
                fit: BoxFit.cover,
                memCacheWidth: cacheWidth,
                diskCacheWidth: cacheWidth.clamp(360, 900).toInt(),
              ),
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: <Color>[Color(0x22000000), Color(0xEE000000)],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(15),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.end,
                children: <Widget>[
                  Text(
                    category.icon?.trim().isNotEmpty == true ? category.icon! : '✦',
                    style: const TextStyle(fontSize: 22),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    category.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    category.mobileCount == null
                        ? 'Mobil duvar kağıtları'
                        : '${category.mobileCount} mobil görsel',
                    style: const TextStyle(color: AppTheme.muted, fontSize: 12),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CategoryError extends StatelessWidget {
  const _CategoryError({required this.message, required this.onRetry});

  final String message;
  final Future<void> Function() onRetry;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 60),
      child: Column(
        children: <Widget>[
          const Icon(Icons.cloud_off_rounded, size: 42, color: AppTheme.muted),
          const SizedBox(height: 12),
          Text(message, textAlign: TextAlign.center),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: () => onRetry(),
            icon: const Icon(Icons.refresh_rounded),
            label: const Text('Tekrar Dene'),
          ),
        ],
      ),
    );
  }
}
