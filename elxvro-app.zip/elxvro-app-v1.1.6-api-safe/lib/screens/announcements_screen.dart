import 'package:flutter/material.dart';

import '../models/announcement.dart';
import '../theme/app_theme.dart';

class AnnouncementsScreen extends StatelessWidget {
  const AnnouncementsScreen({super.key});

  static const List<Announcement> _items = <Announcement>[
    Announcement(
      title: 'ELXVRO Mobile v1.1 Final',
      body: 'Mobil kategoriler, Google hesap geçişi, destek paneli ve ekran uyumlu duvar kağıdı sistemi tamamlandı.',
      date: '14 Eylül 2026',
    ),
    Announcement(
      title: 'ELXVRO Web v4.7',
      body: 'Uygulama mevcut ELXVRO web hesabı ve destek merkeziyle birlikte çalışır.',
      date: 'Web referansı',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 110),
      itemCount: _items.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (BuildContext context, int index) {
        final Announcement item = _items[index];
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: const Color(0x227C5CFF),
                    borderRadius: BorderRadius.circular(13),
                  ),
                  child: const Icon(Icons.campaign_outlined, color: AppTheme.primary),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        item.title,
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                      ),
                      const SizedBox(height: 6),
                      Text(item.body, style: const TextStyle(color: AppTheme.muted, height: 1.4)),
                      const SizedBox(height: 10),
                      Text(item.date, style: const TextStyle(fontSize: 11.5, color: AppTheme.accent)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
