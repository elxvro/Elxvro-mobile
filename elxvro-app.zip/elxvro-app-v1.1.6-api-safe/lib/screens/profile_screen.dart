import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../config/app_config.dart';
import '../services/browser_service.dart';
import '../services/google_auth_service.dart';
import '../theme/app_theme.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  static const BrowserService _browser = BrowserService();
  final GoogleAuthService _auth = GoogleAuthService.instance;
  bool _acceptedTerms = false;

  Future<void> _open(String url) async {
    try {
      await _browser.open(url);
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString().replaceFirst('Exception: ', ''))),
      );
    }
  }

  Future<void> _signIn() async {
    try {
      await _auth.signIn();
    } catch (_) {
      if (!mounted) return;
      final String message = _auth.lastError.value ?? 'Google ile giriş yapılamadı.';
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
    }
  }

  Future<void> _signOut() async {
    try {
      await _auth.signOut();
    } catch (_) {
      if (!mounted) return;
      final String message = _auth.lastError.value ?? 'Çıkış yapılamadı.';
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<GoogleSignInAccount?>(
      valueListenable: _auth.account,
      builder: (BuildContext context, GoogleSignInAccount? user, Widget? child) {
        return ValueListenableBuilder<bool>(
          valueListenable: _auth.busy,
          builder: (BuildContext context, bool busy, Widget? child) {
            return ListView(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 110),
              children: <Widget>[
                _Avatar(user: user),
                const SizedBox(height: 14),
                Center(
                  child: Text(
                    user?.displayName?.trim().isNotEmpty == true
                        ? user!.displayName!.trim()
                        : 'ELXVRO Hesabı',
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
                  ),
                ),
                const SizedBox(height: 6),
                Center(
                  child: Text(
                    user?.email ?? 'Google hesabınla doğrudan uygulama içinde giriş yap.',
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: AppTheme.muted),
                  ),
                ),
                const SizedBox(height: 24),
                if (user == null) ...<Widget>[
                  CheckboxListTile(
                    value: _acceptedTerms,
                    contentPadding: EdgeInsets.zero,
                    controlAffinity: ListTileControlAffinity.leading,
                    onChanged: busy
                        ? null
                        : (bool? value) => setState(() => _acceptedTerms = value ?? false),
                    title: const Text(
                      'Kullanım Koşulları, Gizlilik Politikası ve KVKK metnini okudum ve kabul ediyorum.',
                      style: TextStyle(fontSize: 12.5, height: 1.35),
                    ),
                  ),
                  const SizedBox(height: 10),
                  FilledButton.icon(
                    onPressed: busy || !_acceptedTerms ? null : _signIn,
                    icon: busy
                        ? const SizedBox.square(
                            dimension: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.login_rounded),
                    label: Text(busy ? 'Google açılıyor...' : 'Google ile Giriş Yap'),
                    style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54)),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'Hesap seçici uygulamanın içinde açılır; tarayıcıya yönlendirme yapılmaz.',
                    style: TextStyle(color: AppTheme.muted, height: 1.45, fontSize: 12.5),
                    textAlign: TextAlign.center,
                  ),
                ] else ...<Widget>[
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: <Widget>[
                          const Icon(Icons.verified_rounded, color: AppTheme.accent),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                const Text('Google hesabı bağlı', style: TextStyle(fontWeight: FontWeight.w900)),
                                const SizedBox(height: 3),
                                Text(user.email, style: const TextStyle(color: AppTheme.muted)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                    onPressed: busy ? null : _signOut,
                    icon: const Icon(Icons.logout_rounded),
                    label: const Text('Çıkış Yap'),
                  ),
                ],
                const SizedBox(height: 22),
                Card(
                  child: Column(
                    children: <Widget>[
                      ListTile(
                        leading: const Icon(Icons.support_agent_rounded),
                        title: const Text('Destek Merkezi'),
                        subtitle: const Text('Mevcut ELXVRO web destek panelini aç'),
                        trailing: const Icon(Icons.open_in_new_rounded),
                        onTap: () => _open(AppConfig.supportUrl),
                      ),
                      const Divider(height: 1),
                      ListTile(
                        leading: const Icon(Icons.privacy_tip_outlined),
                        title: const Text('Gizlilik Politikası'),
                        trailing: const Icon(Icons.open_in_new_rounded),
                        onTap: () => _open(AppConfig.privacyUrl),
                      ),
                      const Divider(height: 1),
                      ListTile(
                        leading: const Icon(Icons.description_outlined),
                        title: const Text('Kullanım Koşulları'),
                        trailing: const Icon(Icons.open_in_new_rounded),
                        onTap: () => _open(AppConfig.termsUrl),
                      ),
                      const Divider(height: 1),
                      const ListTile(
                        leading: Icon(Icons.info_outline_rounded),
                        title: Text('Uygulama sürümü'),
                        trailing: Text(AppConfig.version, style: TextStyle(color: AppTheme.muted)),
                      ),
                    ],
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }
}

class _Avatar extends StatelessWidget {
  const _Avatar({required this.user});

  final GoogleSignInAccount? user;

  @override
  Widget build(BuildContext context) {
    final String? photo = user?.photoUrl;
    return Center(
      child: CircleAvatar(
        radius: 38,
        backgroundColor: AppTheme.surfaceAlt,
        backgroundImage: photo == null ? null : NetworkImage(photo),
        child: photo == null
            ? Text(
                user?.displayName?.trim().isNotEmpty == true
                    ? user!.displayName!.trim().characters.first.toUpperCase()
                    : 'G',
                style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900),
              )
            : null,
      ),
    );
  }
}
