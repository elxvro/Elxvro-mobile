import 'package:flutter/material.dart';

import 'config/app_config.dart';
import 'screens/shell_screen.dart';
import 'services/google_auth_service.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await GoogleAuthService.instance.initialize();
  runApp(const ElxvroApp());
}

class ElxvroApp extends StatelessWidget {
  const ElxvroApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConfig.appName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark(),
      home: const ShellScreen(),
    );
  }
}
