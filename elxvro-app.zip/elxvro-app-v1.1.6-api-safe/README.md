# ELXVRO Mobile v1.1.6 — API Safe Category Fix

- Kategori detay ekranı artık `category=` parametreli çoklu API isteği yapmaz.
- Tek güvenli mobil endpoint kullanılır: `wallpapers.php?device=mobile`.
- Ana ekranın memory/disk cache verisi kategori ekranında tekrar kullanılır.
- Kategori filtreleme cihazda yapılır.
- Shared-hosting/WAF üzerinde 403 tetikleme riski azaltıldı.
- v1.1.4 Wallpaper Fast, native Google giriş, thumbnail/cache ve diğer performans iyileştirmeleri korunur.
