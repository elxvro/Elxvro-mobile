# ELXVRO App v1.0.7

Android mobil duvar kagidi istemcisi.

## Bu sürüm

- Sadece mobil görseller: `wallpapers.php?device=mobile`
- Görsele dokununca tam ekran önizleme
- `Duvar Kağıdı Yap` butonu
- Android 7+ için:
  - Ana ekran
  - Kilit ekranı
  - İkisi birden
- `INTERNET` ve `SET_WALLPAPER` izinleri GitHub workflow tarafından eklenir.
- Yerel Android `WallpaperManager` entegrasyonu, Flutter `MethodChannel` ile çağrılır.

## GitHub

1. Bu ZIP'i repoya `elxvro-app.zip` adıyla yükle.
2. `GITHUB_ZIP_BUILD_WORKFLOW.yml` içeriğini `.github/workflows/build-apk.yml` dosyasına yapıştır.
3. Actions > ELXVRO APK Build > Run workflow.
4. `ELXVRO-APK-v1.0.7` artifact'ını indir.

Önemli: Eski v1.0.6 workflow'u duvar kağıdı için gereken Kotlin modülünü üretmez. v1.0.7 workflow kullanılmalıdır.
