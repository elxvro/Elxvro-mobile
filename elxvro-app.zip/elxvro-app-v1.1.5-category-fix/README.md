# ELXVRO Mobile v1.1.5 — Category Fix

Bu sürüm v1.1.4 Wallpaper Fast altyapısını korur ve kategori içeriği yükleme hatasını düzeltir.

- Kategori API çağrısında ID / slug / kategori adı uyumluluk fallback'i
- Kategoriye özel istek hata verse bile tüm mobil listeden yerel filtreleme
- Boş/hatalı kategori isteğinde gereksiz hata ekranına düşmeme
- Native Google giriş, thumbnail/API cache ve Wallpaper Fast korunur

# ELXVRO Mobile v1.1.5 — Wallpaper Fast

Bu sürüm v1.1.3 Performance üzerine kuruludur ve duvar kağıdı uygulama gecikmesini azaltır.

## Değişiklikler

- Detay ekranı açılır açılmaz duvar kağıdı arka planda telefon ekran boyutuna hazırlanır.
- Hazırlanan ekran-boyutlu dosya tekrar Bitmap olarak decode edilmeden Android `WallpaperManager.setStream` ile doğrudan uygulanır.
- Buton sonrası gereksiz JPEG decode ve ek bellek kopyası kaldırıldı.
- Hazırlanmış dosya varsa uygulama doğrudan onu kullanır; hazır değilse aynı hazırlama işleminin tamamlanmasını bekler.
- Hazır JPEG kalite seviyesi 94'ten 90'a çekildi; dosya daha küçük olduğu için sistem duvar kağıdını daha hızlı okuyabilir, görünür kalite kaybı minimumdur.
- Aynı duvar kağıdı tekrar seçildiğinde hazırlanan dosya cache'den kullanılır.
- v1.1.3 görsel/API cache, native Google giriş, kategori ve tam ekran center-crop düzeltmeleri korunur.

## GitHub

Repo kökündeki kaynak ZIP'in adı `elxvro-app.zip` olmalıdır. `.github/workflows/build-apk.yml` için paketteki `GITHUB_ZIP_BUILD_WORKFLOW.yml` kullanılabilir.

Gerekli repository secrets:

- `ELXVRO_KEYSTORE_BASE64`
- `ELXVRO_KEYSTORE_PASSWORD`

Beklenen release SHA-1:

`6B:24:70:EB:30:85:61:A7:30:A0:CA:1B:CA:ED:64:9E:1F:7C:9C:4F`
