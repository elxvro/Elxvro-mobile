import 'package:elxvro/config/app_config.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('mobile wallpaper endpoint is fixed to mobile device', () {
    expect(AppConfig.mobileWallpapersUri.path, endsWith('/wallpapers.php'));
    expect(AppConfig.mobileWallpapersUri.queryParameters['device'], 'mobile');
  });
}
