import 'dart:convert';

import 'package:http/http.dart' as http;

import '../config/app_config.dart';
import '../models/wallpaper.dart';

class ApiService {
  const ApiService();

  Future<void> checkConnection() async {
    final http.Response response = await http.get(
      AppConfig.categoriesUri,
      headers: const <String, String>{'Accept': 'application/json'},
    ).timeout(const Duration(seconds: 15));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('ELXVRO API HTTP ${response.statusCode} hatasi verdi.');
    }

    if (response.body.trim().isEmpty) {
      throw Exception('ELXVRO API bos cevap verdi.');
    }
  }

  Future<List<Wallpaper>> fetchMobileWallpapers() async {
    final http.Response response = await http.get(
      AppConfig.mobileWallpapersUri,
      headers: const <String, String>{'Accept': 'application/json'},
    ).timeout(const Duration(seconds: 20));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Gorseller alinamadi (HTTP ${response.statusCode}).');
    }

    final dynamic decoded;
    try {
      decoded = jsonDecode(response.body);
    } on FormatException {
      throw Exception('Gorsel API gecersiz JSON dondurdu.');
    }

    final List<dynamic> rows = _extractList(decoded);
    final List<Wallpaper> result = <Wallpaper>[];

    for (final dynamic row in rows) {
      if (row is! Map) continue;
      final Map<String, dynamic> item = row.map(
        (dynamic key, dynamic value) => MapEntry(key.toString(), value),
      );

      // Sunucuya device=mobile gonderiyoruz. Buna ek olarak cevapta cihaz
      // bilgisi varsa PC/desktop kayitlarini uygulama tarafinda da eliyoruz.
      if (!_isMobileItem(item)) continue;

      final String? image = _firstString(item, const <String>[
        'image_url',
        'imageUrl',
        'url',
        'image',
        'file_url',
        'file',
        'path',
        'src',
        'thumbnail_url',
        'thumbnail',
        'thumb',
      ]);

      if (image == null || image.isEmpty) continue;

      result.add(
        Wallpaper(
          id: _firstString(item, const <String>['id', 'wallpaper_id', 'code']) ??
              result.length.toString(),
          title: _firstString(item, const <String>['title', 'name']) ??
              'ELXVRO Mobil',
          imageUrl: _absoluteUrl(image),
          category: _firstString(
                item,
                const <String>['category_name', 'category', 'category_title'],
              ) ??
              'Mobil',
        ),
      );
    }

    return result;
  }

  List<dynamic> _extractList(dynamic decoded) {
    if (decoded is List) return decoded;
    if (decoded is! Map) return const <dynamic>[];

    final Map<String, dynamic> map = decoded.map(
      (dynamic key, dynamic value) => MapEntry(key.toString(), value),
    );

    for (final String key in const <String>[
      'data',
      'wallpapers',
      'items',
      'results',
      'images',
    ]) {
      final dynamic value = map[key];
      if (value is List) return value;
      if (value is Map) {
        for (final String nestedKey in const <String>[
          'wallpapers',
          'items',
          'results',
          'images',
        ]) {
          final dynamic nested = value[nestedKey];
          if (nested is List) return nested;
        }
      }
    }

    return const <dynamic>[];
  }

  bool _isMobileItem(Map<String, dynamic> item) {
    final List<String> deviceValues = <String>[];

    for (final String key in const <String>[
      'device',
      'device_type',
      'deviceType',
      'platform',
      'target',
      'screen_type',
      'screenType',
      'orientation',
      'type',
    ]) {
      final dynamic value = item[key];
      if (value != null) {
        deviceValues.add(value.toString().trim().toLowerCase());
      }
    }

    if (deviceValues.any(
      (String value) => value.contains('pc') ||
          value.contains('desktop') ||
          value.contains('computer') ||
          value.contains('landscape'),
    )) {
      return false;
    }

    if (deviceValues.any(
      (String value) => value.contains('mobile') ||
          value.contains('phone') ||
          value.contains('telefon') ||
          value.contains('portrait') ||
          value.contains('vertical'),
    )) {
      return true;
    }

    final double? width = _number(item['width'] ?? item['image_width']);
    final double? height = _number(item['height'] ?? item['image_height']);
    if (width != null && height != null && width > 0 && height > 0) {
      return height >= width;
    }

    // API cagrisi zaten ?device=mobile ile yapiliyor. Cevap cihaz alanini
    // tekrar etmiyorsa sunucunun mobil filtresine guveniyoruz.
    return true;
  }

  String? _firstString(Map<String, dynamic> item, List<String> keys) {
    for (final String key in keys) {
      final dynamic value = item[key];
      if (value == null) continue;
      final String text = value.toString().trim();
      if (text.isNotEmpty && text.toLowerCase() != 'null') return text;
    }
    return null;
  }

  double? _number(dynamic value) {
    if (value is num) return value.toDouble();
    if (value == null) return null;
    return double.tryParse(value.toString());
  }

  String _absoluteUrl(String raw) {
    final Uri? parsed = Uri.tryParse(raw);
    if (parsed != null && parsed.hasScheme) return parsed.toString();
    return Uri.parse(AppConfig.siteBaseUrl).resolve(raw).toString();
  }
}
