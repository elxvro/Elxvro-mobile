import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class ElxvroLogo extends StatelessWidget {
  const ElxvroLogo({super.key, this.compact = false});

  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Container(
          width: compact ? 34 : 46,
          height: compact ? 34 : 46,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(compact ? 11 : 15),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: <Color>[AppTheme.primary, AppTheme.accent],
            ),
          ),
          child: Text(
            'E',
            style: TextStyle(
              fontSize: compact ? 19 : 26,
              fontWeight: FontWeight.w900,
              color: Colors.white,
            ),
          ),
        ),
        const SizedBox(width: 12),
        Text(
          'ELXVRO',
          style: TextStyle(
            letterSpacing: 2.4,
            fontSize: compact ? 17 : 24,
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    );
  }
}
