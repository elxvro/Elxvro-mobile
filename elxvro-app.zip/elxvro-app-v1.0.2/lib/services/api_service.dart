import 'package:http/http.dart' as http;

import '../config/app_config.dart';

class ApiService {
  const ApiService();

  Future<void> checkConnection() async {
    final Uri uri = Uri.parse(AppConfig.categoriesUrl);

    final http.Response response = await http.get(
      uri,
      headers: const <String, String>{'Accept': 'application/json'},
    ).timeout(const Duration(seconds: 15));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('ELXVRO API HTTP ${response.statusCode} hatasi verdi.');
    }

    if (response.body.trim().isEmpty) {
      throw Exception('ELXVRO API bos cevap verdi.');
    }
  }
}
