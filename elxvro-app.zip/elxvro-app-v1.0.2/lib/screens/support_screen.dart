import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class SupportScreen extends StatelessWidget {
  const SupportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 110),
      children: <Widget>[
        const Text('Destek Merkezi', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
        const SizedBox(height: 7),
        const Text(
          'Sorun bildir, yardim al veya mevcut destek taleplerini goruntule.',
          style: TextStyle(color: AppTheme.muted, height: 1.45),
        ),
        const SizedBox(height: 22),
        Card(
          child: ListTile(
            contentPadding: const EdgeInsets.all(18),
            leading: const CircleAvatar(child: Icon(Icons.add_comment_outlined)),
            title: const Text('Yeni destek talebi', style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: const Padding(
              padding: EdgeInsets.only(top: 5),
              child: Text('API baglandiginda web destek sistemiyle ortak calisacak.'),
            ),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () {},
          ),
        ),
        const SizedBox(height: 12),
        Card(
          child: ListTile(
            contentPadding: const EdgeInsets.all(18),
            leading: const CircleAvatar(child: Icon(Icons.history_rounded)),
            title: const Text('Taleplerim', style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: const Padding(
              padding: EdgeInsets.only(top: 5),
              child: Text('Onceki destek gorusmelerini burada listele.'),
            ),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () {},
          ),
        ),
      ],
    );
  }
}
