import 'package:flutter/material.dart';

import '../config/app_config.dart';
import '../theme/app_theme.dart';
import 'login_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 110),
      children: <Widget>[
        const CircleAvatar(
          radius: 38,
          backgroundColor: AppTheme.surfaceAlt,
          child: Icon(Icons.person_rounded, size: 40),
        ),
        const SizedBox(height: 14),
        const Center(
          child: Text('ELXVRO User', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
        ),
        const SizedBox(height: 4),
        const Center(child: Text('user@elxvro.app', style: TextStyle(color: AppTheme.muted))),
        const SizedBox(height: 24),
        Card(
          child: Column(
            children: <Widget>[
              ListTile(
                leading: const Icon(Icons.manage_accounts_outlined),
                title: const Text('Hesap ayarlari'),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () {},
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.notifications_none_rounded),
                title: const Text('Bildirim ayarlari'),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () {},
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.info_outline_rounded),
                title: const Text('Uygulama surumu'),
                trailing: const Text(AppConfig.version, style: TextStyle(color: AppTheme.muted)),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        OutlinedButton.icon(
          onPressed: () {
            Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute<void>(builder: (_) => const LoginScreen()),
              (_) => false,
            );
          },
          icon: const Icon(Icons.logout_rounded),
          label: const Text('Cikis Yap'),
          style: OutlinedButton.styleFrom(
            minimumSize: const Size.fromHeight(52),
            foregroundColor: const Color(0xFFFF7B86),
            side: const BorderSide(color: Color(0xFF5B3038)),
          ),
        ),
      ],
    );
  }
}
