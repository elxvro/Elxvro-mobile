import 'package:flutter/material.dart';

import '../config/app_config.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import '../widgets/elxvro_logo.dart';
import 'shell_screen.dart';

class ApiGateScreen extends StatefulWidget {
  const ApiGateScreen({super.key});

  @override
  State<ApiGateScreen> createState() => _ApiGateScreenState();
}

class _ApiGateScreenState extends State<ApiGateScreen> {
  final ApiService _api = const ApiService();
  String? _error;

  @override
  void initState() {
    super.initState();
    _connect();
  }

  Future<void> _connect() async {
    setState(() => _error = null);

    try {
      await _api.checkConnection();
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(builder: (_) => const ShellScreen()),
      );
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 460),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  const Center(child: ElxvroLogo()),
                  const SizedBox(height: 38),
                  Text(
                    _error == null ? 'ELXVRO\'ya baglaniyor' : 'Baglanti kurulamadi',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    _error == null
                        ? 'Web v4.7.1 API baglantisi kontrol ediliyor.'
                        : _error!,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: AppTheme.muted,
                      height: 1.45,
                    ),
                  ),
                  const SizedBox(height: 26),
                  if (_error == null)
                    const Center(child: CircularProgressIndicator())
                  else
                    FilledButton.icon(
                      onPressed: _connect,
                      icon: const Icon(Icons.refresh_rounded),
                      label: const Text('Tekrar Dene'),
                    ),
                  const SizedBox(height: 18),
                  const Text(
                    AppConfig.apiBaseUrl,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: AppTheme.muted,
                      fontSize: 11.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
