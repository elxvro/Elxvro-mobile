class AppConfig {
  const AppConfig._();

  static const String appName = 'ELXVRO';
  static const String version = '1.0.2';

  // ELXVRO Web v4.7.1 API adresi uygulamaya sabitlendi.
  static const String apiBaseUrl = 'https://www.elxvro.com/api/v1';

  // Mevcut web API yapisinda baglanti kontrolu icin kullanilan PHP ucu.
  static const String categoriesEndpoint = 'categories.php';

  static String get categoriesUrl => '$apiBaseUrl/$categoriesEndpoint';
}
