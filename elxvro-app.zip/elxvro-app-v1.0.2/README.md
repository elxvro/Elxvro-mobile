# ELXVRO App v1.0.2

ELXVRO Web v4.7.1 icin Flutter mobil/PC istemci baslangic paketi.

## Sabit API

Uygulama artik kullanicidan API adresi istemez.

API tabani:

`https://www.elxvro.com/api/v1`

Acilista `categories.php` ucu ile baglantiyi otomatik kontrol eder. Baglanti basariliysa ELXVRO arayuzune gecer.

## Not

Bu surumde web kullanici girisi henuz uygulamaya baglanmamistir. Mevcut API yapisinda login endpoint'i netlestirildiginde hesap girisi ayri surumde eklenecektir.

## APK

GitHub Actions ile Flutter release APK uretebilirsiniz.
