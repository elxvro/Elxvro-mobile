import 'package:elxvro/main.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('ELXVRO login screen opens', (WidgetTester tester) async {
    await tester.pumpWidget(const ElxvroApp());
    expect(find.text('ELXVRO'), findsOneWidget);
    expect(find.text('Giris Yap'), findsOneWidget);
  });
}
