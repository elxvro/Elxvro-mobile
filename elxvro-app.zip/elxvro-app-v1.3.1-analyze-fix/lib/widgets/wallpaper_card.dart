import 'package:flutter/material.dart';

import '../models/wallpaper.dart';
import '../theme/app_theme.dart';
import '../widgets/fast_network_image.dart';
import '../screens/wallpaper_detail_screen.dart';

class WallpaperCard extends StatelessWidget {
  const WallpaperCard({
    super.key,
    required this.wallpaper,
    required this.cacheWidth,
    this.showCategory = true,
    this.borderRadius = 20,
  });

  final Wallpaper wallpaper;
  final int cacheWidth;
  final bool showCategory;
  final double borderRadius;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppTheme.surfaceAlt,
      borderRadius: BorderRadius.circular(borderRadius),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (_) => WallpaperDetailScreen(wallpaper: wallpaper),
            ),
          );
        },
        child: Stack(
          fit: StackFit.expand,
          children: <Widget>[
            FastNetworkImage(
              url: wallpaper.thumbnailUrl,
              fit: BoxFit.cover,
              memCacheWidth: cacheWidth,
              diskCacheWidth: cacheWidth.clamp(360, 1080).toInt(),
            ),
            const Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    stops: <double>[0.45, 1],
                    colors: <Color>[Colors.transparent, Color(0xE8000000)],
                  ),
                ),
              ),
            ),
            const Positioned(
              top: 10,
              left: 10,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: Color(0xB812141A),
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                ),
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                  child: Text(
                    'MOBİL',
                    style: TextStyle(
                      fontSize: 9,
                      letterSpacing: 0.8,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 11,
              right: 11,
              bottom: 11,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Text(
                    wallpaper.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800),
                  ),
                  if (showCategory && wallpaper.category.trim().isNotEmpty) ...<Widget>[
                    const SizedBox(height: 3),
                    Text(
                      wallpaper.category,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 10, color: AppTheme.muted),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
