import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../config/app_config.dart';
import '../services/browser_service.dart';
import '../services/google_auth_service.dart';
import '../theme/app_theme.dart';
import '../widgets/elxvro_logo.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  static const BrowserService _browser = BrowserService();
  final GoogleAuthService _auth = GoogleAuthService.instance;
  bool _acceptedTerms = false;

  Future<void> _open(String url) async {
    try {
      await _browser.open(url);
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString().replaceFirst('Exception: ', ''))),
      );
    }
  }

  Future<void> _signIn() async {
    try {
      await _auth.signIn();
    } catch (_) {
      if (!mounted) return;
      final String message = _auth.lastError.value ?? 'Google ile giriş yapılamadı.';
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
    }
  }

  Future<void> _signOut() async {
    try {
      await _auth.signOut();
    } catch (_) {
      if (!mounted) return;
      final String message = _auth.lastError.value ?? 'Çıkış yapılamadı.';
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<GoogleSignInAccount?>(
      valueListenable: _auth.account,
      builder: (BuildContext context, GoogleSignInAccount? user, Widget? child) {
        return ValueListenableBuilder<bool>(
          valueListenable: _auth.busy,
          builder: (BuildContext context, bool busy, Widget? child) {
            return ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 118),
              children: <Widget>[
                _ProfileHero(user: user),
                const SizedBox(height: 16),
                if (user == null)
                  _SignInCard(
                    busy: busy,
                    acceptedTerms: _acceptedTerms,
                    onAcceptedChanged: (bool value) => setState(() => _acceptedTerms = value),
                    onSignIn: _signIn,
                  )
                else
                  _ConnectedAccountCard(user: user, busy: busy, onSignOut: _signOut),
                const SizedBox(height: 16),
                const _AppStatusCard(),
                const SizedBox(height: 16),
                _SettingsCard(onOpen: _open),
              ],
            );
          },
        );
      },
    );
  }
}

class _ProfileHero extends StatelessWidget {
  const _ProfileHero({required this.user});

  final GoogleSignInAccount? user;

  @override
  Widget build(BuildContext context) {
    final String name = user?.displayName?.trim().isNotEmpty == true
        ? user!.displayName!.trim()
        : 'ELXVRO Profil';
    final String subtitle = user?.email ?? 'Google hesabınla ELXVRO deneyimini tamamla.';

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[Color(0xFF211947), Color(0xFF10252D)],
        ),
        border: Border.all(color: const Color(0x337C5CFF)),
      ),
      child: Row(
        children: <Widget>[
          _Avatar(user: user),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  user == null ? 'PROFİL' : 'BAĞLI HESAP',
                  style: const TextStyle(
                    color: AppTheme.accent,
                    fontSize: 9.5,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.4,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: AppTheme.muted, height: 1.35, fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SignInCard extends StatelessWidget {
  const _SignInCard({
    required this.busy,
    required this.acceptedTerms,
    required this.onAcceptedChanged,
    required this.onSignIn,
  });

  final bool busy;
  final bool acceptedTerms;
  final ValueChanged<bool> onAcceptedChanged;
  final Future<void> Function() onSignIn;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            const Text('Google ile devam et', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            const Text(
              'Hesap seçici uygulama içinde açılır. Şifren ELXVRO ile paylaşılmaz.',
              style: TextStyle(color: AppTheme.muted, height: 1.4, fontSize: 12),
            ),
            const SizedBox(height: 12),
            CheckboxListTile(
              value: acceptedTerms,
              contentPadding: EdgeInsets.zero,
              controlAffinity: ListTileControlAffinity.leading,
              onChanged: busy ? null : (bool? value) => onAcceptedChanged(value ?? false),
              title: const Text(
                'Kullanım Koşulları, Gizlilik Politikası ve KVKK metnini kabul ediyorum.',
                style: TextStyle(fontSize: 12, height: 1.35),
              ),
            ),
            const SizedBox(height: 8),
            FilledButton.icon(
              onPressed: busy || !acceptedTerms ? null : onSignIn,
              icon: busy
                  ? const SizedBox.square(
                      dimension: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.login_rounded),
              label: Text(busy ? 'Google açılıyor...' : 'Google ile Giriş Yap'),
            ),
          ],
        ),
      ),
    );
  }
}

class _ConnectedAccountCard extends StatelessWidget {
  const _ConnectedAccountCard({required this.user, required this.busy, required this.onSignOut});

  final GoogleSignInAccount user;
  final bool busy;
  final Future<void> Function() onSignOut;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: <Widget>[
            Row(
              children: <Widget>[
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: const Color(0x2453D8FB),
                    borderRadius: BorderRadius.circular(13),
                  ),
                  child: const Icon(Icons.verified_rounded, color: AppTheme.accent),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      const Text('Google hesabı bağlı', style: TextStyle(fontWeight: FontWeight.w900)),
                      const SizedBox(height: 3),
                      Text(user.email, style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            OutlinedButton.icon(
              onPressed: busy ? null : onSignOut,
              icon: const Icon(Icons.logout_rounded),
              label: const Text('Çıkış Yap'),
            ),
          ],
        ),
      ),
    );
  }
}

class _AppStatusCard extends StatelessWidget {
  const _AppStatusCard();

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const Row(
              children: <Widget>[
                ElxvroLogo(compact: true),
                Spacer(),
                _StatusBadge(),
              ],
            ),
            const SizedBox(height: 18),
            const Row(
              children: <Widget>[
                Expanded(
                  child: _StatusItem(
                    icon: Icons.phone_android_rounded,
                    title: 'Mobil',
                    subtitle: 'ELX-M',
                  ),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: _StatusItem(
                    icon: Icons.cloud_done_rounded,
                    title: 'Media Pack',
                    subtitle: 'App API',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Text(
              'ELXVRO v${AppConfig.version}',
              style: const TextStyle(color: AppTheme.muted, fontSize: 11),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  const _StatusBadge();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0x2453D8FB),
        borderRadius: BorderRadius.circular(999),
      ),
      child: const Text(
        'HAZIR',
        style: TextStyle(color: AppTheme.accent, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1),
      ),
    );
  }
}

class _StatusItem extends StatelessWidget {
  const _StatusItem({required this.icon, required this.title, required this.subtitle});

  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: AppTheme.surfaceAlt,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: <Widget>[
          Icon(icon, size: 21, color: AppTheme.accent),
          const SizedBox(width: 9),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(title, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800)),
                Text(subtitle, style: const TextStyle(color: AppTheme.muted, fontSize: 10)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SettingsCard extends StatelessWidget {
  const _SettingsCard({required this.onOpen});

  final Future<void> Function(String url) onOpen;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Column(
        children: <Widget>[
          ListTile(
            leading: const Icon(Icons.privacy_tip_outlined),
            title: const Text('Gizlilik Politikası'),
            subtitle: const Text('Veri ve gizlilik bilgileri'),
            trailing: const Icon(Icons.open_in_new_rounded, size: 19),
            onTap: () => onOpen(AppConfig.privacyUrl),
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.description_outlined),
            title: const Text('Kullanım Koşulları'),
            trailing: const Icon(Icons.open_in_new_rounded, size: 19),
            onTap: () => onOpen(AppConfig.termsUrl),
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.gavel_rounded),
            title: const Text('KVKK'),
            trailing: const Icon(Icons.open_in_new_rounded, size: 19),
            onTap: () => onOpen(AppConfig.kvkkUrl),
          ),
          const Divider(height: 1),
          const ListTile(
            leading: Icon(Icons.info_outline_rounded),
            title: Text('Uygulama sürümü'),
            trailing: Text(AppConfig.version, style: TextStyle(color: AppTheme.muted)),
          ),
        ],
      ),
    );
  }
}

class _Avatar extends StatelessWidget {
  const _Avatar({required this.user});

  final GoogleSignInAccount? user;

  @override
  Widget build(BuildContext context) {
    final String? photo = user?.photoUrl;
    if (photo != null && photo.trim().isNotEmpty) {
      return Container(
        width: 68,
        height: 68,
        padding: const EdgeInsets.all(3),
        decoration: const BoxDecoration(shape: BoxShape.circle, gradient: AppTheme.brandGradient),
        child: CircleAvatar(backgroundImage: NetworkImage(photo), backgroundColor: AppTheme.surfaceAlt),
      );
    }

    return Container(
      width: 68,
      height: 68,
      decoration: const BoxDecoration(shape: BoxShape.circle, gradient: AppTheme.brandGradient),
      alignment: Alignment.center,
      child: Text(
        user?.displayName?.trim().isNotEmpty == true
            ? user!.displayName!.trim().characters.first.toUpperCase()
            : 'E',
        style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: Colors.white),
      ),
    );
  }
}
