import 'package:flutter/material.dart';

import '../models/announcement.dart';
import '../theme/app_theme.dart';

class AnnouncementsScreen extends StatelessWidget {
  const AnnouncementsScreen({super.key});

  static const List<Announcement> _items = <Announcement>[
    Announcement(
      title: 'ELXVRO v1.3.0 Visual Refresh',
      body: 'Yeni uygulama kimliği, görselli kategori kartları, Keşfet bölümü ve yenilenen profil ekranı kullanıma hazır.',
      date: '14 Eylül 2026',
    ),
    Announcement(
      title: 'App API + Mobile Media Pack',
      body: 'Android uygulaması artık ELX-M mobil medya paketini kullanıyor. Ana sayfa, kategoriler ve duvar kağıdı uygulama akışı aynı sunucu katmanında çalışıyor.',
      date: '14 Eylül 2026',
    ),
    Announcement(
      title: 'Native Google Giriş',
      body: 'Google hesabı uygulama içinden seçiliyor ve profil ekranında bağlı hesap bilgileri gösteriliyor.',
      date: 'ELXVRO Mobile',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 118),
      children: <Widget>[
        const _AnnouncementHero(),
        const SizedBox(height: 22),
        const Row(
          children: <Widget>[
            Text('Son duyurular', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            Spacer(),
            Text(
              'ELXVRO',
              style: TextStyle(color: AppTheme.accent, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1.4),
            ),
          ],
        ),
        const SizedBox(height: 12),
        for (int index = 0; index < _items.length; index++) ...<Widget>[
          _AnnouncementCard(item: _items[index], latest: index == 0),
          if (index != _items.length - 1) const SizedBox(height: 12),
        ],
      ],
    );
  }
}

class _AnnouncementHero extends StatelessWidget {
  const _AnnouncementHero();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[Color(0xFF201A42), Color(0xFF0E2630)],
        ),
        border: Border.all(color: const Color(0x337C5CFF)),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              _HeroIcon(),
              Spacer(),
              _LiveBadge(),
            ],
          ),
          SizedBox(height: 22),
          Text(
            'Duyurular',
            style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900),
          ),
          SizedBox(height: 7),
          Text(
            'Yeni sürümler ve ELXVRO uygulama değişiklikleri burada yayınlanır.',
            style: TextStyle(color: AppTheme.muted, height: 1.45),
          ),
        ],
      ),
    );
  }
}

class _HeroIcon extends StatelessWidget {
  const _HeroIcon();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 48,
      height: 48,
      decoration: BoxDecoration(
        gradient: AppTheme.brandGradient,
        borderRadius: BorderRadius.circular(16),
      ),
      child: const Icon(Icons.campaign_rounded, color: Colors.white),
    );
  }
}

class _LiveBadge extends StatelessWidget {
  const _LiveBadge();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: const Color(0x1FFFFFFF),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0x28FFFFFF)),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(Icons.circle, size: 7, color: AppTheme.accent),
          SizedBox(width: 6),
          Text('GÜNCEL', style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w900, letterSpacing: 1)),
        ],
      ),
    );
  }
}

class _AnnouncementCard extends StatelessWidget {
  const _AnnouncementCard({required this.item, required this.latest});

  final Announcement item;
  final bool latest;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: latest ? const Color(0x297C5CFF) : AppTheme.surfaceAlt,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(
                latest ? Icons.auto_awesome_rounded : Icons.notifications_none_rounded,
                color: latest ? AppTheme.accent : AppTheme.muted,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  if (latest) ...<Widget>[
                    const Text(
                      'YENİ',
                      style: TextStyle(color: AppTheme.accent, fontSize: 9.5, fontWeight: FontWeight.w900, letterSpacing: 1.3),
                    ),
                    const SizedBox(height: 4),
                  ],
                  Text(item.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 7),
                  Text(item.body, style: const TextStyle(color: AppTheme.muted, height: 1.45)),
                  const SizedBox(height: 11),
                  Text(
                    item.date,
                    style: const TextStyle(fontSize: 10.5, color: AppTheme.accent, fontWeight: FontWeight.w700),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
