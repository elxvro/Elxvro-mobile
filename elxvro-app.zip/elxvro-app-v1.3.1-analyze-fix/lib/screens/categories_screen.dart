import 'package:flutter/material.dart';

import '../models/category.dart';
import '../models/wallpaper.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import '../widgets/fast_network_image.dart';
import 'category_wallpapers_screen.dart';

class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key});

  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  final ApiService _api = const ApiService();

  bool _loading = true;
  String? _error;
  List<WallpaperCategory> _categories = const <WallpaperCategory>[];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load({bool forceRefresh = false}) async {
    if (_categories.isEmpty || forceRefresh) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }

    try {
      final List<WallpaperCategory> apiCategories = await _api.fetchCategories(
        forceRefresh: forceRefresh,
      );

      List<Wallpaper> mobile = const <Wallpaper>[];
      try {
        mobile = await _api.fetchMobileWallpapers(forceRefresh: forceRefresh);
      } catch (_) {
        // Kategori listesi yine de kullanılabilir; yalnızca kapak fallback'i eksik kalır.
      }

      final List<WallpaperCategory> visible = <WallpaperCategory>[];
      final Set<String> used = <String>{};

      for (final WallpaperCategory category in apiCategories) {
        final String nameKey = _normalize(category.name);
        final String slugKey = _normalize(category.slug);
        final String idKey = _normalize(category.id);
        final String uniqueKey = slugKey.isNotEmpty ? slugKey : nameKey;
        if (uniqueKey.isEmpty || !used.add(uniqueKey)) continue;

        final Set<String> wanted = <String>{nameKey, slugKey, idKey}
          ..removeWhere((String value) => value.isEmpty);
        Wallpaper? firstMatch;
        int mobileCount = 0;

        for (final Wallpaper wallpaper in mobile) {
          final Set<String> values = <String>{
            _normalize(wallpaper.category),
            ...wallpaper.categoryKeys.map(_normalize),
          }..removeWhere((String value) => value.isEmpty);

          bool matches = values.any(wanted.contains);
          if (!matches) {
            matches = values.any(
              (String value) => wanted.any(
                (String target) => target.length >= 3 &&
                    value.length >= 3 &&
                    (value.contains(target) || target.contains(value)),
              ),
            );
          }
          if (!matches) continue;
          mobileCount++;
          firstMatch ??= wallpaper;
        }

        visible.add(
          WallpaperCategory(
            id: category.id,
            name: category.name,
            slug: category.slug,
            icon: category.icon,
            coverUrl: category.coverUrl ?? firstMatch?.thumbnailUrl,
            mobileCount: mobile.isEmpty ? category.mobileCount : mobileCount,
          ),
        );
      }

      if (visible.isEmpty && mobile.isNotEmpty) {
        final Map<String, List<Wallpaper>> grouped = <String, List<Wallpaper>>{};
        for (final Wallpaper item in mobile) {
          final String key = _normalize(item.category);
          if (key.isEmpty || key == 'mobil') continue;
          grouped.putIfAbsent(key, () => <Wallpaper>[]).add(item);
        }
        for (final MapEntry<String, List<Wallpaper>> entry in grouped.entries) {
          visible.add(
            WallpaperCategory(
              id: entry.key,
              name: _displayName(entry.key),
              slug: entry.key,
              coverUrl: entry.value.first.thumbnailUrl,
              mobileCount: entry.value.length,
            ),
          );
        }
      }

      if (!mounted) return;
      setState(() {
        _categories = visible;
        _error = null;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() => _error = error.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _normalize(String value) {
    String text = value.toLowerCase().trim();
    const Map<String, String> replacements = <String, String>{
      'ç': 'c',
      'ğ': 'g',
      'ı': 'i',
      'ö': 'o',
      'ş': 's',
      'ü': 'u',
    };
    replacements.forEach((String from, String to) {
      text = text.replaceAll(from, to);
    });
    return text.replaceAll(RegExp(r'[^a-z0-9]+'), '-').replaceAll(RegExp(r'^-+|-+$'), '');
  }

  String _displayName(String slug) {
    if (slug.isEmpty) return 'Kategori';
    return slug
        .split('-')
        .where((String part) => part.isNotEmpty)
        .map((String part) => '${part[0].toUpperCase()}${part.substring(1)}')
        .join(' ');
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () => _load(forceRefresh: true),
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 118),
        children: <Widget>[
          const Text(
            'KATEGORİLER',
            style: TextStyle(
              color: AppTheme.accent,
              fontSize: 11,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.8,
            ),
          ),
          const SizedBox(height: 5),
          const Text('Tarzını seç.', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900)),
          const SizedBox(height: 7),
          const Text(
            'Her kategori kendi mobil kapak görseliyle gösterilir.',
            style: TextStyle(color: AppTheme.muted, height: 1.4),
          ),
          const SizedBox(height: 20),
          if (_loading && _categories.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 90),
              child: Center(child: CircularProgressIndicator()),
            )
          else if (_error != null && _categories.isEmpty)
            _CategoryError(message: _error!, onRetry: () => _load(forceRefresh: true))
          else if (_categories.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 80),
              child: Center(
                child: Text('Kategori bulunamadı.', style: TextStyle(color: AppTheme.muted)),
              ),
            )
          else
            LayoutBuilder(
              builder: (BuildContext context, BoxConstraints constraints) {
                final int columns = constraints.maxWidth >= 760 ? 3 : 2;
                final double cellWidth =
                    (constraints.maxWidth - ((columns - 1) * 12)) / columns;
                final int cacheWidth = (cellWidth * MediaQuery.devicePixelRatioOf(context))
                    .round()
                    .clamp(300, 850)
                    .toInt();
                return GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: _categories.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: columns,
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: 0.82,
                  ),
                  itemBuilder: (BuildContext context, int index) {
                    return RepaintBoundary(
                      child: _CategoryCard(
                        category: _categories[index],
                        cacheWidth: cacheWidth,
                      ),
                    );
                  },
                );
              },
            ),
        ],
      ),
    );
  }
}

class _CategoryCard extends StatelessWidget {
  const _CategoryCard({required this.category, required this.cacheWidth});

  final WallpaperCategory category;
  final int cacheWidth;

  IconData _fallbackIcon(String slug) {
    final String value = slug.toLowerCase();
    if (value.contains('anime')) return Icons.auto_awesome_rounded;
    if (value.contains('doga') || value.contains('doğa')) return Icons.landscape_rounded;
    if (value.contains('hayvan')) return Icons.pets_rounded;
    if (value.contains('sehir') || value.contains('şehir')) return Icons.location_city_rounded;
    if (value.contains('arac') || value.contains('araç')) return Icons.directions_car_filled_rounded;
    if (value.contains('oyun')) return Icons.sports_esports_rounded;
    if (value.contains('uzay')) return Icons.rocket_launch_rounded;
    if (value.contains('minimal')) return Icons.crop_square_rounded;
    if (value.contains('soyut')) return Icons.blur_on_rounded;
    return Icons.collections_rounded;
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppTheme.surfaceAlt,
      borderRadius: BorderRadius.circular(24),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (_) => CategoryWallpapersScreen(category: category),
            ),
          );
        },
        child: Stack(
          fit: StackFit.expand,
          children: <Widget>[
            if (category.coverUrl != null)
              FastNetworkImage(
                url: category.coverUrl!,
                fit: BoxFit.cover,
                memCacheWidth: cacheWidth,
                diskCacheWidth: cacheWidth.clamp(480, 1080).toInt(),
              )
            else
              const DecoratedBox(decoration: BoxDecoration(gradient: AppTheme.brandGradient)),
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  stops: <double>[0.25, 1],
                  colors: <Color>[Color(0x16000000), Color(0xF3000000)],
                ),
              ),
            ),
            Positioned(
              left: 14,
              top: 14,
              child: Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: const Color(0xB20C0F15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0x33FFFFFF)),
                ),
                child: Icon(_fallbackIcon(category.slug), size: 20, color: Colors.white),
              ),
            ),
            Positioned(
              left: 15,
              right: 15,
              bottom: 15,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Text(
                    category.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 5),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Text(
                          category.mobileCount == null
                              ? 'Mobil koleksiyon'
                              : '${category.mobileCount} mobil görsel',
                          style: const TextStyle(color: AppTheme.muted, fontSize: 11.5),
                        ),
                      ),
                      const Icon(Icons.arrow_forward_rounded, size: 18, color: AppTheme.accent),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CategoryError extends StatelessWidget {
  const _CategoryError({required this.message, required this.onRetry});

  final String message;
  final Future<void> Function() onRetry;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 60),
      child: Column(
        children: <Widget>[
          const Icon(Icons.cloud_off_rounded, size: 42, color: AppTheme.muted),
          const SizedBox(height: 12),
          Text(message, textAlign: TextAlign.center),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: () => onRetry(),
            icon: const Icon(Icons.refresh_rounded),
            label: const Text('Tekrar Dene'),
          ),
        ],
      ),
    );
  }
}
