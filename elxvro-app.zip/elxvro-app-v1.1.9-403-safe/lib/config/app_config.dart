class AppConfig {
  const AppConfig._();

  static const String appName = 'ELXVRO';
  static const String version = '1.1.9';

  static const String siteBaseUrl = 'https://www.elxvro.com/';
  static const String apiBaseUrl = 'https://www.elxvro.com/api/v1';

  static const String googleAndroidClientId =
      '227765065065-r5o01nbld8jubjio4b5pflnvsk27d7me.apps.googleusercontent.com';
  static const String googleWebClientId =
      '227765065065-3r92i04nkfc3nbnfs3hu28uf5jpvl7c4.apps.googleusercontent.com';

  static const String loginUrl = 'https://www.elxvro.com/login.php';
  static const String supportUrl = 'https://www.elxvro.com/contact.php';
  static const String privacyUrl = 'https://www.elxvro.com/privacy.php';
  static const String termsUrl = 'https://www.elxvro.com/terms.php';
  static const String kvkkUrl = 'https://www.elxvro.com/kvkk.php';

  static const String categoriesEndpoint = 'categories.php';
  static const String wallpapersEndpoint = 'wallpapers.php';
  static const String wallpaperEndpoint = 'wallpaper.php';

  static Uri get categoriesUri => Uri.parse('$apiBaseUrl/$categoriesEndpoint');


  static Uri wallpaperUri({String? id, String? slug}) {
    final Map<String, String> params = <String, String>{};
    final String normalizedId = id?.trim() ?? '';
    final String normalizedSlug = slug?.trim() ?? '';
    if (normalizedId.isNotEmpty) {
      params['id'] = normalizedId;
    } else if (normalizedSlug.isNotEmpty) {
      params['slug'] = normalizedSlug;
    }
    return Uri.parse('$apiBaseUrl/$wallpaperEndpoint').replace(
      queryParameters: params.isEmpty ? null : params,
    );
  }

  static Uri mobileWallpapersUri({String? category}) {
    final Map<String, String> params = <String, String>{'device': 'mobile'};
    final String normalized = category?.trim() ?? '';
    if (normalized.isNotEmpty) params['category'] = normalized;

    return Uri.parse('$apiBaseUrl/$wallpapersEndpoint').replace(
      queryParameters: params,
    );
  }
}
