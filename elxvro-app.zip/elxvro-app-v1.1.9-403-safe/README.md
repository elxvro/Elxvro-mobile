# ELXVRO Mobile v1.1.9 — 403 Safe Wallpaper Fix

- v1.1.8 tekil wallpaper.php detay çözümleme kaldırıldı.
- download_url/original_url gibi korumalı adaylar wallpaper hazırlamada kullanılmıyor.
- Yalnızca listede çalışan imageUrl, gerekirse thumbnailUrl deneniyor.
- Native indirme başlıkları v1.1.4 çalışan sade yapıya geri döndürüldü.
- v1.1.7 kategori tamamlama, Wallpaper Fast, native Google giriş ve cache sistemi korunur.
