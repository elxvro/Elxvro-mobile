import 'package:elxvro/config/app_config.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('wallpaper endpoint uses App API pagination without legacy device query', () {
    final Uri uri = AppConfig.mobileWallpapersUri();

    expect(uri.scheme, 'https');
    expect(uri.host, 'www.elxvro.com');
    expect(uri.path, '/app-api/v1/wallpapers.php');
    expect(uri.queryParameters['page'], '1');
    expect(uri.queryParameters['limit'], '50');
    expect(uri.queryParameters.containsKey('device'), isFalse);
  });

  test('category is added while App API pagination is preserved', () {
    final Uri uri = AppConfig.mobileWallpapersUri(
      category: 'anime',
      page: 2,
      limit: 25,
    );

    expect(uri.path, '/app-api/v1/wallpapers.php');
    expect(uri.queryParameters['category'], 'anime');
    expect(uri.queryParameters['page'], '2');
    expect(uri.queryParameters['limit'], '25');
    expect(uri.queryParameters.containsKey('device'), isFalse);
  });

  test('App API and media pack bases are isolated from legacy API', () {
    expect(AppConfig.apiBaseUrl, 'https://www.elxvro.com/app-api/v1');
    expect(AppConfig.mediaBaseUrl, 'https://www.elxvro.com/app-api/media');
    expect(AppConfig.apiBaseUrl.contains('/api/v1'), isFalse);
  });

  test('app version is Visual Refresh', () {
    expect(AppConfig.version, '1.3.0');
  });
}
