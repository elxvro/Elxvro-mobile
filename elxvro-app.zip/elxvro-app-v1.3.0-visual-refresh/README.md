# ELXVRO Android v1.3.0 — Visual Refresh

Bu paket çalışan v1.2.1 App API + Mobile Media Pack tabanının görsel yenilemesidir.

- Yeni ELXVRO uygulama ikonu ve uygulama içi splash
- Yenilenmiş ana sayfa ve görsel kartları
- Görselli kategori kartları; kapak yoksa kategorinin ilk ELX-M görseli kullanılır
- Destek sekmesi kaldırıldı
- Duyurular sekmesi yenilendi
- Yeni Keşfet sekmesi eklendi
- Profil ekranı baştan düzenlendi
- App API / Media Pack / Google giriş / native wallpaper akışı korunur

GitHub deposunda bu ZIP `elxvro-app.zip` adıyla kullanılmalıdır.
