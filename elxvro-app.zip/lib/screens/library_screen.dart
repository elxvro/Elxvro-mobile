import 'package:flutter/material.dart';

import '../models/wallpaper.dart';
import '../services/local_library_service.dart';
import '../theme/app_theme.dart';
import '../widgets/wallpaper_card.dart';

class LibraryScreen extends StatelessWidget {
  const LibraryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'Koleksiyonum',
            style: TextStyle(fontWeight: FontWeight.w900),
          ),
          bottom: const TabBar(
            tabs: <Tab>[
              Tab(icon: Icon(Icons.favorite_rounded), text: 'Favoriler'),
              Tab(icon: Icon(Icons.history_rounded), text: 'Son bakılanlar'),
            ],
          ),
        ),
        body: const TabBarView(
          children: <Widget>[
            _LibraryTab(type: _LibraryType.favorites),
            _LibraryTab(type: _LibraryType.recent),
          ],
        ),
      ),
    );
  }
}

enum _LibraryType { favorites, recent }

class _LibraryTab extends StatelessWidget {
  const _LibraryTab({required this.type});

  final _LibraryType type;

  @override
  Widget build(BuildContext context) {
    final LocalLibraryService library = LocalLibraryService.instance;
    final ValueNotifier<List<Wallpaper>> listenable =
        type == _LibraryType.favorites ? library.favorites : library.recent;

    return ValueListenableBuilder<List<Wallpaper>>(
      valueListenable: listenable,
      builder: (BuildContext context, List<Wallpaper> items, Widget? child) {
        if (items.isEmpty) {
          return _EmptyLibrary(type: type);
        }

        return CustomScrollView(
          slivers: <Widget>[
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 10),
              sliver: SliverToBoxAdapter(
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Text(
                        type == _LibraryType.favorites
                            ? '${items.length} favori görsel'
                            : '${items.length} yakın zamanda görüntülendi',
                        style: const TextStyle(
                          color: AppTheme.muted,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    TextButton.icon(
                      onPressed: () => _confirmClear(context, library),
                      icon: const Icon(Icons.delete_sweep_outlined, size: 18),
                      label: const Text('Temizle'),
                    ),
                  ],
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 28),
              sliver: SliverLayoutBuilder(
                builder: (BuildContext context, SliverConstraints constraints) {
                  final double width = constraints.crossAxisExtent;
                  final int columns = width >= 760 ? 4 : (width >= 520 ? 3 : 2);
                  final double cellWidth =
                      (width - ((columns - 1) * 12)) / columns;
                  final int cacheWidth =
                      (cellWidth * MediaQuery.devicePixelRatioOf(context))
                          .round()
                          .clamp(360, 960)
                          .toInt();

                  return SliverGrid(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: columns,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      childAspectRatio: 0.60,
                    ),
                    delegate: SliverChildBuilderDelegate(
                      (BuildContext context, int index) {
                        return WallpaperCard(
                          wallpaper: items[index],
                          cacheWidth: cacheWidth,
                        );
                      },
                      childCount: items.length,
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  Future<void> _confirmClear(
    BuildContext context,
    LocalLibraryService library,
  ) async {
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: Text(
            type == _LibraryType.favorites
                ? 'Favoriler temizlensin mi?'
                : 'Geçmiş temizlensin mi?',
          ),
          content: Text(
            type == _LibraryType.favorites
                ? 'Kaydettiğin favori görseller bu cihazdan kaldırılır.'
                : 'Son görüntülediğin duvar kağıtları bu cihazdan kaldırılır.',
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Vazgeç'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Temizle'),
            ),
          ],
        );
      },
    );
    if (confirmed != true) return;
    if (type == _LibraryType.favorites) {
      await library.clearFavorites();
    } else {
      await library.clearRecent();
    }
  }
}

class _EmptyLibrary extends StatelessWidget {
  const _EmptyLibrary({required this.type});

  final _LibraryType type;

  @override
  Widget build(BuildContext context) {
    final bool favorites = type == _LibraryType.favorites;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                gradient: AppTheme.glassGradient,
                shape: BoxShape.circle,
                border: Border.all(color: AppTheme.border),
              ),
              child: Icon(
                favorites ? Icons.favorite_border_rounded : Icons.history_rounded,
                color: AppTheme.accent,
                size: 31,
              ),
            ),
            const SizedBox(height: 18),
            Text(
              favorites ? 'Henüz favorin yok' : 'Henüz görüntüleme geçmişi yok',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 8),
            Text(
              favorites
                  ? 'Beğendiğin duvar kağıtlarındaki kalp simgesine dokun. Burada saklanır.'
                  : 'Açtığın duvar kağıtları burada otomatik olarak listelenir.',
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppTheme.muted, height: 1.45),
            ),
          ],
        ),
      ),
    );
  }
}
