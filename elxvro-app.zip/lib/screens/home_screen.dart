import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/wallpaper.dart';
import '../services/api_service.dart';
import '../services/local_library_service.dart';
import '../theme/app_theme.dart';
import '../widgets/fast_network_image.dart';
import '../widgets/wallpaper_card.dart';
import 'wallpaper_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ApiService _api = const ApiService();
  final TextEditingController _searchController = TextEditingController();

  List<Wallpaper> _all = const <Wallpaper>[];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
    _searchController.addListener(_onSearchChanged);
  }

  void _onSearchChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _searchController
      ..removeListener(_onSearchChanged)
      ..dispose();
    super.dispose();
  }

  Future<void> _load({bool forceRefresh = false}) async {
    if (_all.isEmpty || forceRefresh) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }

    try {
      final List<Wallpaper> wallpapers = await _api.fetchMobileWallpapers(
        forceRefresh: forceRefresh,
      );
      if (!mounted) return;
      setState(() {
        _all = wallpapers;
        _error = null;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() => _error = error.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  List<Wallpaper> _visibleItems() {
    final String query = _searchController.text.trim().toLowerCase();
    if (query.isEmpty) return _all;
    return _all.where((Wallpaper item) {
      return item.title.toLowerCase().contains(query) ||
          item.category.toLowerCase().contains(query);
    }).toList(growable: false);
  }

  @override
  Widget build(BuildContext context) {
    final List<Wallpaper> visible = _visibleItems();
    final bool searching = _searchController.text.trim().isNotEmpty;

    return RefreshIndicator(
      onRefresh: () => _load(forceRefresh: true),
      child: CustomScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        slivers: <Widget>[
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
            sliver: SliverToBoxAdapter(
              child: _HomeHeader(
                count: _all.length,
                controller: _searchController,
              ),
            ),
          ),
          if (_loading && _all.isEmpty)
            const SliverFillRemaining(
              hasScrollBody: false,
              child: Center(child: CircularProgressIndicator()),
            )
          else if (_error != null && _all.isEmpty)
            SliverFillRemaining(
              hasScrollBody: false,
              child: _ErrorState(
                message: _error!,
                onRetry: () => _load(forceRefresh: true),
              ),
            )
          else if (visible.isEmpty)
            const SliverFillRemaining(
              hasScrollBody: false,
              child: _EmptyState(),
            )
          else ...<Widget>[
            if (!searching) ...<Widget>[
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                sliver: SliverToBoxAdapter(
                  child: _FeaturedWallpaper(wallpaper: _all.first),
                ),
              ),
              const SliverPadding(
                padding: EdgeInsets.fromLTRB(16, 22, 16, 11),
                sliver: SliverToBoxAdapter(
                  child: _SectionTitle(
                    title: 'Yeni seçkiler',
                    subtitle: 'Son eklenen premium mobil görseller',
                    icon: Icons.auto_awesome_rounded,
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: SizedBox(
                  height: 244,
                  child: ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    scrollDirection: Axis.horizontal,
                    itemCount: math.min(8, _all.length),
                    separatorBuilder: (_, __) => const SizedBox(width: 11),
                    itemBuilder: (BuildContext context, int index) {
                      return SizedBox(
                        width: 140,
                        child: WallpaperCard(
                          wallpaper: _all[index],
                          cacheWidth: 430,
                          showCategory: false,
                        ),
                      );
                    },
                  ),
                ),
              ),
              const SliverPadding(
                padding: EdgeInsets.fromLTRB(16, 26, 16, 11),
                sliver: SliverToBoxAdapter(
                  child: _SectionTitle(
                    title: 'Tüm koleksiyon',
                    subtitle: 'ELXVRO mobil seçkisi',
                    icon: Icons.grid_view_rounded,
                  ),
                ),
              ),
            ] else
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(16, 6, 16, 12),
                sliver: SliverToBoxAdapter(
                  child: Row(
                    children: <Widget>[
                      const Icon(Icons.search_rounded, size: 18, color: AppTheme.accent),
                      const SizedBox(width: 8),
                      Text(
                        '${visible.length} sonuç',
                        style: const TextStyle(
                          color: AppTheme.muted,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 118),
              sliver: SliverLayoutBuilder(
                builder: (BuildContext context, constraints) {
                  final double width = constraints.crossAxisExtent;
                  final int columns = width >= 900
                      ? 5
                      : width >= 650
                          ? 4
                          : width >= 430
                              ? 3
                              : 2;
                  final double cellWidth = (width - ((columns - 1) * 10)) / columns;
                  final int cacheWidth = (cellWidth * MediaQuery.devicePixelRatioOf(context))
                      .round()
                      .clamp(240, 720)
                      .toInt();

                  return SliverGrid(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: columns,
                      mainAxisSpacing: 10,
                      crossAxisSpacing: 10,
                      childAspectRatio: 0.58,
                    ),
                    delegate: SliverChildBuilderDelegate(
                      (BuildContext context, int index) => RepaintBoundary(
                        child: WallpaperCard(
                          wallpaper: visible[index],
                          cacheWidth: cacheWidth,
                        ),
                      ),
                      childCount: visible.length,
                    ),
                  );
                },
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _HomeHeader extends StatelessWidget {
  const _HomeHeader({required this.count, required this.controller});

  final int count;
  final TextEditingController controller;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 18),
      decoration: BoxDecoration(
        gradient: AppTheme.heroGradient,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: const Color(0x4436425A)),
        boxShadow: const <BoxShadow>[
          BoxShadow(
            color: Color(0x33000000),
            blurRadius: 28,
            offset: Offset(0, 14),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                decoration: BoxDecoration(
                  color: const Color(0x1A66E7FF),
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(color: const Color(0x3366E7FF)),
                ),
                child: const Text(
                  'ELXVRO COLLECTION',
                  style: TextStyle(
                    color: AppTheme.accent,
                    fontSize: 9.5,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.25,
                  ),
                ),
              ),
              const Spacer(),
              if (count > 0)
                Text(
                  '$count GÖRSEL',
                  style: const TextStyle(
                    color: AppTheme.muted,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.8,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 16),
          const Text(
            'Duvar kağıdın,\ntarzın olsun.',
            style: TextStyle(
              fontSize: 31,
              height: 1.05,
              fontWeight: FontWeight.w900,
              letterSpacing: -0.7,
            ),
          ),
          const SizedBox(height: 9),
          const Text(
            'Mobil ekranlar için seçilmiş yüksek çözünürlüklü ELX-M koleksiyonu.',
            style: TextStyle(color: AppTheme.muted, height: 1.42, fontSize: 12.5),
          ),
          const SizedBox(height: 18),
          TextField(
            controller: controller,
            textInputAction: TextInputAction.search,
            decoration: InputDecoration(
              hintText: 'Duvar kağıdı veya kategori ara',
              prefixIcon: const Icon(Icons.search_rounded),
              suffixIcon: controller.text.isEmpty
                  ? null
                  : IconButton(
                      onPressed: controller.clear,
                      icon: const Icon(Icons.close_rounded),
                    ),
            ),
          ),
        ],
      ),
    );
  }
}

class _FeaturedWallpaper extends StatelessWidget {
  const _FeaturedWallpaper({required this.wallpaper});

  final Wallpaper wallpaper;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: const Color(0x334F5E7A)),
        boxShadow: const <BoxShadow>[
          BoxShadow(
            color: Color(0x55000000),
            blurRadius: 24,
            offset: Offset(0, 12),
          ),
        ],
      ),
      child: Material(
        color: AppTheme.surfaceAlt,
        borderRadius: BorderRadius.circular(27),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () {
            unawaited(LocalLibraryService.instance.addRecent(wallpaper));
            Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => WallpaperDetailScreen(wallpaper: wallpaper),
              ),
            );
          },
          child: SizedBox(
            height: 258,
            child: Stack(
              fit: StackFit.expand,
              children: <Widget>[
                FastNetworkImage(
                  url: wallpaper.thumbnailUrl,
                  fit: BoxFit.cover,
                  diskCacheWidth: 1080,
                ),
                const DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      stops: <double>[0.1, 0.55, 1],
                      colors: <Color>[
                        Color(0x10000000),
                        Color(0x45000000),
                        Color(0xF9000000),
                      ],
                    ),
                  ),
                ),
                const Positioned(
                  left: 16,
                  top: 16,
                  child: _FeaturedBadge(),
                ),
                Positioned(
                  right: 14,
                  top: 14,
                  child: ValueListenableBuilder<List<Wallpaper>>(
                    valueListenable: LocalLibraryService.instance.favorites,
                    builder: (BuildContext context, List<Wallpaper> _, Widget? child) {
                      final bool favorite =
                          LocalLibraryService.instance.isFavorite(wallpaper);
                      return Material(
                        color: const Color(0xD20B0F16),
                        shape: const CircleBorder(),
                        clipBehavior: Clip.antiAlias,
                        child: InkWell(
                          onTap: () {
                            unawaited(
                              LocalLibraryService.instance.toggleFavorite(wallpaper),
                            );
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(10),
                            child: Icon(
                              favorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                              size: 20,
                              color: favorite ? AppTheme.accent : Colors.white,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                Positioned(
                  left: 18,
                  right: 18,
                  bottom: 18,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: <Widget>[
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            Text(
                              wallpaper.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                                letterSpacing: -0.35,
                              ),
                            ),
                            const SizedBox(height: 5),
                            Row(
                              children: <Widget>[
                                const Icon(
                                  Icons.collections_bookmark_rounded,
                                  color: AppTheme.accent,
                                  size: 15,
                                ),
                                const SizedBox(width: 6),
                                Expanded(
                                  child: Text(
                                    wallpaper.category,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: Color(0xFFD0D7E3),
                                      fontSize: 12,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          gradient: AppTheme.brandGradient,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: const <BoxShadow>[
                            BoxShadow(color: Color(0x557C6CFF), blurRadius: 18),
                          ],
                        ),
                        child: const Icon(Icons.arrow_forward_rounded, color: Colors.white),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _FeaturedBadge extends StatelessWidget {
  const _FeaturedBadge();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: const Color(0xD20B0F16),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0x3DFFFFFF)),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(Icons.auto_awesome_rounded, size: 13, color: AppTheme.accent),
          SizedBox(width: 6),
          Text(
            'ÖNE ÇIKAN',
            style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w900, letterSpacing: 1.1),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title, required this.subtitle, required this.icon});

  final String title;
  final String subtitle;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: const Color(0x1F6E6BFF),
            borderRadius: BorderRadius.circular(13),
            border: Border.all(color: const Color(0x286E6BFF)),
          ),
          child: Icon(icon, color: AppTheme.accent, size: 20),
        ),
        const SizedBox(width: 11),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(title, style: const TextStyle(fontSize: 17.5, fontWeight: FontWeight.w900)),
              const SizedBox(height: 2),
              Text(subtitle, style: const TextStyle(color: AppTheme.muted, fontSize: 11.5)),
            ],
          ),
        ),
      ],
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(Icons.image_search_rounded, size: 46, color: AppTheme.muted),
            SizedBox(height: 12),
            Text('Mobil görsel bulunamadı.', style: TextStyle(color: AppTheme.muted)),
          ],
        ),
      ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  const _ErrorState({required this.message, required this.onRetry});

  final String message;
  final Future<void> Function() onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const Icon(Icons.cloud_off_rounded, size: 46, color: AppTheme.muted),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: () => onRetry(),
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('Tekrar Dene'),
            ),
          ],
        ),
      ),
    );
  }
}
