import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const List<(IconData, String, String)> cards = <(IconData, String, String)>[
      (Icons.grid_view_rounded, 'Kategoriler', 'Tum icerikleri kesfet'),
      (Icons.search_rounded, 'Arama', 'ELXVRO icinde hizlica bul'),
      (Icons.bookmark_outline_rounded, 'Kaydedilenler', 'Favori iceriklerine don'),
      (Icons.auto_awesome_rounded, 'Yeni', 'Son eklenenleri incele'),
    ];

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 110),
      children: <Widget>[
        const Text(
          'Hos geldin',
          style: TextStyle(color: AppTheme.muted, fontSize: 14),
        ),
        const SizedBox(height: 4),
        const Text(
          'ELXVRO',
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, letterSpacing: 1.3),
        ),
        const SizedBox(height: 22),
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: <Color>[Color(0xFF2B1F64), Color(0xFF152A38)],
            ),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Icon(Icons.rocket_launch_rounded, size: 30),
              SizedBox(height: 20),
              Text('ELXVRO App v1.0', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              SizedBox(height: 7),
              Text(
                'Web v4.7.1 altyapisini mobil ve PC tarafina tasiyan yeni istemci.',
                style: TextStyle(color: Color(0xFFD4D6E3), height: 1.45),
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
            maxCrossAxisExtent: 240,
            mainAxisExtent: 150,
            crossAxisSpacing: 14,
            mainAxisSpacing: 14,
          ),
          itemCount: cards.length,
          itemBuilder: (BuildContext context, int index) {
            final (IconData icon, String title, String subtitle) = cards[index];
            return Card(
              child: InkWell(
                borderRadius: BorderRadius.circular(22),
                onTap: () {},
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Icon(icon, color: AppTheme.accent),
                      const Spacer(),
                      Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 4),
                      Text(subtitle, style: const TextStyle(color: AppTheme.muted, fontSize: 12.5)),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}
