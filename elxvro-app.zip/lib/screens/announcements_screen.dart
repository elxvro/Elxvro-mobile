import 'package:flutter/material.dart';

import '../models/announcement.dart';
import '../theme/app_theme.dart';
import '../widgets/elxvro_logo.dart';

class AnnouncementsScreen extends StatelessWidget {
  const AnnouncementsScreen({super.key});

  static const List<Announcement> _items = <Announcement>[
    Announcement(
      title: 'ELXVRO v1.6.0 Modern Release',
      body:
          'Android 7.0+ desteği, tüm uygulamada ekran görüntüsü koruması, daha modern duyuru deneyimi ve sadeleştirilmiş görsel kart yapısı eklendi.',
      date: '16 Eylül 2026',
    ),
    Announcement(
      title: 'ELXVRO v1.5.0 Play Release',
      body:
          'Favoriler, son görüntülenenler ve Koleksiyonum bölümü eklendi. Play Store yayın altyapısı güncellendi.',
      date: '16 Eylül 2026',
    ),
    Announcement(
      title: 'ELXVRO v1.4.2 Hesap Senkronizasyonu',
      body:
          'Web ve uygulama Google hesabı aynı ELXVRO kimliğinde birleşiyor. App API hesap senkronizasyonu aktif.',
      date: '16 Eylül 2026',
    ),
    Announcement(
      title: 'Yeni ELXVRO marka kimliği',
      body:
          'E/X monogram logo, uygulama ikonu ve splash ekranı ELXVRO’nun sabit görsel dili olarak uygulanmaya devam ediyor.',
      date: '14 Eylül 2026',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 118),
      children: <Widget>[
        const _AnnouncementHero(),
        const SizedBox(height: 16),
        const _AnnouncementHighlights(),
        const SizedBox(height: 22),
        const Row(
          children: <Widget>[
            Text('Duyuru merkezi', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            Spacer(),
            Text(
              'EN YENİLER',
              style: TextStyle(
                color: AppTheme.accent,
                fontSize: 9.5,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.15,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        for (int index = 0; index < _items.length; index++) ...<Widget>[
          _AnnouncementCard(item: _items[index], latest: index == 0, index: index),
          if (index != _items.length - 1) const SizedBox(height: 12),
        ],
      ],
    );
  }
}

class _AnnouncementHero extends StatelessWidget {
  const _AnnouncementHero();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        gradient: AppTheme.heroGradient,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: const Color(0x44394864)),
        boxShadow: const <BoxShadow>[
          BoxShadow(color: Color(0x36000000), blurRadius: 28, offset: Offset(0, 14)),
        ],
      ),
      child: Stack(
        children: <Widget>[
          Positioned(
            top: -30,
            right: -20,
            child: Container(
              width: 110,
              height: 110,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: <Color>[
                    AppTheme.primary.withValues(alpha: 0.30),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  ElxvroLogo(compact: true, showWordmark: false),
                  Spacer(),
                  _LiveBadge(),
                ],
              ),
              SizedBox(height: 20),
              Text(
                'Yeni sürümler,\nşık bir merkezde.',
                style: TextStyle(
                  fontSize: 29,
                  height: 1.08,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.5,
                ),
              ),
              SizedBox(height: 8),
              Text(
                'ELXVRO uygulamasındaki yenilikler, güvenlik güncellemeleri ve önemli bildirimler tek akışta.',
                style: TextStyle(color: AppTheme.muted, height: 1.45, fontSize: 12.5),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _AnnouncementHighlights extends StatelessWidget {
  const _AnnouncementHighlights();

  @override
  Widget build(BuildContext context) {
    return const Row(
      children: <Widget>[
        Expanded(
          child: _MiniInfoCard(
            icon: Icons.auto_awesome_rounded,
            title: 'Yeni arayüz',
            subtitle: 'Daha modern görünüm',
          ),
        ),
        SizedBox(width: 10),
        Expanded(
          child: _MiniInfoCard(
            icon: Icons.shield_moon_rounded,
            title: 'Güvenli',
            subtitle: 'Screenshot koruması',
          ),
        ),
        SizedBox(width: 10),
        Expanded(
          child: _MiniInfoCard(
            icon: Icons.android_rounded,
            title: 'Android 7+',
            subtitle: 'Daha net destek aralığı',
          ),
        ),
      ],
    );
  }
}

class _MiniInfoCard extends StatelessWidget {
  const _MiniInfoCard({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: AppTheme.panelGradient,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0x2E41506A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: const Color(0x1966E7FF),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0x2866E7FF)),
            ),
            child: Icon(icon, color: AppTheme.accent, size: 18),
          ),
          const SizedBox(height: 12),
          Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5)),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: const TextStyle(color: AppTheme.muted, fontSize: 11.2, height: 1.35),
          ),
        ],
      ),
    );
  }
}

class _LiveBadge extends StatelessWidget {
  const _LiveBadge();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: const Color(0x146FE6B5),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0x356FE6B5)),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(Icons.circle, size: 7, color: AppTheme.success),
          SizedBox(width: 6),
          Text(
            'CANLI',
            style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w900, letterSpacing: 1),
          ),
        ],
      ),
    );
  }
}

class _AnnouncementCard extends StatelessWidget {
  const _AnnouncementCard({required this.item, required this.latest, required this.index});

  final Announcement item;
  final bool latest;
  final int index;

  @override
  Widget build(BuildContext context) {
    final IconData icon = switch (index) {
      0 => Icons.rocket_launch_rounded,
      1 => Icons.new_releases_rounded,
      2 => Icons.sync_rounded,
      _ => Icons.palette_rounded,
    };

    return Container(
      decoration: BoxDecoration(
        gradient: latest ? AppTheme.panelGradient : null,
        color: latest ? null : AppTheme.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: latest ? const Color(0x446E6BFF) : AppTheme.border),
        boxShadow: latest
            ? const <BoxShadow>[
                BoxShadow(color: Color(0x28000000), blurRadius: 20, offset: Offset(0, 10)),
              ]
            : null,
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                gradient: AppTheme.brandGradient,
                borderRadius: BorderRadius.circular(15),
                boxShadow: const <BoxShadow>[
                  BoxShadow(color: Color(0x3B6E6BFF), blurRadius: 14, offset: Offset(0, 8)),
                ],
              ),
              child: Icon(icon, size: 22, color: Colors.white),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      if (latest)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                          decoration: BoxDecoration(
                            color: const Color(0x1866E7FF),
                            borderRadius: BorderRadius.circular(999),
                            border: Border.all(color: const Color(0x2F66E7FF)),
                          ),
                          child: const Text(
                            'YENİ',
                            style: TextStyle(
                              color: AppTheme.accent,
                              fontSize: 8.5,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.1,
                            ),
                          ),
                        ),
                      if (latest) const SizedBox(width: 8),
                      const Spacer(),
                      Text(
                        item.date,
                        style: const TextStyle(
                          fontSize: 9.5,
                          color: AppTheme.muted,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(item.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 7),
                  Text(
                    item.body,
                    style: const TextStyle(color: AppTheme.muted, height: 1.45, fontSize: 12),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
