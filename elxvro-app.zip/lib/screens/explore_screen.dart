import 'package:flutter/material.dart';

import '../models/wallpaper.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import '../widgets/fast_network_image.dart';
import '../widgets/wallpaper_card.dart';
import 'wallpaper_detail_screen.dart';

class ExploreScreen extends StatefulWidget {
  const ExploreScreen({super.key});

  @override
  State<ExploreScreen> createState() => _ExploreScreenState();
}

class _ExploreScreenState extends State<ExploreScreen> {
  final ApiService _api = const ApiService();
  bool _loading = true;
  String? _error;
  List<Wallpaper> _items = const <Wallpaper>[];
  int _manualShift = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load({bool forceRefresh = false}) async {
    if (_items.isEmpty || forceRefresh) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }
    try {
      final List<Wallpaper> source = await _api.fetchMobileWallpapers(
        forceRefresh: forceRefresh,
      );
      final List<Wallpaper> mixed = List<Wallpaper>.from(source);
      if (mixed.length > 1) {
        final int shift = (DateTime.now().day + _manualShift) % mixed.length;
        final List<Wallpaper> rotated = <Wallpaper>[
          ...mixed.skip(shift),
          ...mixed.take(shift),
        ];
        mixed
          ..clear()
          ..addAll(rotated);
      }
      if (!mounted) return;
      setState(() {
        _items = mixed;
        _error = null;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() => _error = error.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _shuffle() async {
    setState(() => _manualShift++);
    await _load(forceRefresh: false);
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () => _load(forceRefresh: true),
      child: CustomScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        slivers: <Widget>[
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
            sliver: SliverToBoxAdapter(
              child: _ExploreHeader(onShuffle: _items.isEmpty ? null : _shuffle),
            ),
          ),
          if (_loading && _items.isEmpty)
            const SliverFillRemaining(
              hasScrollBody: false,
              child: Center(child: CircularProgressIndicator()),
            )
          else if (_error != null && _items.isEmpty)
            SliverFillRemaining(
              hasScrollBody: false,
              child: _ExploreError(message: _error!, onRetry: () => _load(forceRefresh: true)),
            )
          else if (_items.isEmpty)
            const SliverFillRemaining(
              hasScrollBody: false,
              child: Center(
                child: Text(
                  'Keşfedilecek mobil görsel bulunamadı.',
                  style: TextStyle(color: AppTheme.muted),
                ),
              ),
            )
          else ...<Widget>[
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 22),
              sliver: SliverToBoxAdapter(
                child: _DailyPick(wallpaper: _items.first),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              sliver: SliverToBoxAdapter(
                child: Row(
                  children: <Widget>[
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Editoryal seçki',
                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                          ),
                          SizedBox(height: 3),
                          Text(
                            'Bugünün karışık ELXVRO koleksiyonu',
                            style: TextStyle(color: AppTheme.muted, fontSize: 11.5),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                      decoration: BoxDecoration(
                        color: AppTheme.surface,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: AppTheme.border),
                      ),
                      child: Text(
                        '${_items.length}',
                        style: const TextStyle(
                          color: AppTheme.accent,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 118),
              sliver: SliverLayoutBuilder(
                builder: (BuildContext context, constraints) {
                  final double width = constraints.crossAxisExtent;
                  final int columns = width >= 900
                      ? 5
                      : width >= 650
                          ? 4
                          : width >= 430
                              ? 3
                              : 2;
                  final double cellWidth = (width - ((columns - 1) * 10)) / columns;
                  final int cacheWidth = (cellWidth * MediaQuery.devicePixelRatioOf(context))
                      .round()
                      .clamp(240, 720)
                      .toInt();
                  final List<Wallpaper> gridItems = _items.skip(1).toList(growable: false);
                  return SliverGrid(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: columns,
                      mainAxisSpacing: 10,
                      crossAxisSpacing: 10,
                      childAspectRatio: 0.58,
                    ),
                    delegate: SliverChildBuilderDelegate(
                      (BuildContext context, int index) => WallpaperCard(
                        wallpaper: gridItems[index],
                        cacheWidth: cacheWidth,
                      ),
                      childCount: gridItems.length,
                    ),
                  );
                },
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _ExploreHeader extends StatelessWidget {
  const _ExploreHeader({required this.onShuffle});

  final Future<void> Function()? onShuffle;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppTheme.heroGradient,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: const Color(0x4436425A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  gradient: AppTheme.brandGradient,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(Icons.explore_rounded, color: Colors.white),
              ),
              const Spacer(),
              IconButton.filledTonal(
                onPressed: onShuffle,
                tooltip: 'Seçkiyi değiştir',
                icon: const Icon(Icons.shuffle_rounded),
              ),
            ],
          ),
          const SizedBox(height: 18),
          const Text(
            'Yeni bir ekran\nkeşfet.',
            style: TextStyle(
              fontSize: 29,
              height: 1.08,
              fontWeight: FontWeight.w900,
              letterSpacing: -0.5,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'ELXVRO koleksiyonundan her gün değişen farklı bir seçki.',
            style: TextStyle(color: AppTheme.muted, height: 1.42, fontSize: 12.5),
          ),
        ],
      ),
    );
  }
}

class _DailyPick extends StatelessWidget {
  const _DailyPick({required this.wallpaper});

  final Wallpaper wallpaper;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: const Color(0x3D667B9C)),
        boxShadow: const <BoxShadow>[
          BoxShadow(color: Color(0x55000000), blurRadius: 24, offset: Offset(0, 12)),
        ],
      ),
      child: Material(
        color: AppTheme.surfaceAlt,
        borderRadius: BorderRadius.circular(27),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () {
            Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => WallpaperDetailScreen(wallpaper: wallpaper),
              ),
            );
          },
          child: SizedBox(
            height: 288,
            child: Stack(
              fit: StackFit.expand,
              children: <Widget>[
                FastNetworkImage(
                  url: wallpaper.thumbnailUrl,
                  fit: BoxFit.cover,
                  diskCacheWidth: 1080,
                ),
                const DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      stops: <double>[0.08, 0.55, 1],
                      colors: <Color>[
                        Color(0x11000000),
                        Color(0x44000000),
                        Color(0xF8000000),
                      ],
                    ),
                  ),
                ),
                Positioned(
                  left: 16,
                  top: 16,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                    decoration: BoxDecoration(
                      color: const Color(0xD20B0F16),
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(color: const Color(0x3DFFFFFF)),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Icon(Icons.bolt_rounded, size: 15, color: AppTheme.accent),
                        SizedBox(width: 5),
                        Text(
                          'GÜNÜN SEÇİMİ',
                          style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w900),
                        ),
                      ],
                    ),
                  ),
                ),
                Positioned(
                  left: 18,
                  right: 18,
                  bottom: 18,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: <Widget>[
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            Text(
                              wallpaper.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                                letterSpacing: -0.35,
                              ),
                            ),
                            const SizedBox(height: 5),
                            Text(
                              wallpaper.category,
                              style: const TextStyle(
                                color: Color(0xFFC5CEDB),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        width: 46,
                        height: 46,
                        decoration: BoxDecoration(
                          gradient: AppTheme.brandGradient,
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: const Icon(Icons.arrow_forward_rounded, color: Colors.white),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ExploreError extends StatelessWidget {
  const _ExploreError({required this.message, required this.onRetry});

  final String message;
  final Future<void> Function() onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const Icon(Icons.cloud_off_rounded, size: 44, color: AppTheme.muted),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: () => onRetry(),
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('Tekrar Dene'),
            ),
          ],
        ),
      ),
    );
  }
}
