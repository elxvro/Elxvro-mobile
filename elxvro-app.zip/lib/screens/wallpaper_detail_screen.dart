import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';

import '../models/wallpaper.dart';
import '../services/local_library_service.dart';
import '../services/wallpaper_service.dart';
import '../theme/app_theme.dart';
import '../widgets/fast_network_image.dart';

class WallpaperDetailScreen extends StatefulWidget {
  const WallpaperDetailScreen({
    super.key,
    required this.wallpaper,
  });

  final Wallpaper wallpaper;

  @override
  State<WallpaperDetailScreen> createState() => _WallpaperDetailScreenState();
}

class _WallpaperDetailScreenState extends State<WallpaperDetailScreen> {
  final WallpaperService _wallpaperService = const WallpaperService();
  final LocalLibraryService _library = LocalLibraryService.instance;
  bool _settingWallpaper = false;
  bool _prepareFinished = false;
  String? _preparedPath;
  late final Future<String?> _prepareFuture;

  @override
  void initState() {
    super.initState();
    unawaited(_library.addRecent(widget.wallpaper));
    _prepareFuture = _prepareWallpaper();
    unawaited(_prepareFuture);
  }

  List<String> get _safeUrls {
    final List<String> values = <String>[];
    void add(String? value) {
      final String clean = value?.trim() ?? '';
      if (clean.isEmpty || values.contains(clean)) return;
      values.add(clean);
    }

    // App API Media Pack tam gorseli ilk tercih edilir. Adaylarin tamami
    // app-api/media altindaki ELX-M-*.webp adresleridir; thumbnail son fallback'tir.
    add(widget.wallpaper.imageUrl);
    for (final String url in widget.wallpaper.candidateUrls) {
      add(url);
    }
    add(widget.wallpaper.thumbnailUrl);
    return values;
  }

  Future<String?> _prepareWallpaper() async {
    try {
      for (final String url in _safeUrls) {
        try {
          // Media Pack dosyasi Flutter disk cache'e alinir; Android native katmani
          // internete cikmadan yalnizca bu yerel dosyayi hazirlar.
          final File rawFile = await DefaultCacheManager().getSingleFile(url);
          if (!await rawFile.exists() || await rawFile.length() <= 512) continue;

          final String? path = await _wallpaperService.prepareFromFile(rawFile.path);
          if (path == null || path.isEmpty) continue;
          final File prepared = File(path);
          if (!await prepared.exists() || await prepared.length() <= 1024) continue;

          if (mounted) {
            setState(() {
              _preparedPath = path;
              _prepareFinished = true;
            });
          }
          return path;
        } catch (_) {
          // Bir tam gorsel URL'si 403/404 verirse sonraki adaya gecilir.
        }
      }
      return null;
    } finally {
      if (mounted && !_prepareFinished) {
        setState(() => _prepareFinished = true);
      }
    }
  }

  Future<void> _chooseAndSetWallpaper() async {
    final WallpaperTarget? target = await showModalBottomSheet<WallpaperTarget>(
      context: context,
      backgroundColor: AppTheme.surface,
      showDragHandle: true,
      builder: (BuildContext sheetContext) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                const Padding(
                  padding: EdgeInsets.fromLTRB(8, 4, 8, 14),
                  child: Text(
                    'Nereye uygulansın?',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                  ),
                ),
                _TargetTile(
                  icon: Icons.home_rounded,
                  title: 'Ana ekran',
                  subtitle: 'Sadece telefonun ana ekranı',
                  onTap: () => Navigator.pop(sheetContext, WallpaperTarget.home),
                ),
                const SizedBox(height: 8),
                _TargetTile(
                  icon: Icons.lock_rounded,
                  title: 'Kilit ekranı',
                  subtitle: 'Sadece kilit ekranı',
                  onTap: () => Navigator.pop(sheetContext, WallpaperTarget.lock),
                ),
                const SizedBox(height: 8),
                _TargetTile(
                  icon: Icons.phone_android_rounded,
                  title: 'İkisi birden',
                  subtitle: 'Ana ekran ve kilit ekranı',
                  onTap: () => Navigator.pop(sheetContext, WallpaperTarget.both),
                ),
              ],
            ),
          ),
        );
      },
    );

    if (target == null || !mounted) return;
    setState(() => _settingWallpaper = true);

    try {
      final String? preparedPath = _preparedPath ?? await _prepareFuture;
      if (preparedPath == null ||
          preparedPath.isEmpty ||
          !await File(preparedPath).exists()) {
        throw Exception(
          'Tam görsel hazırlanamadı. İnternet bağlantısını kontrol edip tekrar deneyin.',
        );
      }

      await _wallpaperService.setPrepared(
        preparedPath: preparedPath,
        target: target,
      );

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Duvar kağıdı başarıyla uygulandı.'),
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (error) {
      if (!mounted) return;
      final String message = error.toString().replaceFirst('Exception: ', '');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          behavior: SnackBarBehavior.floating,
        ),
      );
    } finally {
      if (mounted) setState(() => _settingWallpaper = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final String? localPath = _preparedPath;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: const Color(0x66000000),
        leading: IconButton.filledTonal(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_rounded),
        ),
        title: Text(
          widget.wallpaper.category,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        actions: <Widget>[
          ValueListenableBuilder<List<Wallpaper>>(
            valueListenable: _library.favorites,
            builder: (BuildContext context, List<Wallpaper> _, Widget? child) {
              final bool favorite = _library.isFavorite(widget.wallpaper);
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: IconButton.filledTonal(
                  tooltip: favorite ? 'Favorilerden çıkar' : 'Favorilere ekle',
                  onPressed: () async {
                    final bool added = await _library.toggleFavorite(widget.wallpaper);
                    if (!mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(added ? 'Favorilere eklendi.' : 'Favorilerden çıkarıldı.'),
                        duration: const Duration(milliseconds: 1100),
                      ),
                    );
                  },
                  icon: Icon(
                    favorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                    color: favorite ? AppTheme.accent : null,
                  ),
                ),
              );
            },
          ),
        ],
      ),
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          const ColoredBox(color: Colors.black),
          InteractiveViewer(
            minScale: 1,
            maxScale: 4,
            child: localPath != null
                ? Image.file(
                    File(localPath),
                    fit: BoxFit.cover,
                    gaplessPlayback: true,
                    filterQuality: FilterQuality.medium,
                  )
                : FastNetworkImage(
                    url: widget.wallpaper.thumbnailUrl,
                    fit: BoxFit.cover,
                    diskCacheWidth: 1080,
                  ),
          ),
          if (localPath == null)
            Positioned(
              left: 0,
              right: 0,
              bottom: 104,
              child: Center(
                child: DecoratedBox(
                  decoration: const BoxDecoration(
                    color: Color(0x99000000),
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                    child: Text(
                      _prepareFinished
                          ? 'Tam görsel hazırlanamadı'
                          : 'Duvar kağıdı hazırlanıyor…',
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                    ),
                  ),
                ),
              ),
            ),
          Positioned(
            left: 16,
            right: 16,
            bottom: 24,
            child: SafeArea(
              top: false,
              child: FilledButton.icon(
                onPressed: _settingWallpaper ? null : _chooseAndSetWallpaper,
                icon: _settingWallpaper
                    ? const SizedBox.square(
                        dimension: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.wallpaper_rounded),
                label: Text(
                  _settingWallpaper ? 'Uygulanıyor...' : 'Duvar Kağıdı Yap',
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TargetTile extends StatelessWidget {
  const _TargetTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppTheme.surfaceAlt,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: <Widget>[
              Icon(icon),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 2),
                    Text(subtitle, style: const TextStyle(color: AppTheme.muted)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded),
            ],
          ),
        ),
      ),
    );
  }
}
