import 'package:flutter/material.dart';

import '../models/category.dart';
import '../models/wallpaper.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import '../widgets/fast_network_image.dart';
import '../widgets/wallpaper_card.dart';

class CategoryWallpapersScreen extends StatefulWidget {
  const CategoryWallpapersScreen({super.key, required this.category});

  final WallpaperCategory category;

  @override
  State<CategoryWallpapersScreen> createState() => _CategoryWallpapersScreenState();
}

class _CategoryWallpapersScreenState extends State<CategoryWallpapersScreen> {
  final ApiService _api = const ApiService();
  bool _loading = true;
  String? _error;
  List<Wallpaper> _items = const <Wallpaper>[];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load({bool forceRefresh = false}) async {
    if (_items.isEmpty || forceRefresh) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }

    try {
      List<Wallpaper> items = const <Wallpaper>[];
      try {
        items = await _api.fetchMobileWallpapers(
          category: widget.category.slug,
          forceRefresh: forceRefresh,
        );
      } catch (_) {
        // Hosting kategori sorgusunu reddederse genel mobil cache'e düş.
      }

      if (items.isEmpty) {
        final List<Wallpaper> all = await _api.fetchMobileWallpapers(forceRefresh: false);
        final Set<String> wanted = <String>{
          _normalize(widget.category.name),
          _normalize(widget.category.slug),
          _normalize(widget.category.id),
        }..removeWhere((String value) => value.isEmpty);

        items = all.where((Wallpaper item) {
          final Set<String> values = <String>{
            _normalize(item.category),
            ...item.categoryKeys.map(_normalize),
          }..removeWhere((String value) => value.isEmpty);

          for (final String value in values) {
            if (wanted.contains(value)) return true;
            if (wanted.any(
              (String target) => target.length >= 3 &&
                  value.length >= 3 &&
                  (value.contains(target) || target.contains(value)),
            )) {
              return true;
            }
          }
          return false;
        }).toList(growable: false);
      }

      if (!mounted) return;
      setState(() {
        _items = items;
        _error = null;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() => _error = error.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _normalize(String value) {
    String text = value.toLowerCase().trim();
    const Map<String, String> replacements = <String, String>{
      'ç': 'c',
      'ğ': 'g',
      'ı': 'i',
      'ö': 'o',
      'ş': 's',
      'ü': 'u',
    };
    replacements.forEach((String from, String to) => text = text.replaceAll(from, to));
    return text.replaceAll(RegExp(r'[^a-z0-9]+'), '-').replaceAll(RegExp(r'^-+|-+$'), '');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.category.name)),
      body: RefreshIndicator(
        onRefresh: () => _load(forceRefresh: true),
        child: _buildBody(),
      ),
    );
  }

  Widget _buildBody() {
    if (_loading && _items.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_error != null && _items.isEmpty) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(28),
        children: <Widget>[
          const SizedBox(height: 100),
          const Icon(Icons.cloud_off_rounded, size: 44, color: AppTheme.muted),
          const SizedBox(height: 14),
          Text(_error!, textAlign: TextAlign.center),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: () => _load(forceRefresh: true),
            icon: const Icon(Icons.refresh_rounded),
            label: const Text('Tekrar Dene'),
          ),
        ],
      );
    }

    if (_items.isEmpty) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(28),
        children: const <Widget>[
          SizedBox(height: 120),
          Icon(Icons.image_not_supported_outlined, size: 44, color: AppTheme.muted),
          SizedBox(height: 14),
          Text(
            'Bu kategoride mobil görsel bulunamadı.',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppTheme.muted),
          ),
        ],
      );
    }

    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        final int columns = constraints.maxWidth >= 900
            ? 5
            : constraints.maxWidth >= 650
                ? 4
                : constraints.maxWidth >= 430
                    ? 3
                    : 2;
        final double cellWidth =
            (constraints.maxWidth - 24 - ((columns - 1) * 10)) / columns;
        final int cacheWidth = (cellWidth * MediaQuery.devicePixelRatioOf(context))
            .round()
            .clamp(240, 720)
            .toInt();

        return CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: <Widget>[
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 16),
              sliver: SliverToBoxAdapter(
                child: _CategoryHero(
                  category: widget.category,
                  fallbackCover: _items.first.thumbnailUrl,
                  count: _items.length,
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 28),
              sliver: SliverGrid(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: columns,
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  childAspectRatio: 0.58,
                ),
                delegate: SliverChildBuilderDelegate(
                  (BuildContext context, int index) => RepaintBoundary(
                    child: WallpaperCard(
                      wallpaper: _items[index],
                      cacheWidth: cacheWidth,
                      showCategory: false,
                    ),
                  ),
                  childCount: _items.length,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _CategoryHero extends StatelessWidget {
  const _CategoryHero({
    required this.category,
    required this.fallbackCover,
    required this.count,
  });

  final WallpaperCategory category;
  final String fallbackCover;
  final int count;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 168,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Stack(
          fit: StackFit.expand,
          children: <Widget>[
            FastNetworkImage(
              url: category.coverUrl ?? fallbackCover,
              fit: BoxFit.cover,
              diskCacheWidth: 900,
            ),
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: <Color>[Color(0x26000000), Color(0xEE000000)],
                ),
              ),
            ),
            Positioned(
              left: 18,
              right: 18,
              bottom: 17,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        const Text(
                          'MOBİL KATEGORİ',
                          style: TextStyle(color: AppTheme.accent, fontSize: 9.5, fontWeight: FontWeight.w900, letterSpacing: 1.4),
                        ),
                        const SizedBox(height: 5),
                        Text(category.name, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                    decoration: BoxDecoration(
                      color: const Color(0xB30D1016),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text('$count görsel', style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
