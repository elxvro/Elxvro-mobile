class Announcement {
  const Announcement({
    required this.title,
    required this.body,
    required this.date,
  });

  final String title;
  final String body;
  final String date;
}
