class ElxvroAccount {
  const ElxvroAccount({
    required this.id,
    required this.email,
    required this.name,
    required this.avatarUrl,
    required this.registrationSource,
    required this.usedWeb,
    required this.usedApp,
    required this.scope,
    required this.status,
  });

  final String id;
  final String email;
  final String name;
  final String avatarUrl;
  final String registrationSource;
  final bool usedWeb;
  final bool usedApp;
  final String scope;
  final String status;

  String get scopeLabel {
    if (usedWeb && usedApp) return 'Web + Uygulama';
    if (usedApp) return 'Uygulama';
    return 'Web';
  }

  factory ElxvroAccount.fromJson(Map<String, dynamic> json) {
    return ElxvroAccount(
      id: (json['id'] ?? '').toString(),
      email: (json['email'] ?? '').toString(),
      name: (json['name'] ?? '').toString(),
      avatarUrl: (json['avatar_url'] ?? '').toString(),
      registrationSource: (json['registration_source'] ?? '').toString(),
      usedWeb: json['used_web'] == true || json['used_web'] == 1,
      usedApp: json['used_app'] == true || json['used_app'] == 1,
      scope: (json['scope'] ?? '').toString(),
      status: (json['status'] ?? 'active').toString(),
    );
  }
}
