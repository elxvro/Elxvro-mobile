class Wallpaper {
  const Wallpaper({
    required this.id,
    required this.title,
    required this.imageUrl,
    required this.thumbnailUrl,
    required this.category,
    this.categoryKeys = const <String>[],
    this.candidateUrls = const <String>[],
  });

  final String id;
  final String title;
  final String imageUrl;
  final String thumbnailUrl;
  final String category;

  /// API kategori bilgisini ad/slug/id veya coklu kategori seklinde
  /// dondurebilir. Yerel fallback filtrelemede tum anahtarlar kullanilir.
  final List<String> categoryKeys;

  /// Duvar kagidi hazirlarken denenebilecek tam gorsel URL'leri.
  /// Liste endpoint'i ile tekil detay endpoint'i farkli alanlar dondurebildigi
  /// icin tek bir URL'ye bagimli kalmayiz.
  final List<String> candidateUrls;

  List<String> get wallpaperUrls {
    final List<String> values = <String>[];
    void add(String value) {
      final String clean = value.trim();
      if (clean.isNotEmpty && !values.contains(clean)) values.add(clean);
    }

    for (final String url in candidateUrls) {
      add(url);
    }
    add(imageUrl);
    add(thumbnailUrl);
    return List<String>.unmodifiable(values);
  }


  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      'id': id,
      'title': title,
      'imageUrl': imageUrl,
      'thumbnailUrl': thumbnailUrl,
      'category': category,
      'categoryKeys': categoryKeys,
      'candidateUrls': candidateUrls,
    };
  }

  static Wallpaper? fromJson(Map<String, dynamic> json) {
    final String imageUrl = (json['imageUrl'] ?? '').toString().trim();
    final String thumbnailUrl = (json['thumbnailUrl'] ?? '').toString().trim();
    if (imageUrl.isEmpty && thumbnailUrl.isEmpty) return null;

    List<String> strings(dynamic raw) {
      if (raw is! List) return const <String>[];
      return raw
          .map((dynamic value) => value.toString().trim())
          .where((String value) => value.isNotEmpty)
          .toList(growable: false);
    }

    return Wallpaper(
      id: (json['id'] ?? '').toString(),
      title: (json['title'] ?? 'ELXVRO Mobil').toString(),
      imageUrl: imageUrl.isNotEmpty ? imageUrl : thumbnailUrl,
      thumbnailUrl: thumbnailUrl.isNotEmpty ? thumbnailUrl : imageUrl,
      category: (json['category'] ?? 'Mobil').toString(),
      categoryKeys: strings(json['categoryKeys']),
      candidateUrls: strings(json['candidateUrls']),
    );
  }

  Wallpaper copyWith({
    String? id,
    String? title,
    String? imageUrl,
    String? thumbnailUrl,
    String? category,
    List<String>? categoryKeys,
    List<String>? candidateUrls,
  }) {
    return Wallpaper(
      id: id ?? this.id,
      title: title ?? this.title,
      imageUrl: imageUrl ?? this.imageUrl,
      thumbnailUrl: thumbnailUrl ?? this.thumbnailUrl,
      category: category ?? this.category,
      categoryKeys: categoryKeys ?? this.categoryKeys,
      candidateUrls: candidateUrls ?? this.candidateUrls,
    );
  }
}
