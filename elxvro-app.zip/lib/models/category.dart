class WallpaperCategory {
  const WallpaperCategory({
    required this.id,
    required this.name,
    required this.slug,
    this.icon,
    this.coverUrl,
    this.mobileCount,
  });

  final String id;
  final String name;
  final String slug;
  final String? icon;
  final String? coverUrl;
  final int? mobileCount;
}
