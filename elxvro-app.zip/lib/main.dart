import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'config/app_config.dart';
import 'screens/shell_screen.dart';
import 'services/google_auth_service.dart';
import 'services/local_library_service.dart';
import 'theme/app_theme.dart';
import 'widgets/elxvro_logo.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Colors.transparent,
      systemNavigationBarIconBrightness: Brightness.light,
      systemNavigationBarDividerColor: Colors.transparent,
    ),
  );
  await Future.wait(<Future<void>>[
    GoogleAuthService.instance.initialize(),
    LocalLibraryService.instance.initialize(),
  ]);
  runApp(const ElxvroApp());
}

class ElxvroApp extends StatelessWidget {
  const ElxvroApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConfig.appName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark(),
      home: const _LaunchGate(),
    );
  }
}

class _LaunchGate extends StatefulWidget {
  const _LaunchGate();

  @override
  State<_LaunchGate> createState() => _LaunchGateState();
}

class _LaunchGateState extends State<_LaunchGate> {
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 900), () {
      if (mounted) setState(() => _ready = true);
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 360),
      switchInCurve: Curves.easeOut,
      switchOutCurve: Curves.easeIn,
      child: _ready
          ? const ShellScreen(key: ValueKey<String>('shell'))
          : const _BrandSplash(key: ValueKey<String>('splash')),
    );
  }
}

class _BrandSplash extends StatelessWidget {
  const _BrandSplash({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: DecoratedBox(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(-0.15, -0.35),
            radius: 1.2,
            colors: <Color>[
              Color(0x2A293C80),
              Color(0x140A3040),
              AppTheme.background,
            ],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                const ElxvroLogo(),
                const SizedBox(height: 24),
                Container(
                  width: 104,
                  height: 3,
                  decoration: BoxDecoration(
                    gradient: AppTheme.brandGradient,
                    borderRadius: BorderRadius.circular(99),
                    boxShadow: const <BoxShadow>[
                      BoxShadow(color: Color(0x5566E7FF), blurRadius: 16),
                    ],
                  ),
                ),
                const SizedBox(height: 17),
                const Text(
                  'PREMIUM MOBILE WALLPAPERS',
                  style: TextStyle(
                    color: AppTheme.muted,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.55,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
