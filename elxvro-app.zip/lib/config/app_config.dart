class AppConfig {
  const AppConfig._();

  static const String appName = 'ELXVRO';
  static const String version = '1.0.1';

  // Burayi web sunucundaki API adresinle degistir.
  // Ornek: https://senin-domainin.com/api/v1
  static const String apiBaseUrl = 'https://example.com/api/v1';

  static bool get isApiConfigured => !apiBaseUrl.contains('example.com');
}
