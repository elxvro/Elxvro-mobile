import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class ElxvroLogo extends StatelessWidget {
  const ElxvroLogo({super.key, this.compact = false, this.showWordmark = true});

  final bool compact;
  final bool showWordmark;

  @override
  Widget build(BuildContext context) {
    final double size = compact ? 34 : 54;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(compact ? 11 : 17),
            boxShadow: const <BoxShadow>[
              BoxShadow(
                color: Color(0x336E6BFF),
                blurRadius: 24,
                offset: Offset(0, 10),
              ),
            ],
          ),
          clipBehavior: Clip.antiAlias,
          child: Image.asset(
            'assets/branding/elxvro_icon.png',
            fit: BoxFit.cover,
          ),
        ),
        if (showWordmark) ...<Widget>[
          SizedBox(width: compact ? 10 : 14),
          Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                'ELXVRO',
                style: TextStyle(
                  letterSpacing: compact ? 2.4 : 3.2,
                  fontSize: compact ? 18 : 25,
                  fontWeight: FontWeight.w800,
                  color: AppTheme.text,
                ),
              ),
              if (!compact)
                const Text(
                  'PREMIUM WALLPAPERS',
                  style: TextStyle(
                    color: AppTheme.accent,
                    fontSize: 9,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.7,
                  ),
                ),
            ],
          ),
        ],
      ],
    );
  }
}
