import 'package:flutter/material.dart';

import '../models/wallpaper.dart';
import '../screens/wallpaper_detail_screen.dart';
import '../theme/app_theme.dart';
import 'fast_network_image.dart';

class WallpaperCard extends StatelessWidget {
  const WallpaperCard({
    super.key,
    required this.wallpaper,
    required this.cacheWidth,
    this.showCategory = true,
    this.borderRadius = 20,
  });

  final Wallpaper wallpaper;
  final int cacheWidth;
  final bool showCategory;
  final double borderRadius;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(borderRadius + 1),
        border: Border.all(color: const Color(0x2C48556C)),
        boxShadow: const <BoxShadow>[
          BoxShadow(color: Color(0x3A000000), blurRadius: 16, offset: Offset(0, 8)),
        ],
      ),
      child: Material(
        color: AppTheme.surfaceAlt,
        borderRadius: BorderRadius.circular(borderRadius),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () {
            Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => WallpaperDetailScreen(wallpaper: wallpaper),
              ),
            );
          },
          child: Stack(
            fit: StackFit.expand,
            children: <Widget>[
              FastNetworkImage(
                url: wallpaper.thumbnailUrl,
                fit: BoxFit.cover,
                memCacheWidth: cacheWidth,
                diskCacheWidth: cacheWidth.clamp(360, 1080).toInt(),
              ),
              const Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      stops: <double>[0.42, 0.72, 1],
                      colors: <Color>[
                        Colors.transparent,
                        Color(0x42000000),
                        Color(0xF4000000),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                top: 10,
                left: 10,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                  decoration: BoxDecoration(
                    color: const Color(0xC70B0F16),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: const Color(0x2EFFFFFF)),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Icon(Icons.phone_android_rounded, size: 10, color: AppTheme.accent),
                      SizedBox(width: 4),
                      Text(
                        'MOBİL',
                        style: TextStyle(
                          fontSize: 8.5,
                          letterSpacing: 0.65,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 11,
                right: 11,
                bottom: 11,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Text(
                      wallpaper.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.1,
                      ),
                    ),
                    if (showCategory && wallpaper.category.trim().isNotEmpty) ...<Widget>[
                      const SizedBox(height: 4),
                      Row(
                        children: <Widget>[
                          const Icon(
                            Icons.collections_bookmark_outlined,
                            size: 11,
                            color: AppTheme.accent,
                          ),
                          const SizedBox(width: 4),
                          Expanded(
                            child: Text(
                              wallpaper.category,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 9.5,
                                color: Color(0xFFB6C0CF),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
