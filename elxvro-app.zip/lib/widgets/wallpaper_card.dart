import 'dart:async';

import 'package:flutter/material.dart';

import '../models/wallpaper.dart';
import '../screens/wallpaper_detail_screen.dart';
import '../services/local_library_service.dart';
import '../theme/app_theme.dart';
import 'fast_network_image.dart';

class WallpaperCard extends StatelessWidget {
  const WallpaperCard({
    super.key,
    required this.wallpaper,
    required this.cacheWidth,
    this.showCategory = true,
    this.borderRadius = 20,
  });

  final Wallpaper wallpaper;
  final int cacheWidth;
  final bool showCategory;
  final double borderRadius;

  @override
  Widget build(BuildContext context) {
    final LocalLibraryService library = LocalLibraryService.instance;

    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(borderRadius + 1),
        border: Border.all(color: const Color(0x2D4C5B75)),
        boxShadow: const <BoxShadow>[
          BoxShadow(color: Color(0x44000000), blurRadius: 18, offset: Offset(0, 10)),
        ],
      ),
      child: Material(
        color: AppTheme.surfaceAlt,
        borderRadius: BorderRadius.circular(borderRadius),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () {
            unawaited(library.addRecent(wallpaper));
            Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => WallpaperDetailScreen(wallpaper: wallpaper),
              ),
            );
          },
          child: Stack(
            fit: StackFit.expand,
            children: <Widget>[
              FastNetworkImage(
                url: wallpaper.thumbnailUrl,
                fit: BoxFit.cover,
                memCacheWidth: cacheWidth,
                diskCacheWidth: cacheWidth.clamp(360, 1080).toInt(),
              ),
              const Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      stops: <double>[0.42, 0.76, 1],
                      colors: <Color>[
                        Colors.transparent,
                        Color(0x1E000000),
                        Color(0xF1000000),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: ValueListenableBuilder<List<Wallpaper>>(
                  valueListenable: library.favorites,
                  builder: (BuildContext context, List<Wallpaper> _, Widget? child) {
                    final bool favorite = library.isFavorite(wallpaper);
                    return Material(
                      color: const Color(0xBF091018),
                      shape: const CircleBorder(),
                      clipBehavior: Clip.antiAlias,
                      child: InkWell(
                        onTap: () async {
                          final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
                          final bool added = await library.toggleFavorite(wallpaper);
                          messenger.showSnackBar(
                            SnackBar(
                              content: Text(
                                added ? 'Favorilere eklendi.' : 'Favorilerden çıkarıldı.',
                              ),
                              duration: const Duration(milliseconds: 1100),
                            ),
                          );
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(8),
                          child: Icon(
                            favorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                            size: 17,
                            color: favorite ? AppTheme.accent : Colors.white,
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
              Positioned(
                left: 11,
                right: 11,
                bottom: 11,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Text(
                      wallpaper.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.1,
                      ),
                    ),
                    if (showCategory && wallpaper.category.trim().isNotEmpty) ...<Widget>[
                      const SizedBox(height: 4),
                      Row(
                        children: <Widget>[
                          const Icon(
                            Icons.collections_bookmark_outlined,
                            size: 11,
                            color: AppTheme.accent,
                          ),
                          const SizedBox(width: 4),
                          Expanded(
                            child: Text(
                              wallpaper.category,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 9.5,
                                color: Color(0xFFB6C0CF),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
