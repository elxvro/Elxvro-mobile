import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class FastNetworkImage extends StatelessWidget {
  const FastNetworkImage({
    super.key,
    required this.url,
    this.fit = BoxFit.cover,
    this.memCacheWidth,
    this.diskCacheWidth,
    this.errorIcon = Icons.broken_image_outlined,
  });

  final String url;
  final BoxFit fit;
  final int? memCacheWidth;
  final int? diskCacheWidth;
  final IconData errorIcon;

  @override
  Widget build(BuildContext context) {
    return CachedNetworkImage(
      imageUrl: url,
      fit: fit,
      memCacheWidth: memCacheWidth,
      maxWidthDiskCache: diskCacheWidth,
      fadeInDuration: Duration.zero,
      fadeOutDuration: Duration.zero,
      placeholder: (_, __) => const ColoredBox(color: AppTheme.surfaceAlt),
      errorWidget: (_, __, ___) => Center(
        child: Icon(errorIcon, color: AppTheme.muted),
      ),
    );
  }
}
