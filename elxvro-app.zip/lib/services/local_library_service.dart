import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/wallpaper.dart';

class LocalLibraryService {
  LocalLibraryService._();

  static final LocalLibraryService instance = LocalLibraryService._();

  static const String _favoritesKey = 'elxvro_favorites_v1';
  static const String _recentKey = 'elxvro_recent_v1';
  static const int _recentLimit = 40;

  final ValueNotifier<List<Wallpaper>> favorites =
      ValueNotifier<List<Wallpaper>>(const <Wallpaper>[]);
  final ValueNotifier<List<Wallpaper>> recent =
      ValueNotifier<List<Wallpaper>>(const <Wallpaper>[]);

  SharedPreferences? _prefs;
  bool _initialized = false;

  Future<void> initialize() async {
    if (_initialized) return;
    _prefs ??= await SharedPreferences.getInstance();
    favorites.value = _decodeList(_prefs?.getString(_favoritesKey));
    recent.value = _decodeList(_prefs?.getString(_recentKey));
    _initialized = true;
  }

  bool isFavorite(Wallpaper wallpaper) {
    final String identity = _identity(wallpaper);
    return favorites.value.any((Wallpaper item) => _identity(item) == identity);
  }

  Future<bool> toggleFavorite(Wallpaper wallpaper) async {
    await initialize();
    final String identity = _identity(wallpaper);
    final List<Wallpaper> next = List<Wallpaper>.from(favorites.value);
    final int existing = next.indexWhere((Wallpaper item) => _identity(item) == identity);
    final bool added;
    if (existing >= 0) {
      next.removeAt(existing);
      added = false;
    } else {
      next.insert(0, wallpaper);
      added = true;
    }
    favorites.value = List<Wallpaper>.unmodifiable(next);
    await _persist(_favoritesKey, favorites.value);
    return added;
  }

  Future<void> addRecent(Wallpaper wallpaper) async {
    await initialize();
    final String identity = _identity(wallpaper);
    final List<Wallpaper> next = List<Wallpaper>.from(recent.value)
      ..removeWhere((Wallpaper item) => _identity(item) == identity)
      ..insert(0, wallpaper);
    if (next.length > _recentLimit) {
      next.removeRange(_recentLimit, next.length);
    }
    recent.value = List<Wallpaper>.unmodifiable(next);
    await _persist(_recentKey, recent.value);
  }

  Future<void> clearRecent() async {
    await initialize();
    recent.value = const <Wallpaper>[];
    await _prefs?.remove(_recentKey);
  }

  Future<void> clearFavorites() async {
    await initialize();
    favorites.value = const <Wallpaper>[];
    await _prefs?.remove(_favoritesKey);
  }

  String _identity(Wallpaper wallpaper) {
    final String id = wallpaper.id.trim();
    if (id.isNotEmpty) return 'id:$id';
    return 'url:${wallpaper.imageUrl.trim()}';
  }

  Future<void> _persist(String key, List<Wallpaper> values) async {
    final String encoded = jsonEncode(
      values.map((Wallpaper item) => item.toJson()).toList(growable: false),
    );
    await _prefs?.setString(key, encoded);
  }

  List<Wallpaper> _decodeList(String? raw) {
    if (raw == null || raw.trim().isEmpty) return const <Wallpaper>[];
    try {
      final dynamic decoded = jsonDecode(raw);
      if (decoded is! List) return const <Wallpaper>[];
      final List<Wallpaper> values = <Wallpaper>[];
      for (final dynamic item in decoded) {
        if (item is! Map) continue;
        final Map<String, dynamic> map = item.map(
          (dynamic key, dynamic value) => MapEntry(key.toString(), value),
        );
        final Wallpaper? wallpaper = Wallpaper.fromJson(map);
        if (wallpaper != null) values.add(wallpaper);
      }
      return List<Wallpaper>.unmodifiable(values);
    } catch (_) {
      return const <Wallpaper>[];
    }
  }
}
