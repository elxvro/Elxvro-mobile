import 'dart:convert';

import 'package:http/http.dart' as http;

import '../config/app_config.dart';

class ApiService {
  const ApiService();

  Future<Map<String, dynamic>> login({
    required String email,
    required String password,
  }) async {
    if (!AppConfig.isApiConfigured) {
      await Future<void>.delayed(const Duration(milliseconds: 650));
      if (email.trim().isEmpty || password.isEmpty) {
        throw Exception('E-posta ve sifre gerekli.');
      }
      return <String, dynamic>{
        'success': true,
        'user': <String, dynamic>{'name': 'ELXVRO User', 'email': email.trim()},
      };
    }

    final Uri uri = Uri.parse('${AppConfig.apiBaseUrl}/auth/login');
    final http.Response response = await http
        .post(
          uri,
          headers: const <String, String>{
            'Content-Type': 'application/json',
            'Accept': 'application/json',
          },
          body: jsonEncode(<String, String>{
            'email': email.trim(),
            'password': password,
          }),
        )
        .timeout(const Duration(seconds: 15));

    final dynamic decoded = jsonDecode(response.body);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      final String message = decoded is Map<String, dynamic>
          ? (decoded['message']?.toString() ?? 'Giris basarisiz.')
          : 'Giris basarisiz.';
      throw Exception(message);
    }

    if (decoded is! Map<String, dynamic>) {
      throw Exception('API cevabi gecersiz.');
    }
    return decoded;
  }
}
