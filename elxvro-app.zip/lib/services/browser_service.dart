import 'dart:io';

import 'package:flutter/services.dart';

class BrowserService {
  const BrowserService();

  static const MethodChannel _channel = MethodChannel('com.elxvro/browser');

  Future<void> open(String url) async {
    if (!Platform.isAndroid) {
      throw Exception('Bu bağlantı şu anda Android uygulamasında destekleniyor.');
    }

    try {
      final bool? opened = await _channel.invokeMethod<bool>(
        'openUrl',
        <String, String>{'url': url},
      );
      if (opened != true) {
        throw Exception('Bağlantı açılamadı.');
      }
    } on PlatformException catch (error) {
      final String message = error.message?.trim().isNotEmpty == true
          ? error.message!.trim()
          : 'Bağlantı açılamadı.';
      throw Exception(message);
    } on MissingPluginException {
      throw Exception('ELXVRO tarayıcı köprüsü APK içine eklenmemiş.');
    }
  }
}
