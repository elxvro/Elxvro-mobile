import 'dart:io';

import 'package:flutter/services.dart';

enum WallpaperTarget { home, lock, both }

class WallpaperService {
  const WallpaperService();

  static const MethodChannel _channel = MethodChannel('com.elxvro/wallpaper');

  Future<String?> prepareFromFile(String filePath) async {
    if (!Platform.isAndroid) return null;
    try {
      return await _channel.invokeMethod<String>(
        'prepareWallpaperFile',
        <String, String>{'path': filePath},
      );
    } catch (_) {
      return null;
    }
  }

  Future<void> setPrepared({
    required String preparedPath,
    required WallpaperTarget target,
  }) async {
    if (!Platform.isAndroid) {
      throw Exception('Duvar kağıdı ayarlama şu anda yalnızca Android APK’da destekleniyor.');
    }

    try {
      await _channel.invokeMethod<bool>(
        'setWallpaperPrepared',
        <String, String>{'path': preparedPath, 'target': target.name},
      );
    } on PlatformException catch (error) {
      final String message = error.message?.trim().isNotEmpty == true
          ? error.message!.trim()
          : 'Duvar kağıdı ayarlanamadı.';
      throw Exception(message);
    } on MissingPluginException {
      throw Exception('Android duvar kağıdı modülü APK içine eklenmemiş.');
    }
  }
}
