import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../config/app_config.dart';
import '../models/elxvro_account.dart';
import '../services/browser_service.dart';
import '../services/google_auth_service.dart';
import '../theme/app_theme.dart';
import '../widgets/elxvro_logo.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  static const BrowserService _browser = BrowserService();
  final GoogleAuthService _auth = GoogleAuthService.instance;
  bool _acceptedTerms = false;

  Future<void> _open(String url) async {
    try {
      await _browser.open(url);
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString().replaceFirst('Exception: ', ''))),
      );
    }
  }

  Future<void> _signIn() async {
    try {
      await _auth.signIn();
    } catch (_) {
      if (!mounted) return;
      final String message = _auth.lastError.value ?? 'Google ile giriş yapılamadı.';
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
    }
  }

  Future<void> _signOut() async {
    try {
      await _auth.signOut();
    } catch (_) {
      if (!mounted) return;
      final String message = _auth.lastError.value ?? 'Çıkış yapılamadı.';
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<GoogleSignInAccount?>(
      valueListenable: _auth.account,
      builder: (BuildContext context, GoogleSignInAccount? user, Widget? child) {
        return ValueListenableBuilder<ElxvroAccount?>(
          valueListenable: _auth.elxvroAccount,
          builder: (BuildContext context, ElxvroAccount? linkedAccount, Widget? child) {
            return ValueListenableBuilder<bool>(
              valueListenable: _auth.busy,
              builder: (BuildContext context, bool busy, Widget? child) {
                return ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 118),
              children: <Widget>[
                _ProfileHero(user: user),
                const SizedBox(height: 16),
                if (user == null)
                  _SignInCard(
                    busy: busy,
                    acceptedTerms: _acceptedTerms,
                    onAcceptedChanged: (bool value) => setState(() => _acceptedTerms = value),
                    onSignIn: _signIn,
                  )
                else
                  _ConnectedAccountCard(
                    user: user,
                    accountInfo: linkedAccount,
                    busy: busy,
                    onSignOut: _signOut,
                  ),
                const SizedBox(height: 16),
                const _AppStatusCard(),
                const SizedBox(height: 16),
                _SettingsCard(onOpen: _open),
              ],
            );
              },
            );
          },
        );
      },
    );
  }
}

class _ProfileHero extends StatelessWidget {
  const _ProfileHero({required this.user});

  final GoogleSignInAccount? user;

  @override
  Widget build(BuildContext context) {
    final String name = user?.displayName?.trim().isNotEmpty == true
        ? user!.displayName!.trim()
        : 'ELXVRO Profil';
    final String subtitle = user?.email ?? 'Google hesabınla kişisel ELXVRO deneyimini tamamla.';

    return Container(
      padding: const EdgeInsets.all(21),
      decoration: BoxDecoration(
        gradient: AppTheme.heroGradient,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: const Color(0x4436425A)),
        boxShadow: const <BoxShadow>[
          BoxShadow(color: Color(0x33000000), blurRadius: 28, offset: Offset(0, 14)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              _Avatar(user: user),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        _AccountBadge(connected: user != null),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.35,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: AppTheme.muted, height: 1.35, fontSize: 11.5),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          const Divider(height: 1),
          const SizedBox(height: 14),
          const Row(
            children: <Widget>[
              Expanded(
                child: _HeroStat(
                  icon: Icons.phone_android_rounded,
                  title: 'Mobil',
                  value: 'ELX-M',
                ),
              ),
              SizedBox(width: 10),
              Expanded(
                child: _HeroStat(
                  icon: Icons.hub_rounded,
                  title: 'Sunucu',
                  value: 'App API',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _AccountBadge extends StatelessWidget {
  const _AccountBadge({required this.connected});

  final bool connected;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
        color: connected ? const Color(0x156FE6B5) : const Color(0x1766E7FF),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(
          color: connected ? const Color(0x356FE6B5) : const Color(0x2F66E7FF),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(
            connected ? Icons.verified_rounded : Icons.person_outline_rounded,
            size: 12,
            color: connected ? AppTheme.success : AppTheme.accent,
          ),
          const SizedBox(width: 5),
          Text(
            connected ? 'BAĞLI HESAP' : 'PROFİL',
            style: TextStyle(
              color: connected ? AppTheme.success : AppTheme.accent,
              fontSize: 8.8,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.05,
            ),
          ),
        ],
      ),
    );
  }
}

class _HeroStat extends StatelessWidget {
  const _HeroStat({required this.icon, required this.title, required this.value});

  final IconData icon;
  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0x160F1826),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: const Color(0x263A465B)),
      ),
      child: Row(
        children: <Widget>[
          Icon(icon, color: AppTheme.accent, size: 19),
          const SizedBox(width: 9),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(title, style: const TextStyle(color: AppTheme.muted, fontSize: 9.5)),
                const SizedBox(height: 2),
                Text(value, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w900)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SignInCard extends StatelessWidget {
  const _SignInCard({
    required this.busy,
    required this.acceptedTerms,
    required this.onAcceptedChanged,
    required this.onSignIn,
  });

  final bool busy;
  final bool acceptedTerms;
  final ValueChanged<bool> onAcceptedChanged;
  final Future<void> Function() onSignIn;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          const Row(
            children: <Widget>[
              _SectionIcon(icon: Icons.login_rounded),
              SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'Google ile devam et',
                      style: TextStyle(fontSize: 16.5, fontWeight: FontWeight.w900),
                    ),
                    SizedBox(height: 3),
                    Text(
                      'Hesabını güvenli şekilde bağla',
                      style: TextStyle(color: AppTheme.muted, fontSize: 11),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 15),
          const Text(
            'Hesap seçici uygulama içinde açılır. Google şifren ELXVRO ile paylaşılmaz.',
            style: TextStyle(color: AppTheme.muted, height: 1.4, fontSize: 12),
          ),
          const SizedBox(height: 10),
          CheckboxListTile(
            value: acceptedTerms,
            contentPadding: EdgeInsets.zero,
            controlAffinity: ListTileControlAffinity.leading,
            onChanged: busy ? null : (bool? value) => onAcceptedChanged(value ?? false),
            title: const Text(
              'Kullanım Koşulları, Gizlilik Politikası ve KVKK metnini kabul ediyorum.',
              style: TextStyle(fontSize: 11.5, height: 1.35),
            ),
          ),
          const SizedBox(height: 7),
          FilledButton.icon(
            onPressed: busy || !acceptedTerms ? null : onSignIn,
            icon: busy
                ? const SizedBox.square(
                    dimension: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.login_rounded),
            label: Text(busy ? 'Google açılıyor...' : 'Google ile Giriş Yap'),
          ),
        ],
      ),
    );
  }
}

class _ConnectedAccountCard extends StatelessWidget {
  const _ConnectedAccountCard({required this.user, required this.accountInfo, required this.busy, required this.onSignOut});

  final GoogleSignInAccount user;
  final ElxvroAccount? accountInfo;
  final bool busy;
  final Future<void> Function() onSignOut;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              const _SectionIcon(icon: Icons.verified_user_rounded),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const Text('Google hesabı bağlı', style: TextStyle(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 3),
                    Text(
                      user.email,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: AppTheme.muted, fontSize: 12),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.check_circle_rounded, color: AppTheme.success, size: 21),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: AppTheme.surfaceAlt,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppTheme.border),
            ),
            child: Row(
              children: <Widget>[
                Icon(
                  accountInfo == null ? Icons.sync_rounded : Icons.hub_rounded,
                  size: 18,
                  color: accountInfo == null ? AppTheme.muted : AppTheme.accent,
                ),
                const SizedBox(width: 9),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      const Text(
                        'ELXVRO hesap kaynağı',
                        style: TextStyle(color: AppTheme.muted, fontSize: 9.5),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        accountInfo?.scopeLabel ?? 'Sunucu ile eşitleniyor...',
                        style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w900),
                      ),
                    ],
                  ),
                ),
                if (accountInfo != null)
                  const Icon(Icons.verified_rounded, color: AppTheme.success, size: 18),
              ],
            ),
          ),
          const SizedBox(height: 14),
          OutlinedButton.icon(
            onPressed: busy ? null : onSignOut,
            icon: const Icon(Icons.logout_rounded),
            label: const Text('Google Hesabından Çıkış Yap'),
          ),
        ],
      ),
    );
  }
}

class _AppStatusCard extends StatelessWidget {
  const _AppStatusCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const Row(
            children: <Widget>[
              ElxvroLogo(compact: true),
              Spacer(),
              _StatusBadge(),
            ],
          ),
          const SizedBox(height: 17),
          Row(
            children: <Widget>[
              const Expanded(
                child: _StatusItem(
                  icon: Icons.phone_android_rounded,
                  title: 'Mobil medya',
                  subtitle: 'ELX-M',
                ),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: _StatusItem(
                  icon: Icons.cloud_done_rounded,
                  title: 'Media Pack',
                  subtitle: 'App API',
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _StatusItem(
                  icon: Icons.new_releases_rounded,
                  title: 'Sürüm',
                  subtitle: AppConfig.version,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  const _StatusBadge();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0x156FE6B5),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0x356FE6B5)),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(Icons.circle, size: 7, color: AppTheme.success),
          SizedBox(width: 6),
          Text(
            'HAZIR',
            style: TextStyle(
              color: AppTheme.success,
              fontSize: 9,
              fontWeight: FontWeight.w900,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusItem extends StatelessWidget {
  const _StatusItem({required this.icon, required this.title, required this.subtitle});

  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
      decoration: BoxDecoration(
        color: AppTheme.surfaceAlt,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0x222E3A50)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(icon, size: 19, color: AppTheme.accent),
          const SizedBox(height: 8),
          Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: AppTheme.muted, fontSize: 9.5),
          ),
          const SizedBox(height: 2),
          Text(
            subtitle,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w900),
          ),
        ],
      ),
    );
  }
}

class _SettingsCard extends StatelessWidget {
  const _SettingsCard({required this.onOpen});

  final Future<void> Function(String url) onOpen;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        children: <Widget>[
          const Padding(
            padding: EdgeInsets.fromLTRB(18, 17, 18, 10),
            child: Row(
              children: <Widget>[
                _SectionIcon(icon: Icons.shield_outlined),
                SizedBox(width: 11),
                Text('Gizlilik ve yasal', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
              ],
            ),
          ),
          ListTile(
            leading: const Icon(Icons.privacy_tip_outlined, color: AppTheme.accent),
            title: const Text('Gizlilik Politikası'),
            subtitle: const Text('Veri ve gizlilik bilgileri'),
            trailing: const Icon(Icons.open_in_new_rounded, size: 18),
            onTap: () => onOpen(AppConfig.privacyUrl),
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.description_outlined, color: AppTheme.accent),
            title: const Text('Kullanım Koşulları'),
            trailing: const Icon(Icons.open_in_new_rounded, size: 18),
            onTap: () => onOpen(AppConfig.termsUrl),
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.gavel_rounded, color: AppTheme.accent),
            title: const Text('KVKK'),
            trailing: const Icon(Icons.open_in_new_rounded, size: 18),
            onTap: () => onOpen(AppConfig.kvkkUrl),
          ),
          const Divider(height: 1),
          const ListTile(
            leading: Icon(Icons.info_outline_rounded, color: AppTheme.accent),
            title: Text('Uygulama sürümü'),
            subtitle: Text('ELXVRO Android'),
            trailing: Text(
              AppConfig.version,
              style: TextStyle(color: AppTheme.muted, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionIcon extends StatelessWidget {
  const _SectionIcon({required this.icon});

  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        color: const Color(0x1F6E6BFF),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: const Color(0x286E6BFF)),
      ),
      child: Icon(icon, size: 20, color: AppTheme.accent),
    );
  }
}

class _Avatar extends StatelessWidget {
  const _Avatar({required this.user});

  final GoogleSignInAccount? user;

  @override
  Widget build(BuildContext context) {
    final String? photo = user?.photoUrl;
    if (photo != null && photo.trim().isNotEmpty) {
      return Container(
        width: 72,
        height: 72,
        padding: const EdgeInsets.all(3),
        decoration: const BoxDecoration(shape: BoxShape.circle, gradient: AppTheme.brandGradient),
        child: CircleAvatar(
          backgroundImage: NetworkImage(photo),
          backgroundColor: AppTheme.surfaceAlt,
        ),
      );
    }

    return Container(
      width: 72,
      height: 72,
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: AppTheme.surfaceAlt,
        shape: BoxShape.circle,
        border: Border.all(color: const Color(0x556E6BFF), width: 2),
        boxShadow: const <BoxShadow>[
          BoxShadow(color: Color(0x336E6BFF), blurRadius: 20),
        ],
      ),
      child: ClipOval(
        child: Image.asset('assets/branding/elxvro_icon.png', fit: BoxFit.cover),
      ),
    );
  }
}
