import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' as http;

import '../config/app_config.dart';
import '../models/elxvro_account.dart';

class GoogleAuthService {
  GoogleAuthService._();

  static final GoogleAuthService instance = GoogleAuthService._();

  final GoogleSignIn _signIn = GoogleSignIn.instance;
  final ValueNotifier<GoogleSignInAccount?> account =
      ValueNotifier<GoogleSignInAccount?>(null);
  final ValueNotifier<ElxvroAccount?> elxvroAccount =
      ValueNotifier<ElxvroAccount?>(null);
  final ValueNotifier<bool> busy = ValueNotifier<bool>(false);
  final ValueNotifier<bool> serverLinked = ValueNotifier<bool>(false);
  final ValueNotifier<String?> lastError = ValueNotifier<String?>(null);

  StreamSubscription<GoogleSignInAuthenticationEvent>? _subscription;
  bool _initialized = false;

  Future<void> initialize() async {
    if (_initialized) return;
    _initialized = true;

    await _signIn.initialize(
      serverClientId: AppConfig.googleWebClientId,
    );

    _subscription = _signIn.authenticationEvents.listen(
      (GoogleSignInAuthenticationEvent event) {
        if (event is GoogleSignInAuthenticationEventSignIn) {
          account.value = event.user;
          lastError.value = null;
          unawaited(_syncElxvroAccount(event.user, silent: true));
        } else if (event is GoogleSignInAuthenticationEventSignOut) {
          account.value = null;
          elxvroAccount.value = null;
          serverLinked.value = false;
        }
      },
      onError: (Object error) {
        lastError.value = _messageFor(error);
      },
    );

    try {
      await _signIn.attemptLightweightAuthentication();
    } catch (_) {
      // Sessiz geri yükleme başarısızsa kullanıcı butondan giriş yapabilir.
    }
  }

  Future<void> signIn() async {
    if (busy.value) return;
    busy.value = true;
    lastError.value = null;

    try {
      if (!_signIn.supportsAuthenticate()) {
        throw Exception('Bu cihaz native Google girişini desteklemiyor.');
      }
      final GoogleSignInAccount user = await _signIn.authenticate();
      account.value = user;
      await _syncElxvroAccount(user, silent: false);
    } catch (error) {
      lastError.value = _messageFor(error);
      rethrow;
    } finally {
      busy.value = false;
    }
  }

  Future<void> _syncElxvroAccount(
    GoogleSignInAccount user, {
    required bool silent,
  }) async {
    try {
      final String? idToken = user.authentication.idToken;
      if (idToken == null || idToken.trim().isEmpty) {
        throw Exception(
          'Google kimlik anahtarı alınamadı. Web Client ID yapılandırmasını kontrol edin.',
        );
      }

      final http.Response response = await http
          .post(
            AppConfig.googleAuthUri,
            headers: const <String, String>{
              'Accept': 'application/json',
              'Content-Type': 'application/json; charset=utf-8',
            },
            body: jsonEncode(<String, String>{'id_token': idToken}),
          )
          .timeout(const Duration(seconds: 12));

      final dynamic decoded = jsonDecode(response.body);
      if (decoded is! Map<String, dynamic>) {
        throw Exception('ELXVRO hesap sunucusu geçersiz yanıt verdi.');
      }
      if (response.statusCode < 200 || response.statusCode >= 300 || decoded['ok'] != true) {
        final dynamic error = decoded['error'];
        final String message = error is Map<String, dynamic>
            ? (error['message'] ?? 'ELXVRO hesabı kaydedilemedi.').toString()
            : 'ELXVRO hesabı kaydedilemedi.';
        throw Exception(message);
      }
      final dynamic data = decoded['data'];
      if (data is! Map<String, dynamic>) {
        throw Exception('ELXVRO hesap bilgisi alınamadı.');
      }
      elxvroAccount.value = ElxvroAccount.fromJson(data);
      serverLinked.value = true;
      lastError.value = null;
    } catch (error) {
      serverLinked.value = false;
      final String message = _messageFor(error);
      lastError.value = message;
      if (!silent) rethrow;
    }
  }

  Future<void> signOut() async {
    if (busy.value) return;
    busy.value = true;
    lastError.value = null;
    try {
      await _signIn.signOut();
      account.value = null;
      elxvroAccount.value = null;
      serverLinked.value = false;
    } catch (error) {
      lastError.value = _messageFor(error);
      rethrow;
    } finally {
      busy.value = false;
    }
  }

  Future<String?> idToken() async => account.value?.authentication.idToken;

  String _messageFor(Object error) {
    if (error is GoogleSignInException) {
      switch (error.code) {
        case GoogleSignInExceptionCode.canceled:
          return 'Google giriş işlemi tamamlanamadı. Hesap erişimi veya OAuth yapılandırmasını kontrol edin.';
        case GoogleSignInExceptionCode.clientConfigurationError:
          return 'Google OAuth yapılandırması eşleşmiyor. Paket adı, SHA-1 ve Web Client ID kontrol edilmeli.';
        default:
          return error.description ?? 'Google ile giriş yapılamadı.';
      }
    }
    return error.toString().replaceFirst('Exception: ', '');
  }

  Future<void> dispose() async {
    await _subscription?.cancel();
  }
}
